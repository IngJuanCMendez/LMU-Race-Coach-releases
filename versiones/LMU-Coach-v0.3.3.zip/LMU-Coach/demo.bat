@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m lmu_coach demo --vueltas 6 --velocidad 3
pause
