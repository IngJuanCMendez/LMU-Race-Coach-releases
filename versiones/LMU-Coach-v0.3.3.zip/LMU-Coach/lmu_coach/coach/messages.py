"""Mensajes del coach, cola con prioridades/antispam y formato de voz en español."""

from __future__ import annotations

import heapq
import itertools
import threading
import time
from dataclasses import dataclass, field

# Prioridades (menor = más urgente)
CRITICAL = 0   # banderas, peligro: puede interrumpir y hablar en curva
CUE = 1        # aviso anticipado de curva: caduca si no se dice a tiempo
HIGH = 2
NORMAL = 3
LOW = 4


@dataclass(order=True)
class Message:
    priority: int
    seq: int = field(compare=True)
    text: str = field(compare=False, default="")
    key: str = field(compare=False, default="")
    expires: float = field(compare=False, default=0.0)   # time.monotonic(); 0 = no caduca
    created: float = field(compare=False, default=0.0)

    @property
    def urgent(self) -> bool:
        return self.priority <= CUE


class MessageQueue:
    """Cola thread-safe con deduplicación por clave y enfriamiento."""

    def __init__(self, max_len: int = 6, clock=time.monotonic) -> None:
        self.clock = clock
        self._h: list[Message] = []
        self._lock = threading.Lock()
        self._seq = itertools.count()
        self._last_said: dict[str, float] = {}
        self.max_len = max_len
        self.history: list[tuple[float, str]] = []

    def push(self, text: str, priority: int = NORMAL, key: str = "", cooldown: float = 0.0,
             ttl: float = 0.0) -> bool:
        now = self.clock()
        key = key or text
        with self._lock:
            if cooldown and now - self._last_said.get(key, -1e9) < cooldown:
                return False
            # reemplaza un mensaje pendiente con la misma clave
            self._h = [m for m in self._h if m.key != key]
            m = Message(priority, next(self._seq), text, key, now + ttl if ttl else 0.0, now)
            heapq.heapify(self._h)
            heapq.heappush(self._h, m)
            self._last_said[key] = now
            # descarta lo menos importante si hay saturación
            while len(self._h) > self.max_len:
                worst = max(self._h)
                self._h.remove(worst)
                heapq.heapify(self._h)
            return True

    def pop(self, allow_normal: bool) -> Message | None:
        """Saca el siguiente mensaje decible. `allow_normal`=False → solo urgentes."""
        now = self.clock()
        with self._lock:
            self._h = [m for m in self._h if not m.expires or m.expires > now]
            heapq.heapify(self._h)
            if not self._h:
                return None
            if self._h[0].urgent or allow_normal:
                m = heapq.heappop(self._h)
                self.history.append((time.time(), m.text))
                return m
            return None

    def has_critical(self) -> bool:
        with self._lock:
            return any(m.priority == CRITICAL for m in self._h)

    def clear(self) -> None:
        with self._lock:
            self._h.clear()


# --------------------------------------------------------------------------- formato
_UNITS = ["cero", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"]


def say_laptime(sec: float) -> str:
    """92.34 → '1 32 punto 3' (las voces SAPI en español lo leen natural)."""
    if sec <= 0:
        return "sin tiempo"
    total = int(round(sec * 10))          # décimas
    m, rest = divmod(total, 600)
    whole, tenths = divmod(rest, 10)
    if m:
        return f"{m} {whole:02d} punto {tenths}"
    return f"{whole} punto {tenths}"


def say_delta(sec: float) -> str:
    """Diferencia en tiempo: 'más 3 décimas', 'menos 1 punto 2 segundos'."""
    sign = "más" if sec > 0 else "menos"
    a = abs(sec)
    if a < 0.05:
        return "igual"
    if a < 0.95:
        d = int(round(a * 10))
        return f"{sign} {'una' if d == 1 else d} {'décima' if d == 1 else 'décimas'}"
    return f"{sign} {a:.1f} segundos".replace(".", " punto ")


def say_tenths(sec: float) -> str:
    d = max(1, int(round(abs(sec) * 10)))
    if d >= 10:
        return f"{abs(sec):.1f} segundos".replace(".", " punto ")
    return f"{'una' if d == 1 else d} {'décima' if d == 1 else 'décimas'}"


def say_int(n: float) -> str:
    return str(int(round(n)))


def say_laps(n: float) -> str:
    n = int(n)
    return "una vuelta" if n == 1 else f"{n} vueltas"


def say_gap(sec: float) -> str:
    """Brecha en segundos para voz: 'ocho décimas', '1 punto 4'."""
    a = abs(sec)
    if a < 1.0:
        d = max(1, int(round(a * 10)))
        return "una décima" if d == 1 else f"{d} décimas"
    return f"{a:.1f}".replace(".", " punto ")
