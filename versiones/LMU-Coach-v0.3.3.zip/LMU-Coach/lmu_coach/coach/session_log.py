"""Registro de sesión en disco (se reescribe al cerrar cada vuelta)."""

from __future__ import annotations

import gzip
import json
import time
from pathlib import Path

from .track import resample, slug

SESSION_NAMES = {0: "Test", 9: "Warmup"}


def session_name(n: int) -> str:
    if 1 <= n <= 4:
        return "Práctica"
    if 5 <= n <= 8:
        return "Clasificación"
    if 10 <= n <= 13:
        return "Carrera"
    return SESSION_NAMES.get(n, f"Sesión {n}")


class SessionLog:
    def __init__(self, root: Path, f) -> None:
        stamp = time.strftime("%Y%m%d_%H%M%S")
        self.dir = Path(root) / "sessions" / f"{stamp}_{slug(f.track)}_{slug(f.car)}"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "session.json"
        self.data = {
            "started": time.strftime("%Y-%m-%d %H:%M:%S"),
            "track": f.track, "car": f.car, "class": f.car_class,
            "session": session_name(f.session), "is_race": f.is_race,
            "reference": None, "laps": [],
        }
        self._write()

    def set_reference(self, ref) -> None:
        self.data["reference"] = {
            "lap_time": ref.lap_time, "length": ref.length,
            "corners": ref.corners_dict(),
            "metrics": {k: vars(m) for k, m in ref.metrics.items()},
        }
        self._write()

    def add_lap(self, summary: dict, trace=None, length: float = 0.0) -> None:
        if trace is not None and len(trace) > 50 and length > 0 and summary.get("complete"):
            ld = self.dir / "laps"
            ld.mkdir(exist_ok=True)
            fn = ld / f"lap_{summary['lap']:03d}.json.gz"
            with gzip.open(fn, "wt", encoding="utf-8") as fh:
                json.dump({k: [round(x, 4) for x in v] for k, v in resample(trace, length).items()}, fh)
            summary["trace_file"] = f"laps/{fn.name}"
        self.data["laps"].append(summary)
        self._write()

    def _write(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
        tmp.replace(self.path)

    def close(self) -> Path:
        self.data["ended"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._write()
        return self.path
