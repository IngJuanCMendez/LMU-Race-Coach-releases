"""Vuelta de referencia, detección de curvas y métricas por curva."""

from __future__ import annotations

import bisect
import gzip
import json
import re
from dataclasses import dataclass, asdict, field
from pathlib import Path

STEP = 2.0  # metros por punto del remuestreo
CHANNELS = ("t", "speed", "throttle", "brake", "steer", "lat_g", "slip_f", "slip_r", "sr_f", "sr_r", "gear", "abs", "tc")


def slug(s: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", s).strip("_").lower() or "desconocido"


# --------------------------------------------------------------------------- traza
class LapTrace:
    """Muestras crudas de una vuelta, indexadas por distancia."""

    __slots__ = ("d", "t", "speed", "throttle", "brake", "steer", "lat_g",
                 "slip_f", "slip_r", "sr_f", "sr_r", "gear", "abs", "tc")

    def __init__(self) -> None:
        for k in self.__slots__:
            setattr(self, k, [])

    def add(self, f) -> None:
        d = f.dist
        if self.d and d <= self.d[-1]:
            return  # distancia no creciente (pausa, reinicio de interpolación)
        self.d.append(d)
        self.t.append(f.t - f.lap_start_t)
        self.speed.append(f.speed)
        self.throttle.append(f.throttle)
        self.brake.append(f.brake)
        self.steer.append(f.steer)
        self.lat_g.append(abs(f.lat_g))
        sa = f.slip_angle
        self.slip_f.append((abs(sa[0]) + abs(sa[1])) / 2)
        self.slip_r.append((abs(sa[2]) + abs(sa[3])) / 2)
        sr = f.slip_ratio
        self.sr_f.append(max(abs(sr[0]), abs(sr[1])))
        self.sr_r.append(max(abs(sr[2]), abs(sr[3])))
        self.gear.append(float(f.gear))
        self.abs.append(1.0 if f.abs_active else 0.0)
        self.tc.append(1.0 if f.tc_active else 0.0)

    def __len__(self) -> int:
        return len(self.d)

    @property
    def max_d(self) -> float:
        return self.d[-1] if self.d else 0.0

    def time_at(self, dist: float) -> float | None:
        return interp(self.d, self.t, dist)


def interp(xs: list, ys: list, x: float):
    if not xs or x < xs[0] or x > xs[-1]:
        return None
    i = bisect.bisect_left(xs, x)
    if i == 0:
        return ys[0]
    x0, x1 = xs[i - 1], xs[i]
    if x1 == x0:
        return ys[i]
    a = (x - x0) / (x1 - x0)
    return ys[i - 1] + a * (ys[i] - ys[i - 1])


def resample(trace: LapTrace, length: float) -> dict:
    n = int(length / STEP)
    out = {k: [] for k in CHANNELS}
    out["d"] = []
    for i in range(n):
        x = i * STEP
        if x < trace.d[0]:
            x = trace.d[0]
        if x > trace.d[-1]:
            x = trace.d[-1]
        out["d"].append(i * STEP)
        for k in CHANNELS:
            out[k].append(interp(trace.d, getattr(trace, k), x))
    return out


# --------------------------------------------------------------------------- curvas
@dataclass
class Corner:
    num: int
    entry_d: float      # inicio de ventana de medición
    brake_d: float      # punto de frenada (o de levantar) de referencia
    apex_d: float
    exit_d: float       # fin de ventana (salida de curva)
    braking: bool       # True = curva de frenada, False = solo levantar
    seg_end_d: float = 0.0  # fin de la medición de tiempo (incluye la recta de salida)


def detect_corners(ref: dict) -> list[Corner]:
    d, v, thr, brk = ref["d"], ref["speed"], ref["throttle"], ref["brake"]
    n = len(d)
    raw: list[list[int]] = []  # [start, apex, exit, braking]
    i = 0
    while i < n:
        if brk[i] > 0.15:
            s = i
            while i < n and brk[i] > 0.05:
                i += 1
            if (i - s) * STEP < 6:
                continue
            raw.append([s, i, 1])
        i += 1
    # curvas sin frenada: el piloto levanta y la velocidad cae >6 %
    i = 1
    while i < n - 1:
        if thr[i] < 0.85 and brk[i] < 0.05:
            s = i
            while i < n and thr[i] < 0.9 and brk[i] < 0.05:
                i += 1
            seg = v[s:i] or [v[s]]
            pre = max(v[max(0, s - 100):s + 1])
            if (i - s) * STEP >= 10 and min(seg) < pre * 0.94:
                if not any(a <= s <= b + 50 for a, b, _ in raw):
                    raw.append([s, i, 0])
        i += 1
    raw.sort()
    corners: list[Corner] = []
    for s, e, braking in raw:
        # vértice: velocidad mínima tras el inicio
        end = min(n - 1, e)
        while end < n - 1 and thr[end] < 0.95 and (end - e) * STEP < 600:
            end += 1
        apex = min(range(s, end + 1), key=lambda k: v[k])
        j = apex
        while j < n - 1 and thr[j] < 0.95 and (j - apex) * STEP < 600:
            j += 1
        ex = j
        if corners and s * STEP <= corners[-1].exit_d:
            # fusionar con la anterior (chicanas)
            c = corners[-1]
            c.exit_d = ex * STEP + 30
            if v[apex] < interp(d, v, c.apex_d):
                c.apex_d = apex * STEP
            continue
        corners.append(Corner(len(corners) + 1, max(0.0, s * STEP - 60), s * STEP,
                              apex * STEP, min(d[-1], ex * STEP + 30), bool(braking)))
    # que las ventanas no se solapen
    for a, b in zip(corners, corners[1:]):
        if a.exit_d > b.entry_d:
            mid = (a.exit_d + b.entry_d) / 2
            a.exit_d, b.entry_d = mid, mid
    for k, c in enumerate(corners):
        c.num = k + 1
        nxt = corners[k + 1].entry_d if k + 1 < len(corners) else d[-1]
        c.seg_end_d = max(c.exit_d, min(nxt, c.exit_d + 250))
    return corners


# --------------------------------------------------------------------------- métricas
@dataclass
class CornerMetrics:
    num: int
    time: float
    brake_d: float | None
    min_speed: float      # km/h
    apex_d: float
    full_throttle_d: float | None
    lock: float = 0.0     # max slip ratio delantero frenando
    spin: float = 0.0     # max slip ratio trasero acelerando
    balance: float = 0.0  # slip delantero - trasero (°): + subviraje, - sobreviraje
    abs_pct: float = 0.0
    peak_brake: float = 0.0     # presión máxima de freno (0..1)
    trail_m: float = 0.0        # metros frenando con volante girado (trail braking)
    coast_m: float = 0.0        # metros sin freno ni acelerador entre frenada y aceleración
    apex_gear: int = 0
    tc_pct: float = 0.0         # fracción de la salida (vértice → recta) con TC actuando


def corner_metrics(c: Corner, d, t, v, thr, brk, slip_f=None, slip_r=None,
                   sr_f=None, sr_r=None, lat=None, steer=None, gear=None, absa=None, tca=None) -> CornerMetrics | None:
    t0 = interp(d, t, c.entry_d)
    t1 = interp(d, t, c.seg_end_d or c.exit_d)
    if t0 is None or t1 is None:
        return None
    i0 = bisect.bisect_left(d, c.entry_d)
    i1 = bisect.bisect_right(d, c.exit_d)
    if i1 - i0 < 3:
        return None
    idx = range(i0, i1)
    brake_d = None
    lo = c.brake_d - 150
    for k in idx:
        if d[k] >= lo and brk[k] > 0.15:
            brake_d = d[k]
            break
    if brake_d is None and not c.braking:
        for k in idx:
            if thr[k] < 0.85:
                brake_d = d[k]
                break
    apex = min(idx, key=lambda k: v[k])
    i2 = max(i1, bisect.bisect_right(d, c.seg_end_d or c.exit_d))
    full = None
    for k in range(apex, i2):
        if thr[k] >= 0.95:
            full = d[k]
            break
    m = CornerMetrics(c.num, t1 - t0, brake_d, v[apex] * 3.6, d[apex], full)
    m.peak_brake = max((brk[k] for k in idx), default=0.0)
    if gear:
        m.apex_gear = int(round(gear[apex]))
    if absa:
        bz = [k for k in idx if brk[k] > 0.3]
        m.abs_pct = sum(absa[k] for k in bz) / len(bz) if bz else 0.0
    if tca:
        ex = [k for k in range(apex, i2) if thr[k] > 0.5]
        m.tc_pct = sum(tca[k] for k in ex) / len(ex) if ex else 0.0
    start = bisect.bisect_left(d, brake_d) if brake_d is not None else apex
    stop = bisect.bisect_left(d, full) if full is not None else i1
    for k in range(max(start, i0 + 1), min(stop, i2)):
        seg = d[k] - d[k - 1]
        if steer and brk[k] > 0.05 and abs(steer[k]) > 0.12:
            m.trail_m += seg
        if thr[k] < 0.1 and brk[k] < 0.05:
            m.coast_m += seg
    if sr_f:
        m.lock = max((sr_f[k] for k in idx if brk[k] > 0.4), default=0.0)
    if sr_r:
        m.spin = max((sr_r[k] for k in range(apex, i2) if thr[k] > 0.5), default=0.0)
    if slip_f and slip_r and lat:
        mids = [k for k in idx if lat[k] > 0.8]
        if mids:
            m.balance = sum(slip_f[k] - slip_r[k] for k in mids) / len(mids)
    return m


def trace_metrics(c: Corner, tr: LapTrace) -> CornerMetrics | None:
    return corner_metrics(c, tr.d, tr.t, tr.speed, tr.throttle, tr.brake,
                          tr.slip_f, tr.slip_r, tr.sr_f, tr.sr_r, tr.lat_g, tr.steer, tr.gear, tr.abs, tr.tc)


def data_metrics(c: Corner, D: dict) -> CornerMetrics | None:
    """Métricas sobre datos remuestreados (dict de canales)."""
    return corner_metrics(c, D["d"], D["t"], D["speed"], D["throttle"], D["brake"],
                          D.get("slip_f"), D.get("slip_r"), D.get("sr_f"), D.get("sr_r"), D.get("lat_g"),
                          D.get("steer"), D.get("gear"), D.get("abs"), D.get("tc"))


# --------------------------------------------------------------------------- referencia
@dataclass
class Reference:
    track: str
    car: str
    lap_time: float
    length: float
    data: dict
    corners: list[Corner] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)  # num -> CornerMetrics

    @classmethod
    def from_trace(cls, trace: LapTrace, track: str, car: str, lap_time: float, length: float):
        data = resample(trace, length)
        ref = cls(track, car, lap_time, length, data)
        ref.rebuild()
        return ref

    def rebuild(self) -> None:
        self.corners = detect_corners(self.data)
        D = self.data
        self.metrics = {}
        for c in self.corners:
            m = data_metrics(c, D)
            if m:
                self.metrics[c.num] = m

    def time_at(self, dist: float):
        return interp(self.data["d"], self.data["t"], dist)

    # persistencia
    def path(self, root: Path) -> Path:
        return root / "references" / f"{slug(self.track)}__{slug(self.car)}.json.gz"

    def save(self, root: Path) -> Path:
        p = self.path(root)
        p.parent.mkdir(parents=True, exist_ok=True)
        blob = {"track": self.track, "car": self.car, "lap_time": self.lap_time,
                "length": self.length, "data": self.data}
        with gzip.open(p, "wt", encoding="utf-8") as fh:
            json.dump(blob, fh)
        return p

    @classmethod
    def load(cls, root: Path, track: str, car: str):
        p = root / "references" / f"{slug(track)}__{slug(car)}.json.gz"
        if not p.exists():
            return None
        with gzip.open(p, "rt", encoding="utf-8") as fh:
            b = json.load(fh)
        ref = cls(b["track"], b["car"], b["lap_time"], b["length"], b["data"])
        ref.rebuild()
        return ref

    def corners_dict(self) -> list[dict]:
        return [asdict(c) for c in self.corners]
