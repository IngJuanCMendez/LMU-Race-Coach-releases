"""LMU Race Coach."""
__version__ = "0.3.3"
