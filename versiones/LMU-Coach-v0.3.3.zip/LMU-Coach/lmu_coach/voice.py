"""Voz del ingeniero: TTS en un hilo propio con prioridades.

Backends:
  sapi     → Windows SAPI5 vía pywin32 (offline, asíncrono, permite interrumpir). Recomendado.
  pyttsx3  → alternativa multiplataforma.
  console  → solo imprime (pruebas / sin audio).

Voces en español para Windows: Configuración → Hora e idioma → Voz → Agregar voces
(p. ej. "Microsoft Sabina" (México), "Microsoft Helena"/"Pablo" (España)).
"""

from __future__ import annotations

import sys
import threading
import time
from typing import Callable

from .coach.messages import CRITICAL, MessageQueue

SPANISH_HINTS = ("spanish", "español", "espanol", "es-", "es_", "sabina", "helena", "pablo",
                 "laura", "raul", "dalia", "jorge", "elvira", "alvaro", "salome", "gonzalo")


class _Console:
    def __init__(self, **_):
        pass

    def speak(self, text: str, interrupt: bool = False) -> None:
        print(f"  🔊 {text}", flush=True)

    def busy(self) -> bool:
        return False

    def voices(self) -> list[str]:
        return ["console"]


class _Sapi:
    def __init__(self, voice: str = "", rate: int = 1, volume: int = 100):
        import pythoncom  # noqa: F401  (pywin32)
        import win32com.client
        pythoncom.CoInitialize()
        self.v = win32com.client.Dispatch("SAPI.SpVoice")
        self.v.Rate = rate
        self.v.Volume = volume
        tokens = [self.v.GetVoices().Item(i) for i in range(self.v.GetVoices().Count)]
        chosen = None
        want = voice.lower()
        for t in tokens:
            d = t.GetDescription().lower()
            if want and want in d:
                chosen = t
                break
        if chosen is None:
            for t in tokens:
                d = t.GetDescription().lower()
                if any(h in d for h in SPANISH_HINTS):
                    chosen = t
                    break
        if chosen is not None:
            self.v.Voice = chosen
        self._names = [t.GetDescription() for t in tokens]

    def speak(self, text: str, interrupt: bool = False) -> None:
        SVSFlagsAsync, SVSFPurgeBeforeSpeak = 1, 2
        self.v.Speak(text, SVSFlagsAsync | (SVSFPurgeBeforeSpeak if interrupt else 0))

    def busy(self) -> bool:
        return self.v.Status.RunningState == 2  # SRSEIsSpeaking

    def voices(self) -> list[str]:
        return self._names


class _Pyttsx3:
    def __init__(self, voice: str = "", rate: int = 1, volume: int = 100):
        import pyttsx3
        self.e = pyttsx3.init()
        self.e.setProperty("rate", 175 + rate * 15)
        self.e.setProperty("volume", volume / 100)
        vs = self.e.getProperty("voices")
        self._names = [v.name for v in vs]
        want = voice.lower()
        for v in vs:
            name = f"{v.name} {v.id}".lower()
            if (want and want in name) or (not want and any(h in name for h in SPANISH_HINTS)):
                self.e.setProperty("voice", v.id)
                break

    def speak(self, text: str, interrupt: bool = False) -> None:
        if interrupt:
            self.e.stop()
        self.e.say(text)
        self.e.runAndWait()

    def busy(self) -> bool:
        return False

    def voices(self) -> list[str]:
        return self._names


def make_backend(name: str, **kw):
    order = [name] if name != "auto" else (["sapi", "pyttsx3", "console"] if sys.platform == "win32"
                                           else ["pyttsx3", "console"])
    for n in order:
        try:
            return {"sapi": _Sapi, "pyttsx3": _Pyttsx3, "console": _Console}[n](**kw)
        except Exception as e:  # noqa: BLE001
            print(f"[voz] backend '{n}' no disponible: {e}")
    return _Console()


class Voice(threading.Thread):
    """Hilo que habla los mensajes de la cola cuando es seguro hacerlo."""

    def __init__(self, queue: MessageQueue, can_speak: Callable[[], bool], backend: str = "auto",
                 voice: str = "", rate: int = 1, volume: int = 100, echo: bool = True):
        super().__init__(daemon=True, name="voice")
        self.q = queue
        self.can_speak = can_speak
        self.cfg = dict(voice=voice, rate=rate, volume=volume)
        self.backend_name = backend
        self.echo = echo
        self._stop = threading.Event()
        self.backend = None
        self.ready = threading.Event()

    def run(self) -> None:
        # El backend COM debe crearse en el mismo hilo que lo usa.
        self.backend = make_backend(self.backend_name, **self.cfg)
        self.ready.set()
        while not self._stop.is_set():
            if self.backend.busy():
                if self.q.has_critical():
                    m = self.q.pop(True)
                    if m:
                        self._say(m.text, interrupt=True)
                time.sleep(0.05)
                continue
            m = self.q.pop(allow_normal=self.can_speak())
            if m is None:
                time.sleep(0.05)
                continue
            self._say(m.text, interrupt=m.priority == CRITICAL)

    def _say(self, text: str, interrupt: bool) -> None:
        if self.echo and not isinstance(self.backend, _Console):
            print(f"  🔊 {text}", flush=True)
        try:
            self.backend.speak(text, interrupt)
        except Exception as e:  # noqa: BLE001
            print(f"[voz] error: {e}")

    def stop(self) -> None:
        self._stop.set()
