"""Análisis post-sesión a partir de session.json."""

from __future__ import annotations

import gzip
import json
import statistics as st
from collections import Counter
from dataclasses import asdict
from pathlib import Path

from ..coach.track import Corner, data_metrics
from ..frame import WHEELS


def recompute_corners(sess: dict, base: Path | None) -> None:
    """Recalcula las métricas de curva de cada vuelta con las ventanas de la referencia final."""
    ref = sess.get("reference")
    if not ref or base is None:
        return
    corners = [Corner(**c) for c in ref["corners"]]
    for lap in sess.get("laps", []):
        tf = lap.get("trace_file")
        if not tf or not (base / tf).exists():
            continue
        with gzip.open(base / tf, "rt", encoding="utf-8") as fh:
            D = json.load(fh)
        res = {}
        for c in corners:
            m = data_metrics(c, D)
            if m:
                res[str(c.num)] = asdict(m)
        lap["corners"] = res


def _valid(laps):
    return [l for l in laps if l.get("valid")]


def analyze(sess: dict, base: Path | None = None) -> dict:
    recompute_corners(sess, base)
    laps = sess.get("laps", [])
    valid = _valid(laps)
    ref = sess.get("reference") or {}
    ref_m = ref.get("metrics", {})
    corners = {str(c["num"]): c for c in ref.get("corners", [])}
    out: dict = {"track": sess.get("track"), "car": sess.get("car"), "class": sess.get("class"),
                 "session": sess.get("session"), "laps_total": len(laps), "laps_valid": len(valid)}
    if not valid:
        out["note"] = "No hay vueltas válidas completas para analizar."
        return out

    times = [l["time"] for l in valid]
    best = min(times)
    out["best"] = best
    out["reference_time"] = ref.get("lap_time", best)
    out["avg"] = st.mean(times)
    out["consistency_sd"] = st.pstdev(times) if len(times) > 1 else 0.0
    out["laps"] = [{"lap": l["lap"], "time": round(l["time"], 3), "valid": l["valid"]} for l in laps if l.get("complete")]

    # --- por curva
    per = {}
    for num, rm in ref_m.items():
        rows = [l["corners"][num] for l in valid if num in l.get("corners", {}) and not l["corners"][num].get("incident")]
        if not rows:
            continue
        # pérdida contra la referencia FINAL (la referencia pudo cambiar durante la sesión)
        losses = [r["time"] - rm["time"] for r in rows]
        vmins = [r["min_speed"] for r in rows]
        issues = Counter()
        for r in rows:
            if rm.get("brake_d") is not None and r.get("brake_d") is not None:
                db = r["brake_d"] - rm["brake_d"]
                if db < -8:
                    issues["frena temprano"] += 1
                elif db > 8:
                    issues["frena tarde"] += 1
            if r["min_speed"] < rm["min_speed"] - 3:
                issues["poca velocidad mínima"] += 1
            if rm.get("full_throttle_d") and r.get("full_throttle_d") and r["full_throttle_d"] - rm["full_throttle_d"] > 12:
                issues["acelera tarde"] += 1
            if r.get("lock", 0) > 0.2:
                issues["bloqueo delantero"] += 1
            if r.get("spin", 0) > 0.2:
                issues["patinaje trasero"] += 1
        per[num] = {
            "corner": int(num),
            "type": "lenta" if rm["min_speed"] < 100 else ("rápida" if rm["min_speed"] > 160 else "media"),
            "ref_min_speed": round(rm["min_speed"], 1),
            "avg_loss": round(st.mean(losses), 3),
            "best_time_gain": round(min(losses), 3),
            "vmin_sd": round(st.pstdev(vmins), 2) if len(vmins) > 1 else 0.0,
            "balance": round(st.mean(r.get("balance", 0.0) for r in rows), 2),
            "locks": sum(1 for r in rows if r.get("lock", 0) > 0.2),
            "spins": sum(1 for r in rows if r.get("spin", 0) > 0.2),
            "issues": dict(issues.most_common(3)),
            "brake_d": corners.get(num, {}).get("brake_d"),
        }
    # referencias de frenada: la mejor ejecución de cada curva
    brake_ref = []
    for num in ref_m:
        rows = [l["corners"][num] for l in valid if num in l.get("corners", {}) and not l["corners"][num].get("incident")]
        if not rows:
            continue
        b = min(rows, key=lambda r: r["time"])
        bd = b.get("brake_d")
        braking = corners.get(num, {}).get("braking", True)
        brake_ref.append({
            "corner": int(num), "braking": braking,
            "brake_to_apex_m": round(b["apex_d"] - bd) if bd is not None else None,
            "brake_d": round(bd) if bd is not None else None,
            "apex_kmh": round(b["min_speed"]),
            "apex_gear": b.get("apex_gear") or None,
            "peak_brake_pct": round(b.get("peak_brake", 0) * 100),
            "trail_m": round(b.get("trail_m", 0)),
            "coast_m": round(b.get("coast_m", 0)),
            "abs_pct": round(sum(r.get("abs_pct", 0) for r in rows) / len(rows) * 100),
            "tc_pct": round(sum(r.get("tc_pct", 0) for r in rows) / len(rows) * 100),
            "brake_sd_m": round(st.pstdev([r["brake_d"] for r in rows if r.get("brake_d") is not None]), 1)
            if sum(1 for r in rows if r.get("brake_d") is not None) > 1 else 0.0,
        })
    out["brake_refs"] = sorted(brake_ref, key=lambda x: x["corner"])
    cars = [l["car"] for l in valid if l.get("car")]
    if cars:
        out["car_aids"] = {k: round(st.mean(c[k] for c in cars) * 100, 1) for k in ("lock_f", "lock_r", "abs", "spin", "tc")}
        for k in ("entry_bal", "brake_ratio"):
            xs = [c[k] for c in cars if c.get(k) is not None]
            out["car_aids"][k] = round(st.mean(xs), 2) if xs else None
        last = cars[-1]
        out["car_aids"].update({k: last.get(k) for k in ("bias_front", "abs_level", "abs_max", "tc_level", "tc_max",
                                                          "tc_slip", "tc_slip_max", "tc_cut", "tc_cut_max")})
    riv = [l["rivals"] for l in laps if l.get("rivals")]
    if riv:
        out["rivals_last"] = riv[-1]
    out["corners"] = sorted(per.values(), key=lambda x: -x["avg_loss"])
    gain = sum(min(0.0, c["best_time_gain"]) for c in per.values())
    out["ideal_lap"] = out["reference_time"] + gain

    # --- balance por tipo de curva (slip delantero - trasero; + = subviraje)
    bal = {}
    for t in ("lenta", "media", "rápida"):
        xs = [c["balance"] for c in per.values() if c["type"] == t]
        if xs:
            bal[t] = round(st.mean(xs), 2)
    out["balance_by_type"] = bal

    # --- llantas (promedio de vueltas válidas tras la primera)
    stint = valid[1:] or valid
    tt = [[st.mean(l["tyre_temp"][w][j] for l in stint) for j in range(3)] for w in range(4)]
    out["tyre_temp"] = {WHEELS[w]: [round(x, 1) for x in tt[w]] for w in range(4)}
    carc = [st.mean(l.get("tyre_carcass", [0] * 4)[w] for l in stint) for w in range(4)]
    out["tyre_carcass"] = {WHEELS[w]: round(carc[w], 1) for w in range(4)}
    out["tyre_press"] = {WHEELS[w]: round(st.mean(l["tyre_press"][w] for l in stint), 1) for w in range(4)}
    opt = stint[-1].get("tyre_opt") or [0] * 4
    out["tyre_opt"] = {WHEELS[w]: round(opt[w], 1) for w in range(4)}
    out["tyre_wear_end"] = {WHEELS[w]: round(laps[-1]["tyre_wear"][w], 3) for w in range(4)}
    out["brake_max"] = {WHEELS[w]: round(max(l["brake_max"][w] for l in stint)) for w in range(4)}
    def _rh(i):
        xs = [l["ride_min"][i] for l in stint if l.get("ride_min") and l["ride_min"][i] and l["ride_min"][i] < 9]
        return round(min(xs) * 1000, 1) if xs else None
    out["ride_min"] = {"front_mm": _rh(0), "rear_mm": _rh(1)}
    fu = [l["fuel_used"] for l in stint if l.get("fuel_used", 0) > 0]
    out["fuel_per_lap"] = round(st.mean(fu), 2) if fu else None
    ve = [l["ve_used"] for l in stint if l.get("ve_used")]
    out["ve_per_lap_pct"] = round(st.mean(ve) * 100, 2) if ve else None
    out["compound"] = stint[-1].get("compound")
    out["conditions"] = {"air": stint[-1].get("air"), "track": stint[-1].get("track_temp")}
    return out
