"""Reglas locales de setup a partir del análisis.

Son puntos de partida de ingeniería clásicos (rFactor 2 / LMU), no verdades
absolutas: haz UN cambio a la vez y confirma con el siguiente stint.
"""

from __future__ import annotations

# Para llantas izquierdas, el lado interior es el derecho (índice 2); para las derechas, el izquierdo (0).
INNER = {"FL": 2, "RL": 2, "FR": 0, "RR": 0}
OUTER = {"FL": 0, "RL": 0, "FR": 2, "RR": 2}
AXLE = {"FL": "delantero", "FR": "delantero", "RL": "trasero", "RR": "trasero"}


def advise(a: dict) -> list[dict]:
    out: list[dict] = []
    if "tyre_temp" not in a:
        return out

    def add(area, obs, sug, conf="media"):
        out.append({"area": area, "observacion": obs, "sugerencia": sug, "confianza": conf})

    # ---- caída (camber) y presión por perfil de temperatura
    for axle, ws in (("delantero", ("FL", "FR")), ("trasero", ("RL", "RR"))):
        spreads, crowns = [], []
        for w in ws:
            t = a["tyre_temp"][w]
            spreads.append(t[INNER[w]] - t[OUTER[w]])
            crowns.append(t[1] - (t[0] + t[2]) / 2)
        sp = sum(spreads) / 2
        cr = sum(crowns) / 2
        if sp > 10:
            add(f"Caída eje {axle}", f"Interior {sp:.0f} °C más caliente que el exterior.",
                f"Reduce caída negativa en el eje {axle} (−0.2/−0.3°).", "media")
        elif sp < 2:
            add(f"Caída eje {axle}", f"Interior apenas {sp:.0f} °C sobre el exterior.",
                f"Puedes probar más caída negativa en el eje {axle} para más agarre en apoyo.", "baja")
        if cr > 4:
            add(f"Presión eje {axle}", f"Centro {cr:.0f} °C más caliente que los bordes.",
                f"Presión alta: baja la presión del eje {axle} un paso.", "media")
        elif cr < -4:
            add(f"Presión eje {axle}", f"Centro {abs(cr):.0f} °C más frío que los bordes.",
                f"Presión baja: sube la presión del eje {axle} un paso.", "media")

    # ---- temperatura media vs óptima
    for w, t in a["tyre_temp"].items():
        carc = a.get("tyre_carcass", {}).get(w, 0)
        opt = a.get("tyre_opt", {}).get(w) or 0
        if carc <= 0 and opt:
            continue  # la óptima de LMU es de carcasa; sin ese dato no se compara
        avg = carc if carc > 0 else sum(t) / 3
        if opt and avg < opt - 10:
            add(f"Temperatura {w}", f"{avg:.0f} °C vs óptima {opt:.0f} °C.",
                "Llanta fría: sube presión, cierra un poco ductos de freno de ese eje o usa un compuesto más blando.", "baja")
        elif opt and avg > opt + 10:
            add(f"Temperatura {w}", f"{avg:.0f} °C vs óptima {opt:.0f} °C.",
                "Llanta caliente: baja presión o considera compuesto más duro; revisa deslizamiento en esa esquina.", "baja")

    # ---- balance (slip delantero − trasero)
    bal = a.get("balance_by_type", {})
    slow, fast = bal.get("lenta"), bal.get("rápida", bal.get("media"))
    if slow is not None and slow > 1.5:
        add("Balance curva lenta", f"Subviraje en curvas lentas (delante desliza {slow:.1f}° más).",
            "Mecánico: ablanda barra estabilizadora delantera o endurece la trasera; menos precarga de diferencial.", "media")
    elif slow is not None and slow < -1.5:
        add("Balance curva lenta", f"Sobreviraje en curvas lentas (detrás desliza {-slow:.1f}° más).",
            "Mecánico: ablanda barra trasera o endurece la delantera; más precarga/rampa de diferencial; sube TC.", "media")
    if fast is not None and fast > 1.5:
        add("Balance curva rápida", f"Subviraje en curvas rápidas ({fast:.1f}°).",
            "Aero: reduce el ala trasera un paso o baja la altura delantera (más rake) para cargar más el frente.", "media")
    elif fast is not None and fast < -1.5:
        add("Balance curva rápida", f"Sobreviraje en curvas rápidas ({-fast:.1f}°).",
            "Aero: sube ala trasera un paso o sube altura delantera/baja trasera (rake).", "media")

    # ---- bloqueos y patinaje
    locks = sum(c["locks"] for c in a.get("corners", []))
    spins = sum(c["spins"] for c in a.get("corners", []))
    if locks >= 2:
        where = ", ".join(str(c["corner"]) for c in a["corners"] if c["locks"])
        add("Frenos", f"{locks} bloqueos delanteros (curvas {where}).",
            "Mueve el reparto de freno 0.5–1 % hacia atrás, sube ABS un nivel si lo tiene, o reduce presión máxima de freno.", "alta")
    if spins >= 2:
        where = ", ".join(str(c["corner"]) for c in a["corners"] if c["spins"])
        add("Tracción", f"{spins} patinajes traseros en salida (curvas {where}).",
            "Sube TC un nivel, ablanda barra trasera o muelles traseros; revisa rampa de potencia del diferencial.", "alta")

    # ---- ayudas: reparto, ABS, TC Slip, TC Cut
    ca = a.get("car_aids") or {}
    bias = ca.get("bias_front")
    if bias:
        bal, ratio = ca.get("entry_bal"), ca.get("brake_ratio")
        if bal is not None and bal > 1.5:
            add("Reparto de freno", f"Subviraje al entrar frenando (delanteras derivan {bal:.1f}° más).",
                f"Reparto medio punto atrás: {bias} → {bias - 0.5:.1f} % adelante.", "media")
        elif bal is not None and bal < -0.8:
            add("Reparto de freno", f"La cola se suelta al entrar frenando ({bal:.1f}°).",
                f"Reparto medio punto adelante: {bias} → {bias + 0.5:.1f} % adelante.", "media")
        elif ratio is not None and ratio > 2.5:
            add("Reparto de freno", f"En frenada recta las delanteras deslizan {ratio:.1f}× más que las traseras.",
                f"Hay margen atrás: prueba {bias - 0.5:.1f} % adelante.", "baja")
        elif ratio is not None and ratio < 1.15:
            add("Reparto de freno", "En frenada recta las traseras trabajan casi como las delanteras.",
                f"Para más estabilidad prueba {bias + 0.5:.1f} % adelante.", "baja")
    if ca.get("abs_max") and ca.get("abs", 0) > 30 and ca.get("lock_f", 0) < 1:
        add("ABS", f"El ABS actúa en el {ca['abs']:.0f} % de la frenada sin bloqueos.",
            f"Prueba ABS {ca['abs_level'] - 1} (uno menos) para frenar más corto.", "media")
    if ca.get("tc_cut_max") and ca.get("tc", 0) >= 3 and ca.get("spin", 0) < 1:
        add("TC Cut", f"El TC actúa en el {ca['tc']:.0f} % de las salidas y no patinas.",
            f"Prueba TC Cut {max(0, (ca.get('tc_cut') or 0) - 1)} (uno menos): cortará menos potencia al actuar.", "media")
    if ca.get("tc_slip_max") and ca.get("tc", 0) >= 2 and ca.get("spin", 0) < 1:
        add("TC Slip", "El TC entra sin que haya patinaje real.",
            f"Prueba TC Slip {max(0, (ca.get('tc_slip') or 0) - 1)} (uno menos) para permitir más deslizamiento y rotación en la salida.", "baja")
    if ca.get("spin", 0) >= 3:
        add("TC", f"Patinaje en el {ca['spin']:.0f} % de las salidas.",
            "Sube TC Slip un punto (entra antes) o TC Cut un punto (corta más).", "alta")

    # ---- altura / tope
    rm = a.get("ride_min", {})
    if rm.get("front_mm") and 0 < rm["front_mm"] < 5:
        add("Altura delantera", f"Altura mínima delantera {rm['front_mm']} mm (posible tope con el piso).",
            "Sube altura delantera un paso o endurece muelles/tercer elemento delantero.", "media")
    if rm.get("rear_mm") and 0 < rm["rear_mm"] < 5:
        add("Altura trasera", f"Altura mínima trasera {rm['rear_mm']} mm.",
            "Sube altura trasera o endurece muelles/tercer elemento trasero.", "media")

    # ---- frenos
    bm = a.get("brake_max", {})
    fr = max(bm.get("FL", 0), bm.get("FR", 0))
    if fr > 900:
        add("Temperatura de frenos", f"Delanteros llegan a {fr:.0f} °C.",
            "Abre ductos de freno delanteros un paso.", "baja")
    return out
