"""Debrief con Claude (opcional). Requiere `pip install anthropic` y ANTHROPIC_API_KEY."""

from __future__ import annotations

import json
import os
from pathlib import Path

SYSTEM = """Eres un ingeniero de pista y coach de pilotaje de resistencia (WEC) experto en
Le Mans Ultimate (motor rFactor 2). Hablas español latino, directo y técnico pero claro.
Recibes un análisis numérico de una sesión (ya calculado: no inventes datos que no estén)
y, opcionalmente, el archivo de setup .svm. Entregas:

1. Resumen en 3 líneas (ritmo, consistencia, vuelta ideal vs mejor).
2. Las 3 prioridades de PILOTAJE ordenadas por tiempo recuperable, cada una con curva(s),
   qué hacer exactamente (referencias de frenada, vértice, acelerador) y cuánto se gana aprox.
3. Cambios de SETUP ordenados por impacto: máximo 4, UNO A LA VEZ, con el parámetro concreto
   del .svm si se proporcionó (nombre y dirección del cambio en pasos/clicks), el porqué
   según los datos y qué debería notar el piloto. Diferencia problemas de pilotaje de problemas de coche.
4. Ayudas: reparto de freno, ABS y TC con valores concretos (actual → sugerido) según
   bloqueos, inestabilidad trasera, patinaje y % de actuación de ABS/TC.
5. Referencias de frenada: para las 3 curvas con más pérdida, el punto de frenada (metros antes
   del vértice), presión pico, trail braking y marcha de la mejor ejecución, y cómo replicarla.
6. Plan para el siguiente stint (5 vueltas) en viñetas.

Convenciones de los datos: balance = ángulo de deriva delantero − trasero en grados
(+ subviraje, − sobreviraje). Temperaturas de llanta [izq, centro, der] en °C; para llantas
izquierdas el interior es 'der' y para las derechas el interior es 'izq'. Presiones en kPa.
Si un dato es insuficiente, dilo en una frase en lugar de suponer."""


def _svm_excerpt(path: str | None, limit: int = 220) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.exists():
        return ""
    lines = []
    for ln in p.read_text(encoding="utf-8", errors="ignore").splitlines():
        s = ln.strip()
        if s.startswith("[") or ("Setting=" in s and "//" in s and "Non-adjustable" not in s):
            lines.append(s)
    return "\n".join(lines[:limit])


def ai_debrief(cfg: dict, analysis: dict, local_advice: list[dict], setup_path: str | None = None) -> str | None:
    if not cfg["ia"].get("habilitada", True):
        return None
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("[IA] Sin ANTHROPIC_API_KEY: se omite el debrief con Claude (el análisis local sí se genera).")
        return None
    try:
        import anthropic
    except ImportError:
        print("[IA] Falta el paquete 'anthropic' (pip install anthropic).")
        return None
    svm = _svm_excerpt(setup_path)
    user = ("ANÁLISIS DE SESIÓN (JSON):\n" + json.dumps(analysis, ensure_ascii=False, indent=1) +
            "\n\nSUGERENCIAS DE LAS REGLAS LOCALES (valídalas o corrígelas):\n" +
            json.dumps(local_advice, ensure_ascii=False, indent=1))
    if svm:
        user += "\n\nSETUP .SVM (extracto de parámetros ajustables):\n" + svm
    client = anthropic.Anthropic()
    try:
        r = client.messages.create(model=cfg["ia"]["modelo"], max_tokens=int(cfg["ia"]["max_tokens"]),
                                   system=SYSTEM, messages=[{"role": "user", "content": user}])
    except Exception as e:  # noqa: BLE001
        print(f"[IA] Error llamando a Claude: {e}")
        return None
    return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
