"""Ejecuta el coach en un hilo de fondo (lo usa la interfaz gráfica)."""

from __future__ import annotations

import collections
import threading
import time

from . import config as C
from .coach.engine import CoachEngine
from .coach.messages import MessageQueue
from .voice import Voice


class CoachRunner(threading.Thread):
    """status: 'detenido' | 'esperando' | 'conectado' | 'demo' | 'error: ...'"""

    def __init__(self, cfg: dict, mode: str = "lmu", demo_speed: float = 3.0):
        super().__init__(daemon=True, name="coach")
        self.cfg = cfg
        self.mode = mode
        self.demo_speed = demo_speed
        self.status = "iniciando"
        self.engine: CoachEngine | None = None
        self.voice: Voice | None = None
        self.queue: MessageQueue | None = None
        self.radio = collections.deque(maxlen=200)   # (hora, texto, prioridad)
        self._stop = threading.Event()
        self.talk = None

    def stop(self) -> None:
        self._stop.set()

    @property
    def running(self) -> bool:
        return self.is_alive() and not self._stop.is_set()

    def _log_factory(self):
        path = C.data_dir(self.cfg) / "coach.log"
        fh = open(path, "a", encoding="utf-8")

        def log(msg):
            fh.write(time.strftime("%H:%M:%S ") + str(msg) + "\n")
            fh.flush()
        return log

    def run(self) -> None:
        try:
            self._run()
        except Exception as e:  # noqa: BLE001
            import traceback
            self.status = f"error: {e}"
            self._log_factory()("ERROR runner:\n" + traceback.format_exc())

    def _run(self) -> None:
        log = self._log_factory()
        log(f"=== inicio interfaz ({self.mode}) ===")
        if self.mode == "demo":
            from .sources.synthetic import SyntheticSource
            src = SyntheticSource(laps=30, speed=self.demo_speed, realtime=True, session=10)
            data_dir = C.data_dir(self.cfg) / "demo"
            data_dir.mkdir(parents=True, exist_ok=True)
            self.status = "demo"
        else:
            from .sources.lmu import LMUSource
            src = LMUSource()
            data_dir = C.data_dir(self.cfg)
            self.status = "esperando"
            while not self._stop.is_set() and not src.connect():
                time.sleep(1.0)
            if self._stop.is_set():
                self.status = "detenido"
                return
            self.status = "conectado"

        live = self.mode != "demo"
        sim = [0.0]
        self.queue = MessageQueue(clock=time.monotonic if live else (lambda: sim[0]))
        self.engine = CoachEngine(self.cfg, self.queue, data_dir, log=log)
        self.engine.listeners.append(lambda t, p: self.radio.appendleft((time.strftime("%H:%M:%S"), t, p)))
        vc = self.cfg["voz"]
        self.voice = Voice(self.queue, self.engine.can_speak, vc["backend"], vc["voz"], vc["velocidad"],
                           vc["volumen"], echo=False)
        self.voice.start()
        self.voice.ready.wait(5)
        if self.cfg.get("hablar", {}).get("habilitado"):
            try:
                from .talk import TalkListener
                self.talk = TalkListener(self.cfg, self.engine, log)
                self.talk.start()
            except Exception as e:  # noqa: BLE001
                log(f"hablar con el coach no disponible: {e}")

        period = 1.0 / float(self.cfg["lectura"]["hz"])
        last_t, last_cars = None, -1e9
        try:
            while not self._stop.is_set():
                f = src.read()
                if f is None:
                    if not live:
                        break
                    time.sleep(0.3)
                    self.status = "conectado" if src.alive() else "esperando"
                    continue
                if f.t != last_t:
                    last_t = f.t
                    sim[0] = f.t
                    self.engine.on_frame(f)
                    if hasattr(src, "read_cars") and (f.t - last_cars >= 0.5 or f.t < last_cars):
                        last_cars = f.t
                        try:
                            self.engine.on_cars(src.read_cars(), f)
                        except Exception as e:  # noqa: BLE001
                            log(f"error rivales: {e}")
                if live:
                    time.sleep(period)
        finally:
            self.engine.close()
            if self.talk:
                self.talk.stop()
            time.sleep(0.5)
            self.voice.stop()
            self.status = "detenido"
