"""Estilo visual (oscuro, tipo telemetría)."""

BG = "#0e1014"
PANEL = "#161a21"
PANEL2 = "#1d222b"
BORDER = "#262c37"
TEXT = "#e8ebf0"
MUTED = "#8a93a3"
ACCENT = "#ff7a1a"     # naranja Le Mans
GOOD = "#2ecc71"
WARN = "#f1c40f"
BAD = "#e74c3c"
COLD = "#3fa7ff"

QSS = f"""
* {{ font-family: 'Segoe UI', 'Inter', sans-serif; font-size: 13px; color: {TEXT}; }}
QMainWindow, QWidget#root {{ background: {BG}; }}
QWidget {{ background: transparent; }}
QFrame#card {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 10px; }}
QLabel#cardTitle {{ color: {MUTED}; font-size: 11px; font-weight: 600; letter-spacing: 1px; }}
QLabel#big {{ font-size: 34px; font-weight: 700; font-family: 'Consolas', 'Segoe UI Mono', monospace; }}
QLabel#mid {{ font-size: 18px; font-weight: 600; font-family: 'Consolas', 'Segoe UI Mono', monospace; }}
QLabel#muted {{ color: {MUTED}; }}
QLabel#h1 {{ font-size: 20px; font-weight: 700; }}
QLabel#h2 {{ font-size: 15px; font-weight: 600; }}
QListWidget#nav {{ background: {PANEL}; border: none; border-right: 1px solid {BORDER}; padding-top: 12px; outline: 0; }}
QListWidget#nav::item {{ padding: 12px 18px; border-radius: 8px; margin: 2px 8px; color: {MUTED}; }}
QListWidget#nav::item:selected {{ background: {PANEL2}; color: {TEXT}; border-left: 3px solid {ACCENT}; }}
QPushButton {{ background: {PANEL2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 8px 14px; }}
QPushButton:hover {{ border-color: {ACCENT}; }}
QPushButton#primary {{ background: {ACCENT}; color: #111; font-weight: 700; border: none; }}
QPushButton#primary:hover {{ background: #ff9443; }}
QPushButton#danger {{ background: {BAD}; color: white; font-weight: 700; border: none; }}
QPushButton:disabled {{ color: {MUTED}; border-color: {BORDER}; }}
QListWidget, QTableWidget, QTextBrowser, QPlainTextEdit, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
    background: {PANEL}; border: 1px solid {BORDER}; border-radius: 8px; padding: 4px; }}
QTableWidget {{ gridline-color: {BORDER}; }}
QHeaderView::section {{ background: {PANEL2}; color: {MUTED}; border: none; padding: 6px; font-weight: 600; }}
QTableWidget::item {{ padding: 4px; }}
QListWidget#radio::item {{ padding: 6px 4px; border-bottom: 1px solid {BORDER}; }}
QSlider::groove:horizontal {{ height: 6px; background: {PANEL2}; border-radius: 3px; }}
QSlider::handle:horizontal {{ background: {ACCENT}; width: 18px; margin: -6px 0; border-radius: 9px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 3px; }}
QProgressBar {{ background: {PANEL2}; border: none; border-radius: 4px; text-align: center; color: transparent; }}
QProgressBar#thr::chunk {{ background: {GOOD}; border-radius: 4px; }}
QProgressBar#brk::chunk {{ background: {BAD}; border-radius: 4px; }}
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border: 2px solid {MUTED}; border-radius: 4px; background: {PANEL2}; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QListWidget::item:selected {{ background: {PANEL2}; color: {TEXT}; border-left: 3px solid {ACCENT}; }}
QListWidget::item {{ padding: 8px 6px; border-bottom: 1px solid {BORDER}; }}
QScrollArea {{ border: none; }}
QToolTip {{ background: {PANEL2}; border: 1px solid {BORDER}; padding: 6px; }}
"""


def temp_color(t: float, opt: float, win: float = 8.0) -> str:
    if t <= 0:
        return MUTED
    if t < opt - win:
        return COLD
    if t > opt + win:
        return BAD
    return GOOD
