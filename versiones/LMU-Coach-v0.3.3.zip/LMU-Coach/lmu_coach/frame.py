"""Muestra de telemetría normalizada (independiente de la fuente)."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict

WHEELS = ("FL", "FR", "RL", "RR")
WHEEL_ES = {
    "FL": "delantera izquierda",
    "FR": "delantera derecha",
    "RL": "trasera izquierda",
    "RR": "trasera derecha",
}


@dataclass
class Frame:
    # Tiempo / posición
    t: float = 0.0                 # tiempo de sesión (s)
    lap: int = 0                   # número de vuelta actual
    lap_start_t: float = 0.0       # tiempo de sesión en que empezó la vuelta
    dist: float = 0.0              # distancia recorrida en la vuelta (m)
    track_len: float = 0.0         # longitud de pista (m)
    x: float = 0.0
    z: float = 0.0

    # Conducción
    speed: float = 0.0             # m/s
    throttle: float = 0.0          # 0..1
    brake: float = 0.0             # 0..1
    steer: float = 0.0             # -1..1
    gear: int = 0
    rpm: float = 0.0
    max_rpm: float = 0.0
    yaw_rate: float = 0.0          # rad/s
    lat_g: float = 0.0
    lon_g: float = 0.0
    abs_active: bool = False
    tc_active: bool = False

    # Energía
    fuel: float = 0.0              # litros
    fuel_cap: float = 0.0
    virtual_energy: float = -1.0   # fracción 0..1 (-1 = no disponible)
    battery: float = -1.0

    # Llantas / frenos (orden FL, FR, RL, RR)
    tyre_temp: list = field(default_factory=lambda: [[0.0, 0.0, 0.0] for _ in range(4)])  # °C izq/centro/der
    tyre_carcass: list = field(default_factory=lambda: [0.0] * 4)
    tyre_opt: list = field(default_factory=lambda: [0.0] * 4)       # °C óptima (0 = desconocida)
    tyre_press: list = field(default_factory=lambda: [0.0] * 4)     # kPa
    tyre_wear: list = field(default_factory=lambda: [0.0] * 4)      # 0..1 (1 = nueva en rF2: fracción restante)
    brake_temp: list = field(default_factory=lambda: [0.0] * 4)     # °C
    slip_angle: list = field(default_factory=lambda: [0.0] * 4)     # grados
    slip_ratio: list = field(default_factory=lambda: [0.0] * 4)     # long patch vel / ground vel
    ride_h_front: float = 0.0
    ride_h_rear: float = 0.0
    compound: str = ""

    # Ajustes de coche en vivo
    brake_bias_rear: float = 0.0
    tc_level: int = 0
    tc_max: int = 0
    tc_slip: int = 0
    tc_slip_max: int = 0
    tc_cut: int = 0
    tc_cut_max: int = 0
    abs_level: int = 0
    abs_max: int = 0
    motor_map: int = 0

    # Sesión / estado
    track: str = ""
    car: str = ""
    car_class: str = ""
    session: int = 0               # 0 testday, 1-4 práctica, 5-8 clasif, 9 warmup, 10-13 carrera
    game_phase: int = 0
    in_realtime: bool = False
    in_pits: bool = False
    pit_state: int = 0
    place: int = 0
    flag: int = 0                  # 6 = azul
    yellow_state: int = 0
    sector_flags: tuple = (0, 0, 0)
    sector: int = 0
    lap_invalid: bool = False
    track_limits_steps: int = 0
    best_lap: float = 0.0
    last_lap: float = 0.0
    delta_best: float = 0.0
    time_remaining: float = -1.0
    max_laps: int = 0
    gap_ahead: float = 0.0
    gap_behind: float = 0.0
    air_temp: float = 0.0
    track_temp: float = 0.0
    wetness: float = 0.0

    @property
    def kmh(self) -> float:
        return self.speed * 3.6

    @property
    def is_race(self) -> bool:
        return 10 <= self.session <= 13

    @property
    def lap_time(self) -> float:
        return self.t - self.lap_start_t

    def to_row(self) -> dict:
        return asdict(self)
