"""Pista y piloto sintéticos para pruebas y demo sin el juego.

Genera telemetría físicamente plausible (perfil de velocidad por curvatura con
fases de frenada y aceleración) y errores de pilotaje controlados por curva,
para verificar que el coach los detecta.
"""

from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass

from ..frame import Frame

G = 9.81

# Pista de demo (~4.6 km): ("S", largo) recta, ("C", radio, ángulo°) curva
DEMO_TRACK = [
    ("S", 900), ("C", 25, 90), ("S", 350), ("C", 60, 70), ("S", 250),
    ("C", 120, 45), ("S", 500), ("C", 18, 120), ("S", 420), ("C", 45, 80),
    ("S", 300), ("C", 80, 60), ("S", 260), ("C", 30, 100), ("S", 380),
]


@dataclass
class CornerError:
    """Error de pilotaje aplicado a una curva en una vuelta."""
    kind: str          # 'late_brake' | 'early_brake' | 'slow_apex' | 'late_throttle' | 'lock' | 'spin'
    corner: int


class SyntheticTrack:
    def __init__(self, layout=None, ds: float = 1.0):
        layout = layout or DEMO_TRACK
        self.ds = ds
        self.k: list[float] = []          # curvatura por metro
        self.corner_of: list[int] = []    # índice de curva por metro (-1 recta)
        self.corners: list[tuple[int, int]] = []
        ci = 0
        for seg in layout:
            n0 = len(self.k)
            if seg[0] == "S":
                n = int(seg[1] / ds)
                self.k += [0.0] * n
                self.corner_of += [-1] * n
            else:
                r, ang = seg[1], seg[2]
                n = int(r * math.radians(ang) / ds)
                self.k += [1.0 / r] * n
                self.corner_of += [ci] * n
                self.corners.append((n0, n0 + n))
                ci += 1
        self.length = len(self.k) * ds
        self.next_corner = [-1] * len(self.k)
        nc = -1
        for i in range(len(self.k) - 1, -1, -1):
            if self.corner_of[i] >= 0:
                nc = self.corner_of[i]
            self.next_corner[i] = nc
        # posición XY para mapa
        self.xy = []
        hdg = x = y = 0.0
        for k in self.k:
            hdg += k * ds
            x += math.cos(hdg) * ds
            y += math.sin(hdg) * ds
            self.xy.append((x, y))


class SyntheticDriver:
    """Calcula perfiles de velocidad y genera vueltas."""

    def __init__(self, track: SyntheticTrack, seed: int = 7,
                 vtop: float = 85.0, mu: float = 2.2, a_max: float = 9.0, b_max: float = 24.0):
        self.tr = track
        self.rng = random.Random(seed)
        self.vtop, self.mu, self.a_max, self.b_max = vtop, mu, a_max, b_max

    def profile(self, errors: list[CornerError]):
        tr = self.tr
        n = len(tr.k)
        apex_scale = [1.0] * len(tr.corners)
        brake_scale = [1.0] * len(tr.corners)
        thr_delay = [0] * len(tr.corners)
        for e in errors:
            if e.kind == "late_brake":
                brake_scale[e.corner] = 1.35
                apex_scale[e.corner] = 0.93
            elif e.kind == "early_brake":
                brake_scale[e.corner] = 0.62
            elif e.kind == "slow_apex":
                apex_scale[e.corner] = 0.90
            elif e.kind == "late_throttle":
                thr_delay[e.corner] = 40

        vmax = []
        for i, k in enumerate(tr.k):
            v = self.vtop if k == 0 else min(self.vtop, math.sqrt(self.mu * G / k))
            c = tr.corner_of[i]
            if c >= 0:
                v *= apex_scale[c]
            vmax.append(v)

        # zona de frenada asignada a la curva siguiente
        next_corner = [-1] * n
        nc = -1
        for i in range(n - 1, -1, -1):
            if tr.corner_of[i] >= 0:
                nc = tr.corner_of[i]
            next_corner[i] = nc

        # retraso de aceleración tras la curva
        for c, (a, b) in enumerate(tr.corners):
            for i in range(b, min(n, b + thr_delay[c])):
                vmax[i] = min(vmax[i], vmax[b - 1])

        v = vmax[:]
        # pasada hacia adelante (aceleración)
        v[0] = min(v[0], 60.0)
        for i in range(1, n):
            a = self.a_max * max(0.05, 1 - v[i - 1] / self.vtop)
            v[i] = min(v[i], math.sqrt(v[i - 1] ** 2 + 2 * a * tr.ds))
        # pasada hacia atrás (frenada)
        for i in range(n - 2, -1, -1):
            c = next_corner[i + 1]
            b = self.b_max * (brake_scale[c] if c >= 0 else 1.0)
            b = min(b, self.b_max * 1.4)
            v[i] = min(v[i], math.sqrt(v[i + 1] ** 2 + 2 * b * tr.ds))
        return v

    def lap_samples(self, errors: list[CornerError]):
        """Lista de muestras por metro: (s, v, throttle, brake, t)."""
        tr = self.tr
        v = self.profile(errors)
        out = []
        t = 0.0
        n = len(v)
        for i in range(n):
            vn = v[(i + 1) % n] if i + 1 < n else v[i]
            dv2 = (vn * vn - v[i] * v[i]) / (2 * tr.ds)
            if dv2 < -0.5:
                brake, thr = min(1.0, -dv2 / self.b_max * 1.1), 0.0
            elif dv2 > 0.3:
                thr, brake = 1.0, 0.0
            else:
                thr, brake = (0.55 if (tr.k[i] > 0 or v[i] < self.vtop * 0.97) else 1.0), 0.0
            out.append((i * tr.ds, v[i], thr, brake, t))
            t += tr.ds / max(v[i], 1.0)
        return out, t


class SyntheticSource:
    """Fuente que reproduce vueltas sintéticas a velocidad real o acelerada."""

    name = "synthetic"

    def __init__(self, laps: int = 6, speed: float = 1.0, hz: float = 30.0, seed: int = 7,
                 error_plan: dict[int, list[CornerError]] | None = None, realtime: bool = True,
                 session: int = 1):
        self.tr = SyntheticTrack()
        self.drv = SyntheticDriver(self.tr, seed=seed)
        self.rng = random.Random(seed)
        self.laps = laps
        self.speed = speed
        self.hz = hz
        self.realtime = realtime
        self.session = session
        self.error_plan = error_plan if error_plan is not None else self.default_plan(laps)
        self._gen = self._frames()
        self._t0 = None
        self._last = None
        # (id, vehículo, clase, tiempo por vuelta, ventaja inicial en vueltas, pits (t0, t1))
        self.rivals_def = [
            (55, "Ferrari 296 LMGT3 #55", "GT3", 80.9, 0.035, (300.0, 330.0)),
            (92, "Porsche 911 LMGT3 #92", "GT3", 79.0, -0.010, None),
            (31, "BMW M4 LMGT3 #31", "GT3", 83.0, -0.30, None),
            (8, "Toyota GR010 #8", "Hypercar", 70.0, -0.25, None),
        ]

    def default_plan(self, laps: int):
        plan = {1: [CornerError("slow_apex", 2), CornerError("late_throttle", 4)],
                2: [],  # vuelta limpia → referencia
                3: [CornerError("early_brake", 3)],
                4: [CornerError("late_brake", 0), CornerError("slow_apex", 5)],
                5: [CornerError("early_brake", 3), CornerError("late_throttle", 6)]}
        for lap in range(6, laps + 1):
            c = self.rng.randrange(len(self.tr.corners))
            plan[lap] = [CornerError(self.rng.choice(
                ["late_brake", "early_brake", "slow_apex", "late_throttle"]), c)]
        return plan

    def connect(self) -> bool:
        return True

    def alive(self) -> bool:
        return True

    def _frames(self):
        tr = self.tr
        t_session = 0.0
        fuel = 70.0
        ve = 1.0
        best = 0.0
        last = 0.0
        wear = [1.0] * 4
        for lap in range(1, self.laps + 1):
            errs = self.error_plan.get(lap, [])
            samples, lap_time = self.drv.lap_samples(errs)
            lock_c = {e.corner for e in errs if e.kind == "lock"}
            spin_c = {e.corner for e in errs if e.kind == "spin"}
            tcheavy = bool([e for e in errs if e.kind == "tc_heavy"])
            absheavy = bool([e for e in errs if e.kind == "abs_heavy"])
            setting = getattr(self, "settings_by_lap", {}).get(lap, {})
            lap_start = t_session
            # interpolación temporal
            dt = 1.0 / self.hz
            j = 0
            tl = 0.0
            while tl < lap_time:
                while j + 1 < len(samples) and samples[j + 1][4] <= tl:
                    j += 1
                s, v, thr, brk, ts = samples[j]
                idx = min(int(s / tr.ds), len(tr.k) - 1)
                k = tr.k[idx]
                f = Frame()
                f.t = lap_start + tl
                f.lap = lap
                f.lap_start_t = lap_start
                f.dist = s + v * (tl - ts)
                f.track_len = tr.length
                f.x, f.z = tr.xy[idx]
                f.speed = v
                f.throttle, f.brake = thr, brk
                f.steer = max(-1.0, min(1.0, k * 6.0))
                f.gear = max(1, min(7, int(v / 12) + 1))
                f.rpm = 4000 + (v % 12) / 12 * 4500
                f.max_rpm = 9000
                f.lat_g = v * v * k / G
                f.yaw_rate = v * k
                f.fuel = fuel - 2.9 * (s / tr.length)
                f.fuel_cap = 90.0
                f.virtual_energy = ve - 0.085 * (s / tr.length)
                corner_load = min(1.0, f.lat_g / 2.2)
                base = 78 + 6 * min(lap, 3) + 4 * corner_load
                # FL caliente por dentro (lado derecho de la llanta izquierda) → camber alto
                f.tyre_temp = [[base - 4, base + 1, base + 9], [base + 2, base, base - 3],
                               [base - 2, base, base + 2], [base + 1, base, base - 1]]
                f.tyre_opt = [90.0] * 4
                f.tyre_press = [178 + min(lap, 3) * 4, 177 + min(lap, 3) * 4,
                                170 + min(lap, 3) * 3, 171 + min(lap, 3) * 3]
                f.tyre_wear = [w - 0.012 * (s / tr.length) for w in wear]
                f.brake_temp = [350 + 400 * brk] * 2 + [300 + 250 * brk] * 2
                us = 1.6 * corner_load  # subviraje en apoyo
                f.slip_angle = [3.0 * corner_load + us] * 2 + [3.0 * corner_load] * 2
                f.ride_h_front = 0.035 - 0.012 * (v / 85) ** 2
                f.ride_h_rear = 0.06 - 0.01 * (v / 85) ** 2
                f.compound = "Medium"
                f.brake_bias_rear = 0.44
                f.abs_level, f.abs_max, f.tc_level, f.tc_max = 4, 10, 5, 10
                f.tc_slip, f.tc_slip_max, f.tc_cut, f.tc_cut_max = 4, 10, 3, 10
                for k, v in setting.items():
                    setattr(f, k, v)
                if absheavy and brk > 0.3:
                    f.abs_active = True
                nc = tr.next_corner[idx]
                if brk > 0.3 and nc not in lock_c:
                    f.slip_ratio = [0.09 * brk, 0.09 * brk, 0.03 * brk, 0.03 * brk]   # delanteras trabajan ~3x
                cur = tr.corner_of[idx]
                if brk > 0.3 and nc in lock_c:
                    f.slip_ratio = [0.35, 0.35, 0.02, 0.02]
                    f.abs_active = True
                if tcheavy and thr > 0.6 and abs(f.lat_g) > 0.3:
                    f.tc_active = True
                if thr > 0.6 and brk == 0 and idx > 0 and tr.corner_of[max(0, idx - 30)] in spin_c and cur == -1:
                    f.slip_ratio = [0.0, 0.0, 0.3, 0.3]
                    f.lat_g = max(f.lat_g, 0.5)
                f.track = "Demo Ring"
                f.car = "Demo LMGT3"
                f.car_class = "GT3"
                f.session = self.session
                f.game_phase = 5
                f.in_realtime = True
                f.place = 3
                f.best_lap = best
                f.last_lap = last
                f.time_remaining = 3600 - f.t
                f.air_temp, f.track_temp = 24.0, 33.0
                yield f
                tl += dt
            t_session = lap_start + lap_time
            fuel -= 2.9
            ve -= 0.085
            wear = [w - 0.012 for w in wear]
            last = lap_time
            best = lap_time if best == 0 else min(best, lap_time)

    def read_cars(self):
        from ..coach.rivals import Car
        f = self._last
        if f is None:
            return []
        L = self.tr.length
        if not hasattr(self, "_clean"):
            smp, lt = self.drv.lap_samples([])
            self._clean = ([x[4] / lt for x in smp], [x[0] for x in smp])  # fracción de tiempo -> distancia
        import bisect
        tf, ds = self._clean

        def dist_at(frac):
            i = min(bisect.bisect_left(tf, frac), len(ds) - 1)
            return ds[i]
        cars = [Car(0, "Juan Camilo", f.car, "GT3", 0, f.lap - 1, f.dist, f.in_pits, 0, f.last_lap, f.best_lap, True, f.speed)]
        for rid, veh, cls, lt, off, pit in self.rivals_def:
            rd = off + f.t / lt
            laps = int(rd // 1)
            in_pits = bool(pit and pit[0] <= f.t <= pit[1])
            cars.append(Car(rid, f"Piloto {rid}", veh, cls, 0, laps, dist_at(rd - laps), in_pits, 1 if pit and f.t > pit[0] else 0,
                            lt if rd > 1 else 0.0, lt if rd > 1 else 0.0, False, L / lt))
        order = sorted(cars, key=lambda c: -(c.laps + c.lapdist / L))
        for i, c in enumerate(order):
            c.place = i + 1
        return cars

    def read(self) -> Frame | None:
        try:
            f = next(self._gen)
        except StopIteration:
            return None
        self._last = f
        if self.realtime:
            now = time.perf_counter()
            if self._t0 is None:
                self._t0 = now - f.t / self.speed
            wait = self._t0 + f.t / self.speed - now
            if wait > 0:
                time.sleep(wait)
        return f

    def close(self) -> None:
        pass
