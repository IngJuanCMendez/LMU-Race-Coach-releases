"""Actualizaciones desde GitHub Releases.

Publica una release en el repo configurado ([actualizaciones] repo = "usuario/LMU-Coach")
con un tag de versión (p. ej. v0.4.0) y adjunta el zip de la app (o usa el zip del código).
La app descarga, reemplaza su código y conserva datos/ y config.toml.
"""

from __future__ import annotations

import io
import json
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from . import __version__

ROOT = Path(__file__).resolve().parent.parent
KEEP = {"datos", "config.toml", ".venv", "instalacion_ok.txt"}


def _ver(t: str) -> tuple:
    t = t.strip().lstrip("vV")
    out = []
    for p in t.split("."):
        n = "".join(ch for ch in p if ch.isdigit())
        out.append(int(n) if n else 0)
    return tuple(out + [0] * (3 - len(out)))


def _manifest(repo: str, timeout: float) -> dict | None:
    """latest.json en la rama main del repo público: {"version","notes","file"}."""
    base = f"https://raw.githubusercontent.com/{repo}/main/"
    req = urllib.request.Request(base + "latest.json", headers={"User-Agent": "LMU-Coach"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            m = json.load(r)
    except Exception:  # noqa: BLE001
        return None
    url = m.get("url") or (base + m["file"])
    return {"version": m["version"], "notes": m.get("notes", ""), "url": url}


def check(repo: str, timeout: float = 8.0) -> dict | None:
    """Devuelve {'version','notes','url'} si hay una versión más nueva, si no None."""
    if not repo or "/" not in repo:
        return None
    m = _manifest(repo, timeout)
    if m:
        return m if _ver(m["version"]) > _ver(__version__) else None
    req = urllib.request.Request(f"https://api.github.com/repos/{repo}/releases/latest",
                                 headers={"Accept": "application/vnd.github+json", "User-Agent": "LMU-Coach"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        rel = json.load(r)
    tag = rel.get("tag_name", "")
    if _ver(tag) <= _ver(__version__):
        return None
    url = next((a["browser_download_url"] for a in rel.get("assets", []) if a["name"].endswith(".zip")),
               rel.get("zipball_url"))
    return {"version": tag, "notes": rel.get("body", ""), "url": url}


def apply(url: str, progress=lambda s: None) -> str:
    """Descarga e instala. Devuelve la versión instalada."""
    progress("Descargando…")
    req = urllib.request.Request(url, headers={"User-Agent": "LMU-Coach"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    progress("Instalando…")
    with tempfile.TemporaryDirectory() as tmp:
        zipfile.ZipFile(io.BytesIO(data)).extractall(tmp)
        # la raíz del zip puede ser una carpeta (LMU-Coach/ o usuario-repo-hash/)
        cands = [p for p in Path(tmp).rglob("lmu_coach") if (p / "__init__.py").exists()]
        if not cands:
            raise RuntimeError("El paquete descargado no contiene la app.")
        src_root = cands[0].parent
        for item in src_root.iterdir():
            if item.name in KEEP or item.name.startswith("."):
                continue
            dst = ROOT / item.name
            if item.is_dir():
                shutil.copytree(item, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dst)
        # dependencias nuevas
        import subprocess
        import sys
        req_file = ROOT / "requirements.txt"
        if req_file.exists():
            progress("Actualizando dependencias…")
            subprocess.run([sys.executable.replace("pythonw", "python"), "-m", "pip", "install", "-q", "-r", str(req_file)],
                           check=False, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        # nuevas claves de configuración: se agregan sin tocar las del usuario
        from . import config as C
        C.save(C.load())
        new_ver = (src_root / "lmu_coach" / "__init__.py").read_text(encoding="utf-8")
    ver = next((ln.split("=")[1].strip().strip('"') for ln in new_ver.splitlines() if "__version__" in ln), "?")
    progress(f"Actualizado a {ver}. Reinicia la app.")
    return ver
