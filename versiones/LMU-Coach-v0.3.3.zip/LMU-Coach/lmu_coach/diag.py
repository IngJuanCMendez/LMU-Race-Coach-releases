"""Diagnóstico: voz + memoria compartida de LMU. Escribe datos/diagnostico.txt."""

from __future__ import annotations

import ctypes
import platform
import subprocess
import sys
import time
import traceback
from pathlib import Path


def run(cfg: dict, data_dir: Path, seconds: int = 15) -> Path:
    out = data_dir / "diagnostico.txt"
    lines: list[str] = []

    def log(s=""):
        print(s, flush=True)
        lines.append(str(s))
        out.write_text("\n".join(lines), encoding="utf-8")

    log(f"=== Diagnóstico LMU Coach {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
    log(f"Python {sys.version.split()[0]} · {platform.platform()}")

    # ---------------------------------------------------------------- voz
    log("\n--- VOZ ---")
    try:
        import pythoncom  # noqa: F401
        import win32com.client
        log("pywin32: OK")
        v = win32com.client.Dispatch("SAPI.SpVoice")
        vs = v.GetVoices()
        for i in range(vs.Count):
            log(f"  voz SAPI: {vs.Item(i).GetDescription()}")
        from .voice import _Sapi
        s = _Sapi(voice=cfg["voz"]["voz"], rate=cfg["voz"]["velocidad"], volume=cfg["voz"]["volumen"])
        log(f"  voz elegida: {s.v.Voice.GetDescription()}")
        s.speak("Radio check. Prueba de voz del ingeniero.")
        t0 = time.time()
        while s.busy() and time.time() - t0 < 8:
            time.sleep(0.1)
        log("  habló (síncrono) OK")
    except Exception:  # noqa: BLE001
        log("ERROR voz SAPI:\n" + traceback.format_exc())
        try:
            import pyttsx3
            e = pyttsx3.init()
            log("pyttsx3 voces: " + ", ".join(x.name for x in e.getProperty("voices")))
        except Exception:  # noqa: BLE001
            log("ERROR pyttsx3:\n" + traceback.format_exc())

    # ---------------------------------------------------------------- LMU
    log("\n--- LE MANS ULTIMATE ---")
    try:
        r = subprocess.run(["tasklist"], capture_output=True, text=True, errors="ignore", timeout=10)
        procs = [ln.split()[0] for ln in r.stdout.splitlines() if "le mans" in ln.lower() or "lmu" in ln.lower()]
        log("Procesos LMU: " + (", ".join(procs) if procs else "NINGUNO (¿el juego está abierto?)"))
    except Exception as e:  # noqa: BLE001
        log(f"tasklist falló: {e}")
    try:
        from .sources.lmu import LMUSource
        from .vendor.pyLMUSharedMemory import lmu_data as D
        src = LMUSource()
        ok = src.connect()
        o = src._obj
        si = o.scoring.scoringInfo
        log(f"Mapa LMU_Data abierto (tamaño {ctypes.sizeof(D.LMUObjectOut)}). alive={ok}")
        log(f"gameVersion={o.generic.gameVersion}  eventos telemetría={o.generic.events.SME_UPDATE_TELEMETRY} "
            f"scoring={o.generic.events.SME_UPDATE_SCORING}")
        log(f"numVehicles={si.mNumVehicles} activeVehicles={o.telemetry.activeVehicles} "
            f"playerHasVehicle={o.telemetry.playerHasVehicle} playerIdx={o.telemetry.playerVehicleIdx}")
        log(f"inRealtime={si.mInRealtime} session={si.mSession} phase={si.mGamePhase} "
            f"track='{si.mTrackName.decode(errors='ignore')}' lapDist={si.mLapDist:.0f}")
        if o.generic.gameVersion == 0 and si.mNumVehicles == 0:
            log(">>> El mapa está VACÍO: activa en LMU  Settings → Gameplay → Enable Plugins = ON  y reinicia el juego.")
        log(f"\nMuestreo {seconds} s (sal a pista y conduce):")
        for _ in range(seconds):
            f = src.read()
            if f is None:
                log("  sin auto del jugador (playerHasVehicle=0 o en menú)")
            else:
                log(f"  t={f.t:8.1f} lap={f.lap} dist={f.dist:7.0f}/{f.track_len:.0f} v={f.kmh:5.0f} "
                    f"T={f.throttle:.2f} F={f.brake:.2f} realtime={f.in_realtime} pits={f.in_pits} "
                    f"track='{f.track}' car='{f.car}' clase='{f.car_class}'")
            time.sleep(1)
    except Exception:  # noqa: BLE001
        log("ERROR leyendo LMU:\n" + traceback.format_exc())
    log(f"\nGuardado en {out}")
    return out
