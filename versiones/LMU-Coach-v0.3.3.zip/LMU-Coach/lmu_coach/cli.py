"""LMU Race Coach — línea de comandos.

  python -m lmu_coach run            Coach en vivo con Le Mans Ultimate
  python -m lmu_coach demo           Demo con pista sintética (sin el juego)
  python -m lmu_coach debrief [ses]  Análisis post-sesión + sugerencias de setup
  python -m lmu_coach voces          Lista las voces TTS instaladas
"""

from __future__ import annotations

import argparse
import sys
import time

from . import config as C
from .coach.engine import CoachEngine
from .coach.messages import MessageQueue
from .voice import Voice, make_backend


def _status(f, eng) -> str:
    ref = f"ref {eng.ref.lap_time:6.2f}s" if eng.ref else "sin ref"
    return (f"\rV{f.lap:<3} {f.dist:7.0f} m  {f.kmh:5.0f} km/h  G{f.gear}  "
            f"T{f.throttle * 100:3.0f} F{f.brake * 100:3.0f}  {ref}  "
            f"{'🎙' if eng.safe else '  '}   ")


def _file_logger(cfg):
    path = C.data_dir(cfg) / "coach.log"
    fh = open(path, "a", encoding="utf-8")

    def log(msg, echo=False):
        fh.write(time.strftime("%H:%M:%S ") + str(msg) + "\n")
        fh.flush()
        if echo:
            print(msg, flush=True)
    return log


def loop(src, cfg, voice_backend=None, status=True, max_frames=None, on_end=None) -> CoachEngine:
    flog = _file_logger(cfg)
    flog(f"=== inicio ({src.name}) ===")
    sim_clock = [0.0]
    q = MessageQueue(clock=(lambda: sim_clock[0]) if src.name != "lmu" else time.monotonic)
    eng = CoachEngine(cfg, q, C.data_dir(cfg), log=lambda m: (flog(m), None if status else print(m)))
    v = Voice(q, eng.can_speak, voice_backend or cfg["voz"]["backend"], cfg["voz"]["voz"],
              cfg["voz"]["velocidad"], cfg["voz"]["volumen"])
    v.start()
    v.ready.wait(5)
    flog(f"voz: backend={type(v.backend).__name__}")
    print(f"Voz: {type(v.backend).__name__.strip('_')}", flush=True)
    last_state = 0.0
    last_cars = [-1e9]
    period = 1.0 / float(cfg["lectura"]["hz"])
    n = 0
    last_t = None
    try:
        while True:
            f = src.read()
            if f is None:
                if src.name != "lmu":
                    break
                if time.monotonic() - last_state > 10:
                    last_state = time.monotonic()
                    flog("sin auto del jugador (menú/garaje)")
                time.sleep(0.5)
                if not src.alive():
                    print("\nLMU cerrado. Esperando...")
                continue
            if f.t != last_t:
                last_t = f.t
                sim_clock[0] = f.t
                eng.on_frame(f)
                if hasattr(src, "read_cars") and (f.t - last_cars[0] >= 0.5 or f.t < last_cars[0]):
                    last_cars[0] = f.t
                    try:
                        eng.on_cars(src.read_cars(), f)
                    except Exception as ex:  # noqa: BLE001
                        flog(f"error rivales: {ex}")
                if time.monotonic() - last_state > 10:
                    last_state = time.monotonic()
                    flog(f"estado lap={f.lap} dist={f.dist:.0f}/{f.track_len:.0f} v={f.kmh:.0f} realtime={f.in_realtime} "
                         f"pits={f.in_pits} track='{f.track}' car='{f.car}' ref={'si' if eng.ref else 'no'} safe={eng.safe}")
                if status and n % 10 == 0:
                    sys.stdout.write(_status(f, eng))
                    sys.stdout.flush()
            n += 1
            if max_frames and n >= max_frames:
                break
            if src.name == "lmu":
                time.sleep(period)
    except KeyboardInterrupt:
        print("\nDetenido.")
    finally:
        path = eng.close()
        time.sleep(1.0)
        v.stop()
        if path:
            print(f"\nSesión guardada en: {path}")
            print(f"Debrief:  python -m lmu_coach debrief \"{path.parent}\"")
        if on_end:
            on_end(eng)
    return eng


def cmd_run(a, cfg):
    from .sources.lmu import LMUSource, wait_for_game
    src = LMUSource()
    wait_for_game(src)
    print(f"Conectado a Le Mans Ultimate (build {src.game_version()}). Ctrl+C para salir.")
    loop(src, cfg, a.voz)


def cmd_demo(a, cfg):
    from .sources.synthetic import SyntheticSource
    cfg["datos"]["carpeta"] = str(C.data_dir(cfg) / "demo")
    src = SyntheticSource(laps=a.vueltas, speed=a.velocidad, realtime=not a.rapido, session=1)
    print(f"Demo: pista sintética {src.tr.length:.0f} m, {a.vueltas} vueltas a x{a.velocidad}. "
          "El piloto virtual comete errores a propósito.")
    loop(src, cfg, a.voz, status=not a.rapido)


def cmd_debrief(a, cfg):
    from .debrief.report import run_debrief
    run_debrief(cfg, a.sesion, use_ai=not a.sin_ia, setup=a.setup, speak=a.hablar)


def cmd_diag(a, cfg):
    from .diag import run
    run(cfg, C.data_dir(cfg), a.segundos)


def cmd_voces(a, cfg):
    b = make_backend(a.voz or cfg["voz"]["backend"])
    for n in b.voices():
        print(" -", n)
    b.speak("Hola, soy tu ingeniero de pista. Radio check.")
    time.sleep(3)


def main(argv=None):
    for st in (sys.stdout, sys.stderr):
        try:
            st.reconfigure(errors="replace")
        except Exception:  # noqa: BLE001
            pass
    p = argparse.ArgumentParser(prog="lmu_coach", description="Race coach por voz para Le Mans Ultimate")
    p.add_argument("--config", help="ruta a config.toml")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("gui", help="abrir la aplicación (por defecto)")
    r = sub.add_parser("run", help="coach en vivo")
    r.add_argument("--voz", help="backend de voz: auto|sapi|pyttsx3|console")
    d = sub.add_parser("demo", help="demo sin el juego")
    d.add_argument("--vueltas", type=int, default=6)
    d.add_argument("--velocidad", type=float, default=4.0, help="multiplicador de tiempo")
    d.add_argument("--rapido", action="store_true", help="sin esperar tiempo real")
    d.add_argument("--voz")
    b = sub.add_parser("debrief", help="análisis post-sesión")
    b.add_argument("sesion", nargs="?", help="carpeta o session.json (por defecto la última)")
    b.add_argument("--setup", help="archivo .svm del setup usado (opcional, mejora la IA)")
    b.add_argument("--sin-ia", action="store_true", help="solo análisis local")
    b.add_argument("--hablar", action="store_true", help="leer el resumen en voz alta")
    v = sub.add_parser("voces", help="listar voces y probar")
    v.add_argument("--voz")
    g = sub.add_parser("diag", help="diagnóstico de voz y conexión con LMU")
    g.add_argument("--segundos", type=int, default=15)
    a = p.parse_args(argv)
    if a.cmd in (None, "gui"):
        from .app.main import main as gui_main
        gui_main()
        return
    cfg = C.load(a.config)
    C.load_secret(cfg)
    {"run": cmd_run, "demo": cmd_demo, "debrief": cmd_debrief, "voces": cmd_voces, "diag": cmd_diag}[a.cmd](a, cfg)


if __name__ == "__main__":
    main()
