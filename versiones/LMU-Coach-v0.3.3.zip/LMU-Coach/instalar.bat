@echo off
setlocal
cd /d "%~dp0"
echo === LMU Race Coach: instalacion / actualizacion ===
set "PY="
if exist ".venv\Scripts\python.exe" goto deps
py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul && set "PY=python"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY (
  echo No se encontro Python 3.11+. Instalando Python 3.12 con winget...
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PY (
  echo ERROR: no pude instalar Python. Instalalo desde https://www.python.org/downloads/ y vuelve a ejecutar.
  pause
  exit /b 1
)
"%PY%" -m venv .venv 2>nul || %PY% -m venv .venv
:deps
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python -c "import lmu_coach, PySide6; print('OK', lmu_coach.__version__)" && echo INSTALACION OK > instalacion_ok.txt
echo Creando acceso directo en el Escritorio...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'LMU Race Coach.lnk'));" ^
 "$s.TargetPath='%~dp0.venv\Scripts\pythonw.exe'; $s.Arguments='-m lmu_coach'; $s.WorkingDirectory='%~dp0';" ^
 "$s.IconLocation='%~dp0assets\icon.ico'; $s.Description='LMU Race Coach'; $s.Save()"
echo.
echo === Listo. Abre "LMU Race Coach" desde el Escritorio. ===
pause
