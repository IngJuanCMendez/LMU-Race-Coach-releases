"""Pruebas: lector binario LMU_Data, motor de coaching y debrief.

En Linux el lector usa /dev/shm/LMU_Data, así que podemos escribir la misma
estructura binaria que publica LMU y leerla con el código real.
"""
import ctypes
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from lmu_coach import config as C
from lmu_coach.coach.engine import CoachEngine
from lmu_coach.coach.messages import MessageQueue, say_delta, say_laptime
from lmu_coach.sources.synthetic import SyntheticSource
from lmu_coach.vendor.pyLMUSharedMemory import lmu_data as D


def test_struct_sizes():
    assert ctypes.sizeof(D.LMUScoringInfo) == 548
    assert ctypes.sizeof(D.LMUVehicleScoring) == 584
    assert ctypes.sizeof(D.LMUVehicleTelemetry) == 1888
    assert ctypes.sizeof(D.LMUWheel) == 260
    assert ctypes.sizeof(D.LMUObjectOut) == 324_820


def test_voice_format():
    assert say_laptime(92.34) == "1 32 punto 3"
    assert say_laptime(59.96) == "1 00 punto 0"
    assert say_delta(0.3) == "más 3 décimas"
    assert say_delta(-0.1) == "menos una décima"


class ShmWriter:
    """Escribe Frames sintéticos en /dev/shm/LMU_Data con el layout binario de LMU."""

    def __init__(self):
        from lmu_coach.vendor.pyLMUSharedMemory._common import platform_mmap
        self.mm = platform_mmap("LMU_Data", ctypes.sizeof(D.LMUObjectOut))
        self.o = D.LMUObjectOut.from_buffer(self.mm)
        self.o.generic.gameVersion = 14000
        self.o.scoring.scoringInfo.mNumVehicles = 1
        self.o.telemetry.activeVehicles = 1
        self.o.telemetry.playerVehicleIdx = 0
        self.o.telemetry.playerHasVehicle = 1
        self.o.scoring.vehScoringInfo[0].mIsPlayer = 1
        self.last_scoring = -1.0

    def write(self, f):
        t = self.o.telemetry.telemInfo[0]
        t.mElapsedTime = f.t
        t.mLapNumber = f.lap
        t.mLapStartET = f.lap_start_t
        t.mTrackName = f.track.encode()
        t.mVehicleModel = f.car.encode()
        t.mLocalVel.z = -f.speed
        t.mUnfilteredThrottle = f.throttle
        t.mUnfilteredBrake = f.brake
        t.mUnfilteredSteering = f.steer
        t.mLocalAccel.x = f.lat_g * 9.81
        t.mGear = f.gear
        t.mFuel = f.fuel
        t.mFuelCapacity = f.fuel_cap
        t.mVirtualEnergy = f.virtual_energy
        t.mFrontRideHeight = f.ride_h_front
        t.mRearRideHeight = f.ride_h_rear
        for i in range(4):
            w = t.mWheels[i]
            for j in range(3):
                w.mTemperature[j] = f.tyre_temp[i][j] + 273.15
            w.mOptimalTemp = f.tyre_opt[i] + 273.15
            w.mPressure = f.tyre_press[i]
            w.mWear = f.tyre_wear[i]
            w.mBrakeTemp = f.brake_temp[i] + 273.15
            w.mLongitudinalGroundVel = -f.speed
            w.mLateralGroundVel = f.speed * __import__("math").tan(__import__("math").radians(f.slip_angle[i]))
        si = self.o.scoring.scoringInfo
        si.mInRealtime = 1
        si.mSession = f.session
        si.mGamePhase = f.game_phase
        si.mLapDist = f.track_len
        si.mTrackName = f.track.encode()
        si.mSessionTimeRemaining = f.time_remaining
        # scoring a 5 Hz, como el juego
        if f.t - self.last_scoring >= 0.2:  # sin forzar en cambio de vuelta: datos viejos como en el juego
            self._lap = f.lap
            self.last_scoring = f.t
            si.mCurrentET = f.t
            vs = self.o.scoring.vehScoringInfo[0]
            vs.mLapDist = f.dist
            vs.mVehicleClass = f.car_class.encode()
            vs.mPlace = f.place

    def close(self):
        self.o = None
        self.mm.close()
        Path("/dev/shm/LMU_Data").unlink(missing_ok=True)


def run_engine(frames_iter, tmp):
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tmp), log=said.append)
    for f in frames_iter:
        clk[0] = f.t
        eng.on_frame(f)
    path = eng.close()
    return said, path


def test_lmu_reader_end_to_end():
    if sys.platform == "win32":
        return  # en Windows /dev/shm no existe; se prueba con el juego real
    from lmu_coach.sources.lmu import LMUSource
    tmp = tempfile.mkdtemp()
    w = ShmWriter()
    src = LMUSource()
    assert src.connect() and src.game_version() == 14000
    synth = SyntheticSource(laps=5, realtime=False, hz=50)

    def frames():
        while (f := synth.read()) is not None:
            w.write(f)
            g = src.read()
            assert g is not None
            assert abs(g.speed - f.speed) < 1e-6
            assert abs(g.tyre_temp[0][2] - f.tyre_temp[0][2]) < 1e-6
            assert abs(g.dist - f.dist) < 25, (g.dist, f.dist)  # interpolación 5 Hz → 50 Hz
            yield g

    said, path = run_engine(frames(), tmp)
    src.close()
    w.close()
    txt = "\n".join(said)
    print(txt)
    assert "Vuelta de referencia" in txt
    assert "Curva 4: frenaste" in txt          # frenada temprana sembrada en vuelta 3
    assert "Curva 1: frenaste" in txt and "tarde" in txt  # frenada tardía vuelta 4
    assert "Curva 6" in txt                     # vértice lento vuelta 4
    assert "Curva 4, aguanta" in txt  # aviso anticipado
    shutil.rmtree(tmp)


def test_debrief_and_advice():
    from lmu_coach.debrief.analysis import analyze
    from lmu_coach.debrief.setup_advisor import advise
    tmp = tempfile.mkdtemp()
    synth = SyntheticSource(laps=6, realtime=False, hz=40)
    said, path = run_engine(iter(synth.read, None), tmp)
    sess = json.loads(path.read_text())
    a = analyze(sess, path.parent)
    assert a["laps_valid"] >= 5
    assert abs(a["ideal_lap"] - a["best"]) < 0.05   # la vuelta limpia es la mejor en todas las curvas
    assert a["corners"][0]["avg_loss"] > 0.05
    adv = advise(a)
    assert any("Balance" in x["area"] for x in adv)  # el simulador tiene subviraje
    shutil.rmtree(tmp)


def test_race_fuel_messages():
    tmp = tempfile.mkdtemp()
    synth = SyntheticSource(laps=6, realtime=False, hz=30, session=10,
                            error_plan={i: [] for i in range(1, 7)})
    said, _ = run_engine(iter(synth.read, None), tmp)
    txt = "\n".join(said)
    assert "Combustible" in txt or "Energía" in txt or "ahorra" in txt
    shutil.rmtree(tmp)


def test_race_rivals_aids_and_debrief():
    """Carrera con rivales, bloqueos y patinaje: info de rivales, asesor ABS/TC y debrief."""
    from lmu_coach.debrief.analysis import analyze
    from lmu_coach.debrief.report import build_markdown
    from lmu_coach.debrief.setup_advisor import advise
    from lmu_coach.sources.synthetic import CornerError as E
    tmp = tempfile.mkdtemp()
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tmp), log=said.append)
    plan = {1: [], 2: [], 3: [E("lock", 0)], 4: [E("lock", 0)], 5: [], 6: [], 7: [E("spin", 1)], 8: [E("spin", 1)],
            9: [E("spin", 1)], 10: [], 11: []}
    src = SyntheticSource(laps=11, realtime=False, hz=30, session=10, error_plan=plan)
    last = -9.0
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
        if f.t - last >= 0.5:
            last = f.t
            eng.on_cars(src.read_cars(), f)
    path = eng.close()
    txt = "\n".join(said)
    assert "P2 de 4" in txt and "Porsche" in txt and "se escapa" in txt
    assert "entra a pits" in txt
    assert "Hypercar más rápido" in txt
    assert "Sube el ABS a 5" in txt
    assert "Sube TC Slip a 5" in txt
    a = analyze(json.loads(path.read_text()), path.parent)
    assert a["brake_refs"] and a["car_aids"]["lock_f"] > 0
    md = build_markdown(a, advise(a), None)
    assert "Referencias de frenada" in md and "Ayudas y reparto" in md
    shutil.rmtree(tmp)



def test_chat_levels_and_focus_cues():
    """Nivel 0 calla todo salvo peligro; nivel 3 avisa antes de curvas con potencial."""
    from lmu_coach.sources.synthetic import CornerError as E
    counts = {}
    for lvl in (0, 2, 3):
        cfg = C.load()
        cfg["coach"]["charla"] = lvl
        clk = [0.0]
        q = MessageQueue(clock=lambda: clk[0])
        said = []
        eng = CoachEngine(cfg, q, Path(tempfile.mkdtemp()), log=said.append, save=False)
        plan = {i: [E("slow_apex", 2)] for i in range(3, 8)}
        plan[1] = []
        plan[2] = []
        src = SyntheticSource(laps=7, realtime=False, hz=30, error_plan=plan)
        while (f := src.read()) is not None:
            clk[0] = f.t
            eng.on_frame(f)
        spoken = [x for x in said if not x.startswith("[silenciado")]
        counts[lvl] = (len(spoken), sum(1 for x in spoken if x.startswith("[AVISO]")))
    assert counts[0][0] == 0
    assert counts[2][1] == 0 and counts[2][0] > 0
    assert counts[3][1] >= 3



def test_aids_margin_and_experiment():
    """ABS actuando mucho sin bloqueos → sugiere bajarlo; al cambiarlo, compara y da veredicto."""
    from lmu_coach.sources.synthetic import CornerError as E
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tempfile.mkdtemp()), log=said.append, save=False)
    src = SyntheticSource(laps=15, realtime=False, hz=25, error_plan={i: [E("abs_heavy", 0)] for i in range(1, 16)})
    src.settings_by_lap = {i: {"abs_level": 3} for i in range(11, 16)}
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
    txt = "\n".join(said)
    assert "Prueba ABS 3" in txt
    assert "Anotado: ABS de 4 a 3" in txt
    assert "Con ABS 3" in txt


def test_incident_filtered_and_rival_names():
    from lmu_coach.coach.rivals import Car
    assert Car(0, "x", "Proton Competition #77:LM", "GT3", 1, 0, 0, False, 0, 0, 0, False).short == "Proton número 77"
    assert Car(0, "x", "Akkodis ASP Team #87:LM", "GT3", 1, 0, 0, False, 0, 0, 0, False).short == "Akkodis número 87"



def test_guided_tuning_covers_bias_tc_cut_slip():
    """Sin problemas visibles, en práctica recorre reparto, ABS, TC Cut y TC Slip."""
    from lmu_coach.sources.synthetic import CornerError as E
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tempfile.mkdtemp()), log=said.append, save=False)
    src = SyntheticSource(laps=22, realtime=False, hz=25,
                          error_plan={i: [E("abs_heavy", 0), E("tc_heavy", 0)] for i in range(1, 23)})
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
    txt = "\n".join(said)
    assert "reparto en 55 punto 5" in txt
    assert "Prueba ABS 3" in txt
    assert "TC Cut 2" in txt
    assert "TC Slip 3" in txt


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("OK", name)
