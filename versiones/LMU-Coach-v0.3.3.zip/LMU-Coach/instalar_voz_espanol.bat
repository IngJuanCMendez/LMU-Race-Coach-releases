@echo off
:: Instala las voces de Windows en espanol (Mexico y Espana). Pide permisos de administrador.
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo === Instalando voces en espanol para Windows (puede tardar unos minutos) ===
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$caps = 'Language.TextToSpeech~~~es-MX~0.0.1.0','Language.TextToSpeech~~~es-ES~0.0.1.0','Language.Speech~~~es-MX~0.0.1.0','Language.Speech~~~es-ES~0.0.1.0';" ^
 "foreach ($c in $caps) { Write-Host ('Instalando ' + $c); try { Add-WindowsCapability -Online -Name $c -ErrorAction Stop | Out-Null; Write-Host '  OK' -ForegroundColor Green } catch { Write-Host ('  No disponible: ' + $_.Exception.Message) -ForegroundColor Yellow } };" ^
 "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer;" ^
 "Write-Host ''; Write-Host 'Voces disponibles:'; $s.GetInstalledVoices() | ForEach-Object { Write-Host (' - ' + $_.VoiceInfo.Name + ' (' + $_.VoiceInfo.Culture + ')') }"
echo.
echo Listo. Abre LMU Race Coach y prueba la voz en la seccion Coach.
pause
