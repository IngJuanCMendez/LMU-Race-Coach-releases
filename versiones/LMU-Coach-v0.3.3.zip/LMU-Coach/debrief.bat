@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m lmu_coach debrief %*
pause
