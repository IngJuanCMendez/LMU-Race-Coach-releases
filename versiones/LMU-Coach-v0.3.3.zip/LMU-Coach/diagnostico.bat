@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m lmu_coach diag --segundos 20
pause
