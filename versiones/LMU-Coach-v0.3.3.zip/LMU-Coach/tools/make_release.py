"""Crea el zip de una versión para publicarlo como release en GitHub (o compartirlo).

Uso:  python tools/make_release.py   → dist/LMU-Coach-vX.Y.Z.zip
Luego en GitHub: Releases → Draft new release → tag vX.Y.Z → adjunta el zip → Publish.
La app de cada usuario lo detecta en Ajustes → Buscar actualizaciones.
"""
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from lmu_coach import __version__  # noqa: E402

INCLUDE = ["lmu_coach", "assets", "tests", "tools", "README.md", "requirements.txt", "instalar.bat", "abrir_app.bat",
           "instalar_voz_espanol.bat", "iniciar_coach.bat", "demo.bat", "debrief.bat", "probar_voz.bat", "diagnostico.bat"]

out = ROOT / "dist" / f"LMU-Coach-v{__version__}.zip"
out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for name in INCLUDE:
        p = ROOT / name
        if not p.exists():
            continue
        files = [p] if p.is_file() else [f for f in p.rglob("*") if f.is_file() and "__pycache__" not in f.parts]
        for f in files:
            z.write(f, Path("LMU-Coach") / f.relative_to(ROOT))
print(out)
