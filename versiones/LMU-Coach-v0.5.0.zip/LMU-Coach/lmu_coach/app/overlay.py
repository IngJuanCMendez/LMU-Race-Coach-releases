"""Overlay: ventana pequeña, transparente y siempre encima del juego.

Funciona con LMU en modo ventana o "ventana sin bordes" (en pantalla completa exclusiva
Windows no deja dibujar encima). Se arrastra con el mouse; la posición se guarda.
"""

from __future__ import annotations

from PySide6.QtCore import QPoint, Qt
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from . import theme as T


class Overlay(QWidget):
    def __init__(self, win):
        super().__init__(None, Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint | Qt.Tool)
        self.win = win
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        c = win.cfg["overlay"]
        self.setWindowOpacity(float(c.get("opacidad", 0.85)))
        self.move(int(c.get("x", 40)), int(c.get("y", 40)))
        box = QWidget(self)
        box.setObjectName("ov")
        box.setStyleSheet(f"#ov {{ background: rgba(14,16,20,215); border: 1px solid {T.BORDER}; border-radius: 12px; }}"
                          f"QLabel {{ color: {T.TEXT}; background: transparent; }}")
        lay = QVBoxLayout(box)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(2)
        self.delta = QLabel("—")
        self.delta.setStyleSheet("font-size: 34px; font-weight: 800; font-family: Consolas, monospace;")
        self.tip = QLabel("")
        self.tip.setStyleSheet(f"font-size: 14px; color: {T.ACCENT}; font-weight: 600;")
        self.tip.setWordWrap(True)
        self.info = QLabel("")
        self.info.setStyleSheet(f"font-size: 12px; color: {T.MUTED};")
        for w in (self.delta, self.tip, self.info):
            lay.addWidget(w)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(box)
        self.setFixedWidth(300)
        self._drag = None

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None
        self.win.cfg["overlay"].update(x=self.x(), y=self.y())
        self.win.save_cfg()

    def refresh(self):
        r = self.win.runner
        e = r.engine if r else None
        if not e or e.last_frame is None:
            self.delta.setText("—")
            self.tip.setText("")
            self.info.setText("Esperando datos del auto…")
            return
        st = e.state()
        f = st["frame"]
        dl = st.get("delta")
        if dl is None:
            self.delta.setText("—")
            self.delta.setStyleSheet("font-size: 34px; font-weight: 800; font-family: Consolas, monospace;")
        else:
            col = T.TEXT if abs(dl) < 0.05 else (T.GOOD if dl < 0 else T.BAD)
            self.delta.setText(f"{dl:+.2f}")
            self.delta.setStyleSheet(f"font-size: 34px; font-weight: 800; font-family: Consolas, monospace; color: {col};")
        self.tip.setText(e.next_tip())
        rv = st["rivals"]
        parts = []
        if rv.get("class_pos"):
            parts.append(f"P{rv['class_pos']}/{rv['n_class']}")
            if rv.get("gap_ahead") is not None:
                parts.append(f"▲ {rv['gap_ahead']:.1f}")
            if rv.get("gap_behind") is not None:
                parts.append(f"▼ {rv['gap_behind']:.1f}")
        if st["fuel_laps"]:
            parts.append(f"⛽ {st['fuel_laps']:.1f} v")
        parts.append(f"V{f.lap}")
        self.info.setText("   ".join(parts))
        self.adjustSize()

    def closeEvent(self, ev):
        self.win.cfg["overlay"].update(x=self.x(), y=self.y())
        ev.accept()


__all__ = ["Overlay", "QPoint"]
