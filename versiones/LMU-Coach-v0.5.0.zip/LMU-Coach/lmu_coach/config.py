"""Configuración: valores por defecto + config.toml del usuario."""

from __future__ import annotations

import copy
import tomllib
from pathlib import Path

DEFAULTS = {
    "voz": {"backend": "auto", "voz": "", "velocidad": 1, "volumen": 100},
    "coach": {
        "charla": 3,                     # 0 Silencio · 1 Mínimo · 2 Ingeniero · 3 Coach · 4 Máximo (práctica/clasif.)
        "charla_carrera": 2,             # nivel en carrera
        "avisos_anticipados": True,
        "anticipacion_s": 3.0,
        "perdida_minima_s": 0.08,
        "perdida_minima_carrera_s": 0.15,
        "felicitar": True,
        "umbral_frenada_m": 8.0,
        "umbral_vel_min_kmh": 3.0,
        "umbral_acelerador_m": 12.0,
        "umbral_bloqueo": 0.20,
        "umbral_patinaje": 0.20,
        "tc_mas_alto_mas_ayuda": True,
        "ajuste_guiado": True,           # en práctica, el coach propone y mide cambios de TC/TC Slip/TC Cut/reparto
    },
    "rivales": {"brecha_pelea_s": 1.0},
    "estrategia": {"desgaste_critico": 0.35, "margen_vueltas": 0.5},
    "llantas": {"ventana_c": 8.0, "optima_por_defecto_c": 85.0},
    "combustible": {"avisar_vueltas": 5},
    "ia": {"habilitada": True, "modelo": "claude-sonnet-5-5", "modelo_radio": "claude-haiku-5-5", "max_tokens": 2500},
    "datos": {"carpeta": "datos"},
    "lectura": {"hz": 60},
    "hablar": {"habilitado": False, "dispositivo": "teclado", "tecla": 0x14, "joystick": 0, "boton": 0,
               "ventana_s": 2.0, "preguntas_libres": True},
    "overlay": {"x": 40, "y": 40, "opacidad": 0.85},
    "celular": {"habilitado": False, "puerto": 8765},
    "piloto": {"nombre": ""},
    "actualizaciones": {"repo": "IngJuanCMendez/LMU-Race-Coach-releases", "auto": True},
}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load(path: str | Path | None = None) -> dict:
    p = Path(path) if path else Path(__file__).resolve().parent.parent / "config.toml"
    if p.exists():
        with open(p, "rb") as fh:
            return _merge(DEFAULTS, tomllib.load(fh))
    return copy.deepcopy(DEFAULTS)


def data_dir(cfg: dict) -> Path:
    d = Path(cfg["datos"]["carpeta"])
    if not d.is_absolute():
        d = Path(__file__).resolve().parent.parent / d
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_path() -> Path:
    return Path(__file__).resolve().parent.parent / "config.toml"


def _toml_value(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return repr(v)
    return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"') + '"'


def save(cfg: dict, path: str | Path | None = None) -> Path:
    """Guarda la configuración completa en config.toml (secciones de un nivel)."""
    p = Path(path) if path else config_path()
    lines = ["# LMU Race Coach — configuración (la app la reescribe al guardar desde la interfaz)", ""]
    for sec, vals in cfg.items():
        if not isinstance(vals, dict):
            continue
        lines.append(f"[{sec}]")
        for k, v in vals.items():
            lines.append(f"{k} = {_toml_value(v)}")
        lines.append("")
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


def secret_path(cfg: dict) -> Path:
    return data_dir(cfg) / ".anthropic_key"


def load_secret(cfg: dict) -> None:
    """Carga la API key guardada desde la app (si no está ya en el entorno)."""
    import os
    p = secret_path(cfg)
    if not os.environ.get("ANTHROPIC_API_KEY") and p.exists():
        key = p.read_text(encoding="utf-8").strip()
        if key:
            os.environ["ANTHROPIC_API_KEY"] = key
