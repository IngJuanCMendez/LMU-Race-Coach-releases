"""LMU Race Coach."""
__version__ = "0.5.0"
