"""Biblioteca de setups: guarda el .svm usado en cada sesión y compara cambios entre sesiones.

LMU guarda los setups en <UserData>/player/Settings/<pista>/*.svm. Al empezar una sesión
se copia el .svm modificado más recientemente (el que el piloto acaba de cargar/guardar).
"""

from __future__ import annotations

import json
import shutil
import time
from pathlib import Path


def settings_dir(user_data: str) -> Path | None:
    if not user_data:
        return None
    p = Path(user_data)
    for cand in (p / "player" / "Settings", p / "Settings", p):
        if cand.exists():
            return cand
    return None


def latest_svm(user_data: str, max_age_h: float = 24.0) -> Path | None:
    base = settings_dir(user_data)
    if base is None:
        return None
    now = time.time()
    best = None
    for f in base.rglob("*.svm"):
        try:
            m = f.stat().st_mtime
        except OSError:
            continue
        if now - m <= max_age_h * 3600 and (best is None or m > best[0]):
            best = (m, f)
    return best[1] if best else None


def snapshot(session_dir: Path, user_data: str, name: str = "setup.svm") -> str | None:
    """Copia el último setup a la carpeta de la sesión. Devuelve el nombre original o None."""
    src = latest_svm(user_data)
    if src is None:
        return None
    dst = Path(session_dir) / name
    try:
        shutil.copy2(src, dst)
        (Path(session_dir) / "setup_info.json").write_text(
            json.dumps({"original": str(src), "name": src.stem, "track_folder": src.parent.name}, ensure_ascii=False),
            encoding="utf-8")
    except OSError:
        return None
    return src.stem


def parse_svm(text: str) -> dict[str, dict[str, str]]:
    """{sección: {parámetro: valor visible}} solo con parámetros ajustables (líneas XSetting=n//texto)."""
    out: dict[str, dict[str, str]] = {}
    sec = "GENERAL"
    for ln in text.splitlines():
        s = ln.strip()
        if s.startswith("[") and s.endswith("]"):
            sec = s[1:-1]
            continue
        if "Setting=" not in s or "//" not in s:
            continue
        key, rest = s.split("=", 1)
        disp = rest.split("//", 1)[1].strip()
        if "Non-adjustable" in disp or "N/A" == disp:
            continue
        out.setdefault(sec, {})[key.replace("Setting", "")] = disp
    return out


def diff_svm(a_text: str, b_text: str) -> list[tuple[str, str, str, str]]:
    a, b = parse_svm(a_text), parse_svm(b_text)
    out = []
    for sec in sorted(set(a) | set(b)):
        for k in sorted(set(a.get(sec, {})) | set(b.get(sec, {}))):
            va, vb = a.get(sec, {}).get(k), b.get(sec, {}).get(k)
            if va != vb:
                out.append((sec, k, va or "—", vb or "—"))
    return out


def previous_session_with_setup(session_dir: Path) -> Path | None:
    """Sesión anterior (misma pista y auto) que tenga setup guardado."""
    session_dir = Path(session_dir)
    try:
        me = json.loads((session_dir / "session.json").read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    cands = []
    for p in session_dir.parent.glob("*/session.json"):
        if p.parent == session_dir or not (p.parent / "setup.svm").exists():
            continue
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        if d.get("track") == me.get("track") and d.get("car") == me.get("car") and p.parent.name < session_dir.name:
            cands.append(p.parent)
    return max(cands) if cands else None


def setup_markdown(session_dir: Path) -> list[str]:
    """Sección del debrief: setup usado y cambios respecto a la sesión anterior."""
    session_dir = Path(session_dir)
    svm = session_dir / "setup.svm"
    if not svm.exists():
        return []
    try:
        info = json.loads((session_dir / "setup_info.json").read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        info = {"name": "setup"}
    L = ["## Setup", "", f"- Usado en esta sesión: **{info.get('name')}**"]
    prev = previous_session_with_setup(session_dir)
    if prev:
        d = diff_svm((prev / "setup.svm").read_text(encoding="utf-8", errors="ignore"),
                     svm.read_text(encoding="utf-8", errors="ignore"))
        try:
            pj = json.loads((prev / "session.json").read_text(encoding="utf-8"))
            pv = [l["time"] for l in pj.get("laps", []) if l.get("valid")]
            pbest = f" (mejor vuelta {min(pv) // 60:.0f}:{min(pv) % 60:06.3f})" if pv else ""
        except Exception:  # noqa: BLE001
            pbest = ""
        if d:
            L += [f"- Cambios respecto a la sesión del {prev.name[:8]}{pbest}:", "",
                  "| Sección | Parámetro | Antes | Ahora |", "|---|---|---|---|"]
            L += [f"| {s} | {k} | {a} | {b} |" for s, k, a, b in d[:30]]
        else:
            L.append(f"- Mismo setup que la sesión del {prev.name[:8]}{pbest}.")
    L.append("")
    return L
