"""Nombres reales de las curvas por circuito.

Plantillas por distancia del vértice desde la meta (m), medidas con LMU. Las curvas
que detecta el coach se emparejan con el nombre más cercano. El piloto puede
renombrar cualquier curva desde la app; eso se guarda en datos/curvas/<pista>.json
y tiene prioridad sobre la plantilla.
"""

from __future__ import annotations

import json
from pathlib import Path

from .coach.track import slug

PRESETS: dict[str, dict] = {
    "circuit_de_spa_francorchamps": {
        "length": 6982,
        "corners": [(276, "La Source"), (1088, "Eau Rouge"), (2290, "Les Combes"), (2550, "Malmedy"),
                    (2944, "Bruxelles"), (3146, "No Name"), (3656, "Pouhon"), (3778, "Pouhon 2"),
                    (4406, "Fagnes"), (4842, "Stavelot"), (5950, "Blanchimont"), (6620, "Bus Stop")],
    },
    "monza_curva_grande_circuit": {
        "length": 5745,
        "corners": [(2118, "Roggia"), (2526, "Lesmo 1"), (2848, "Lesmo 2"), (3884, "Ascari"), (5144, "Parabolica")],
    },
}


def _preset_for(track: str) -> dict | None:
    s = slug(track)
    if s in PRESETS:
        return PRESETS[s]
    for k, v in PRESETS.items():       # nombres con variantes ("…_endurance", etc.)
        if s.startswith(k):
            return v
    return None


def user_file(data_dir: Path, track: str) -> Path:
    return Path(data_dir) / "curvas" / f"{slug(track)}.json"


def load_user(data_dir: Path, track: str) -> dict:
    p = user_file(data_dir, track)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return {}
    return {}


def save_user_name(data_dir: Path, track: str, apex_d: float, name: str) -> None:
    """Guarda el nombre elegido por el piloto, indexado por la distancia del vértice."""
    p = user_file(data_dir, track)
    p.parent.mkdir(parents=True, exist_ok=True)
    d = load_user(data_dir, track)
    key = str(int(round(apex_d / 10) * 10))
    if name.strip():
        d[key] = name.strip()
    else:
        d.pop(key, None)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def corner_names(data_dir: Path, track: str, corners, length: float) -> dict[int, str]:
    """{número de curva: nombre} para las curvas detectadas."""
    out: dict[int, str] = {}
    preset = _preset_for(track)
    used = set()
    if preset:
        scale = length / preset["length"] if preset["length"] else 1.0
        pts = [(d * scale, n) for d, n in preset["corners"]]
        for c in corners:
            best = min(pts, key=lambda p: abs(p[0] - c.apex_d))
            if abs(best[0] - c.apex_d) < 160 and best[1] not in used:
                out[c.num] = best[1]
                used.add(best[1])
    user = load_user(data_dir, track)
    for key, name in user.items():
        try:
            d = float(key)
        except ValueError:
            continue
        near = min(corners, key=lambda c: abs(c.apex_d - d), default=None)
        if near is not None and abs(near.apex_d - d) < 120:
            out[near.num] = name
    return out
