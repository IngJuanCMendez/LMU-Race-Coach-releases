"""Ingeniero de estrategia: paradas, carga de energía/combustible, desgaste de llantas,
degradación de ritmo, undercut/overcut con los rivales y clima.

Trabaja por vuelta (al cerrar cada vuelta) y con eventos (lluvia, pits de rivales).
"""

from __future__ import annotations

import math

from .messages import CRITICAL, HIGH, NORMAL, say_laps, say_tenths


class Strategy:
    def __init__(self, engine, cfg: dict):
        self.e = engine
        self.cfg = cfg
        self.laps: list[dict] = []          # vueltas completas del stint actual (y anteriores)
        self.stint_start_lap = 0
        self.last_pitstops = 0
        self.window_open_said = False
        self.box_said = False
        self.tyres_short_said = False
        self.wet_level = 0                  # 0 seco, 1 húmeda, 2 mojada, 3 muy mojada
        self.rain_on = False
        self.wet_mode = False
        self.plan: dict = {}

    # ------------------------------------------------------------ eventos por frame
    def on_frame(self, f) -> None:
        p = self.e.prev
        if f.num_pitstops > self.last_pitstops:
            self.last_pitstops = f.num_pitstops
            self.stint_start_lap = f.lap
            self.window_open_said = self.box_said = self.tyres_short_said = False
        # lluvia
        rain = f.raining > 0.08
        if rain and not self.rain_on and p is not None:
            self.e.say("Empieza a llover. Frena antes y suave con el acelerador.", CRITICAL, "rain", 60)
        if not rain and self.rain_on and f.raining < 0.02:
            self.e.say("Dejó de llover.", NORMAL, "rain", 60)
        self.rain_on = rain
        lvl = 0 if f.wetness < 0.12 else (1 if f.wetness < 0.3 else (2 if f.wetness < 0.55 else 3))
        if lvl != self.wet_level and p is not None:
            msgs = {0: "La pista ya está seca.", 1: "Pista húmeda: menos agarre en frenadas y pianos.",
                    2: "Pista mojada. Cuidado con los charcos en la trazada.", 3: "Pista muy mojada."}
            if lvl > self.wet_level or lvl == 0:
                self.e.say(msgs[lvl], HIGH, "wet", 45)
            wet_tyre = any(w in (f.compound or "").lower() for w in ("wet", "rain", "lluvia"))
            if lvl >= 2 and not wet_tyre:
                self.e.say("Con esta humedad conviene parar por llantas de lluvia.", HIGH, "wettyre", 120)
            if lvl == 0 and wet_tyre:
                self.e.say("La pista se secó: considera volver a slicks.", HIGH, "wettyre", 120)
            self.wet_level = lvl
        # con pista mojada la referencia seca no sirve para comparar curvas
        self.wet_mode = lvl >= 1 or rain

    def on_rival_pit(self, who: str, car, gap: float | None) -> None:
        """who: 'ahead' | 'behind'."""
        if not self.e.last_frame or not self.e.last_frame.is_race:
            return
        win = self.plan.get("window_open")
        if who == "ahead":
            self.e.say(f"{car.short} paró. Empuja estas vueltas para ganarle con el overcut.", HIGH, "strat", 30)
        elif who == "behind":
            if gap is not None and gap < 3.0:
                tail = " Tu ventana está abierta: entra la próxima vuelta para cubrirlo." if win else ""
                self.e.say(f"{car.short} paró detrás de ti. Cuidado con el undercut.{tail}", HIGH, "strat", 30)
            else:
                self.e.say(f"El de atrás, {car.short}, paró.", NORMAL, "strat", 30)

    # ------------------------------------------------------------ por vuelta
    def end_lap(self, f, summary: dict) -> None:
        if not summary.get("complete") or summary.get("pits"):
            return
        wear = summary.get("tyre_wear") or [0] * 4
        self.laps.append({"lap": summary["lap"], "time": summary["time"], "valid": summary["valid"],
                          "fuel": summary.get("fuel_used", 0), "ve": summary.get("ve_used") or 0,
                          "wear": list(wear), "stint_lap": summary["lap"] - self.stint_start_lap})
        self._tyres(f)
        if f.is_race:
            self._pit_plan(f)

    def _stint(self) -> list[dict]:
        return [x for x in self.laps if x["lap"] >= self.stint_start_lap and x["fuel"] > 0]

    def wear_rate(self) -> float | None:
        """Desgaste medio por vuelta (fracción) de la llanta más gastada, últimas vueltas del stint."""
        st = self._stint()
        if len(st) < 3:
            return None
        a, b = st[-4] if len(st) >= 4 else st[0], st[-1]
        n = b["lap"] - a["lap"]
        if n <= 0:
            return None
        drops = [(a["wear"][i] - b["wear"][i]) / n for i in range(4)]
        return max(drops) if max(drops) > 0 else None

    def degradation(self) -> float | None:
        """Pérdida de ritmo por vuelta en el stint (s/vuelta), regresión sobre vueltas válidas."""
        st = [x for x in self._stint() if x["valid"]]
        if len(st) < 5:
            return None
        xs = [x["stint_lap"] for x in st]
        ys = [x["time"] for x in st]
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        den = sum((x - mx) ** 2 for x in xs)
        if den == 0:
            return None
        return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den

    def laps_to_go(self, f, avg_t: float) -> int | None:
        if 0 < f.max_laps < 10000:
            return max(0, f.max_laps - f.lap)
        if f.time_remaining > 0 and avg_t > 0:
            return math.ceil(f.time_remaining / avg_t)
        return None

    def _tyres(self, f) -> None:
        rate = self.wear_rate()
        if not rate:
            return
        worst = min(f.tyre_wear) if f.tyre_wear else 1.0
        crit = float(self.cfg.get("desgaste_critico", 0.35))
        laps_left = max(0.0, (worst - crit) / rate)
        self.plan["tyre_laps"] = laps_left
        st = [x for x in self._stint() if x["valid"]]
        avg_t = sum(x["time"] for x in st[-3:]) / len(st[-3:]) if st else 0
        to_go = self.laps_to_go(f, avg_t) if f.is_race else None
        deg = self.degradation()
        self.plan["degradation"] = deg
        if laps_left < 2.5:
            self.e.say(f"Llantas muy gastadas: quedan unas {say_laps(max(1, round(laps_left)))} útiles.", HIGH, "tyrewear", 90)
        elif to_go and laps_left < to_go and not self.tyres_short_said:
            self.tyres_short_said = True
            self.e.say(f"Las llantas no llegan al final: aguantan unas {say_laps(round(laps_left))} y faltan {to_go}.",
                       NORMAL, "tyrewear", 120)
        if deg is not None and deg > 0.15 and len(st) % 4 == 0:
            self.e.say(f"Estás perdiendo {say_tenths(deg)} por vuelta por desgaste.", NORMAL, "deg", 240)

    def _pit_plan(self, f) -> None:
        st = self._stint()
        if len(st) < 2:
            return
        h = st[-3:]
        avg_t = sum(x["time"] for x in h) / len(h)
        to_go = self.laps_to_go(f, avg_t)
        if to_go is None:
            return
        use_ve = f.virtual_energy > 0 and all(x["ve"] > 0 for x in h)
        per_lap = (sum(x["ve"] for x in h) / len(h)) if use_ve else (sum(x["fuel"] for x in h) / len(h))
        have = f.virtual_energy if use_ve else f.fuel
        cap = 1.0 if use_ve else (f.fuel_cap or 0)
        if per_lap <= 0 or cap <= 0:
            return
        laps_left = have / per_lap
        margin = float(self.cfg.get("margen_vueltas", 0.5))
        if laps_left >= to_go + margin:
            self.plan.update(stops=0, window_open=False, laps_left=laps_left, to_go=to_go)
            return
        stint_cap = cap / per_lap
        stops = math.ceil((to_go + margin - laps_left) / stint_cap)
        # ventana abierta: si paras ahora, una sola carga completa alcanza para terminar
        window_open = (to_go + margin) <= stint_cap
        # carga si paras al final de la próxima vuelta
        rem = max(0.0, have - per_lap)
        add = min(cap - rem, max(0.0, (to_go - 1 + margin) * per_lap - rem))
        self.plan.update(stops=stops, window_open=window_open, laps_left=laps_left, to_go=to_go,
                         add=add, unit="por ciento de energía" if use_ve else "litros")
        if window_open and not self.window_open_said and stops == 1:
            self.window_open_said = True
            amt = f"{add * 100:.0f} por ciento de energía" if use_ve else f"{add:.0f} litros"
            self.e.say(f"Ventana de pits abierta. Para terminar necesitas cargar unos {amt}. "
                       f"Puedes aguantar hasta {say_laps(math.floor(laps_left))} más.", NORMAL, "strat", 60)
        if laps_left < 2.0 and not self.box_said:
            self.box_said = True
            self.e.say("Entra a pits esta vuelta o la próxima.", HIGH, "box", 60)

    def summary_text(self) -> str:
        """Respuesta para «estrategia» por voz."""
        p = self.plan
        parts = []
        if p.get("stops") == 0:
            parts.append(f"Te alcanza para terminar sin parar: tienes para {say_laps(math.floor(p['laps_left']))} y faltan {p['to_go']}.")
        elif p.get("stops"):
            amt = (f"{p['add'] * 100:.0f} por ciento" if p.get("unit", "").startswith("por") else f"{p['add']:.0f} litros")
            parts.append(f"Necesitas {p['stops']} {'parada' if p['stops'] == 1 else 'paradas'}. "
                         f"Puedes aguantar {say_laps(math.floor(p['laps_left']))} y luego cargar unos {amt}.")
        if p.get("tyre_laps") is not None:
            parts.append(f"Las llantas aguantan unas {say_laps(round(p['tyre_laps']))}.")
        if p.get("degradation") is not None and p["degradation"] > 0.05:
            parts.append(f"Degradación de {say_tenths(p['degradation'])} por vuelta.")
        if self.wet_level:
            parts.append(["", "Pista húmeda.", "Pista mojada.", "Pista muy mojada."][self.wet_level])
        return " ".join(parts) or "Todavía no tengo datos suficientes para la estrategia."
