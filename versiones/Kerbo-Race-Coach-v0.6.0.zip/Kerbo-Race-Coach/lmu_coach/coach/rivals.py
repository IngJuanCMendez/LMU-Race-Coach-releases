"""Rivales: posición en clase, brechas, tendencia, defensa/ataque, multiclase y pits."""

from __future__ import annotations

from dataclasses import dataclass, field

from .messages import CRITICAL, HIGH, NORMAL, say_gap

# Orden aproximado de velocidad de clase (fallback si no hay mejores vueltas)
CLASS_SPEED = {"hyper": 5, "lmh": 5, "lmdh": 5, "lmp2": 4, "lmp3": 3, "gte": 2, "gt3": 2, "lmgt3": 2, "gt4": 1}


def class_rank(c: str) -> int:
    c = c.lower().replace(" ", "")
    for k, v in CLASS_SPEED.items():
        if k in c:
            return v
    return 0


@dataclass
class Car:
    id: int
    driver: str
    vehicle: str
    cls: str
    place: int
    laps: int          # vueltas completadas
    lapdist: float
    in_pits: bool
    pitstops: int
    last: float
    best: float
    is_player: bool
    speed: float = 0.0

    @property
    def short(self) -> str:
        """Nombre corto para voz: marca del auto (+ número si viene en el nombre)."""
        import re
        m = re.search(r"#\s*(\d+)", self.vehicle)
        num = f" número {m.group(1)}" if m else ""
        name = re.split(r"\s*#", self.vehicle)[0].strip()
        words = [w for w in re.split(r"[\s_]+", name) if w and not w.isdigit()]
        generic = {"team", "racing", "the", "motorsport", "motorsports", "competition", "by", "and", "de", "-"}
        make = next((w for w in words if w.lower() not in generic), None)
        if not make:
            make = self.driver.split()[-1] if self.driver else "Rival"
        return f"{make}{num}"


@dataclass
class _Hist:
    gap_at_lap: dict = field(default_factory=dict)   # vuelta del jugador -> brecha (s)
    in_pits: bool = False


class RivalTracker:
    def __init__(self, engine, cfg: dict):
        self.e = engine
        self.cfg = cfg
        self.hist: dict[int, _Hist] = {}
        self.class_pos = 0
        self._pending_pos = None
        self._pending_since = 0.0
        self.ahead: Car | None = None
        self.behind: Car | None = None
        self.gap_ahead = None
        self.gap_behind = None
        self._close_ahead = False
        self._close_behind = False
        self._traffic_warned: dict[int, float] = {}
        self.me: Car | None = None
        self.n_class = 0

    # ----------------------------------------------------------------- util
    def _est_lap(self, me: Car) -> float:
        for x in (self.e.best, me.best, me.last):
            if x and x > 0:
                return x
        return 120.0

    def _race_dist(self, c: Car, L: float) -> float:
        return c.laps + (c.lapdist / L if L > 0 else 0.0)

    def _race_time(self, c: Car, L: float, lap_t: float) -> float:
        """Posición en tiempo: vueltas × tiempo de vuelta + tiempo de referencia hasta su distancia."""
        ref = self.e.ref
        t_in = ref.time_at(min(c.lapdist, ref.data["d"][-1])) if ref else None
        if t_in is None:
            t_in = (c.lapdist / L) * lap_t if L > 0 else 0.0
        else:
            t_in *= lap_t / ref.lap_time
        return c.laps * lap_t + t_in

    # ----------------------------------------------------------------- update
    def update(self, cars: list[Car], f) -> None:
        if not cars or f.track_len <= 0:
            return
        me = next((c for c in cars if c.is_player), None)
        if me is None:
            return
        self.me = me
        L = f.track_len
        lap_t = self._est_lap(me)
        same = [c for c in cars if c.cls == me.cls]
        same.sort(key=lambda c: -self._race_dist(c, L))
        self.n_class = len(same)
        pos = same.index(me) + 1
        ahead = same[pos - 2] if pos >= 2 else None
        behind = same[pos] if pos < len(same) else None
        self.ahead, self.behind = ahead, behind
        my_rt = self._race_time(me, L, lap_t)
        self.gap_ahead = (self._race_time(ahead, L, lap_t) - my_rt) if ahead else None
        self.gap_behind = (my_rt - self._race_time(behind, L, lap_t)) if behind else None
        for c in cars:
            if c.id not in self.hist:
                self.hist[c.id] = _Hist(in_pits=c.in_pits)
        race = f.is_race
        if race:
            self._positions(pos, f)
            self._battles(f)
            self._pits(ahead, "El de adelante", "ahead", self.gap_ahead)
            self._pits(behind, "El de atrás", "behind", self.gap_behind)
        if race or 5 <= f.session <= 8:
            self._traffic(cars, me, f, L)
        for c in cars:
            self.hist[c.id].in_pits = c.in_pits

    def _positions(self, pos: int, f) -> None:
        now = self.e.q.clock()
        if self.class_pos == 0:
            self.class_pos = pos
            return
        if pos != self.class_pos:
            if self._pending_pos != pos:
                self._pending_pos, self._pending_since = pos, now
            elif now - self._pending_since > 6.0 and not f.in_pits:
                old = self.class_pos
                self.class_pos = pos
                self._pending_pos = None
                if f.lap < 1:
                    return   # la arrancada se resume al cerrar la vuelta
                if pos < old:
                    self.e.say(f"Ganas posición. P{pos} en tu clase.", HIGH, "pos", 20)
                else:
                    self.e.say(f"Pierdes posición. P{pos} en tu clase.", HIGH, "pos", 20)
        else:
            self._pending_pos = None

    def _battles(self, f) -> None:
        th = float(self.cfg.get("brecha_pelea_s", 1.0))
        ga, gb = self.gap_ahead, self.gap_behind
        if self.behind and gb is not None and not self.behind.in_pits:
            if not self._close_behind and gb < th:
                self._close_behind = True
                self.e.say(f"{self.behind.short} detrás a {say_gap(gb)}. Defiende, cubre la frenada.",
                           HIGH, "behind", 45)
            elif self._close_behind and gb > th * 1.3:
                self._close_behind = False
        if self.ahead and ga is not None and not self.ahead.in_pits:
            if not self._close_ahead and ga < th:
                self._close_ahead = True
                self.e.say(f"{self.ahead.short} adelante a {say_gap(ga)}. Ataca, busca la salida más rápida.",
                           HIGH, "ahead", 45)
            elif self._close_ahead and ga > th * 1.3:
                self._close_ahead = False

    def _pits(self, car: Car | None, who: str, side: str = "", gap=None) -> None:
        if car is None:
            return
        h = self.hist.get(car.id)
        if h and car.in_pits and not h.in_pits:
            if hasattr(self.e, "strategy") and side:
                self.e.strategy.on_rival_pit(side, car, gap)
            else:
                self.e.say(f"{who}, {car.short}, entra a pits.", NORMAL, f"pit{car.id}", 60)

    def _traffic(self, cars, me: Car, f, L: float) -> None:
        """Autos de otra clase cerca en pista (no en la clasificación)."""
        now = self.e.q.clock()
        v = max(f.speed, 20.0)
        my_rank = class_rank(me.cls)
        for c in cars:
            if c.is_player or c.cls == me.cls or c.in_pits:
                continue
            faster = (c.best > 0 and me.best > 0 and c.best < me.best * 0.97) or \
                     (c.best <= 0 or me.best <= 0) and class_rank(c.cls) > my_rank
            slower = (c.best > 0 and me.best > 0 and c.best > me.best * 1.03) or \
                     (c.best <= 0 or me.best <= 0) and 0 < class_rank(c.cls) < my_rank
            behind_m = (me.lapdist - c.lapdist) % L      # distancia en pista detrás de mí
            ahead_m = (c.lapdist - me.lapdist) % L
            if now - self._traffic_warned.get(c.id, -1e9) < 30:
                continue
            if faster and behind_m < v * 2.5:
                self._traffic_warned[c.id] = now
                self.e.say(f"{c.cls} más rápido llegando por detrás. Mantén tu línea.", CRITICAL, f"tr{c.id}", 25)
            elif slower and ahead_m < v * 4.0:
                self._traffic_warned[c.id] = now
                self.e.say(f"Tráfico adelante, {c.cls} más lento.", HIGH, f"tr{c.id}", 25)

    # ----------------------------------------------------------------- vuelta
    def lap_report(self, lap: int) -> str | None:
        """Texto de fin de vuelta (solo carrera) con brechas y tendencias."""
        if not self.me:
            return None
        parts = [f"P{self.class_pos or '?'} de {self.n_class}."]
        for car, gap, label in ((self.ahead, self.gap_ahead, "Adelante"), (self.behind, self.gap_behind, "Atrás")):
            if car is None or gap is None:
                continue
            h = self.hist[car.id]
            prev = h.gap_at_lap.get(lap - 1)
            h.gap_at_lap[lap] = gap
            trend = ""
            if prev is not None:
                d = gap - prev
                if abs(d) >= 0.1:
                    if label == "Adelante":
                        trend = f", le descuentas {say_gap(d)}" if d < 0 else f", se escapa {say_gap(d)}"
                    else:
                        trend = f", se acerca {say_gap(d)}" if d < 0 else f", te alejas {say_gap(d)}"
            parts.append(f"{label} {car.short} a {say_gap(gap)}{trend}.")
        return " ".join(parts) if len(parts) > 1 else None

    def snapshot(self) -> dict:
        return {"class_pos": self.class_pos, "n_class": self.n_class,
                "gap_ahead": self.gap_ahead, "gap_behind": self.gap_behind,
                "ahead": self.ahead.short if self.ahead else None,
                "behind": self.behind.short if self.behind else None}
