"""Compartir vueltas entre pilotos y progreso histórico."""

from __future__ import annotations

import gzip
import json
import shutil
import time
from pathlib import Path

from .coach.track import slug


def _read(p: Path) -> dict | None:
    try:
        with gzip.open(p, "rt", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:  # noqa: BLE001
        return None


def own_refs(data_dir: Path) -> list[dict]:
    out = []
    for p in sorted((Path(data_dir) / "references").glob("*.json.gz")):
        b = _read(p)
        if b:
            out.append({"path": str(p), "track": b["track"], "car": b["car"], "lap_time": b["lap_time"]})
    return out


def friend_refs(data_dir: Path, track: str | None = None) -> list[dict]:
    out = []
    for p in sorted((Path(data_dir) / "amigos").glob("*.json.gz")):
        b = _read(p)
        if b and (track is None or slug(b["track"]) == slug(track)):
            out.append({"path": str(p), "track": b["track"], "car": b["car"], "lap_time": b["lap_time"],
                        "driver": b.get("driver", "amigo")})
    return out


def export_ref(src: str, dest: str, driver: str) -> None:
    b = _read(Path(src))
    if not b:
        raise ValueError("No se pudo leer la vuelta.")
    b["driver"] = driver or "Piloto"
    b["exported"] = time.strftime("%Y-%m-%d")
    with gzip.open(dest, "wt", encoding="utf-8") as fh:
        json.dump(b, fh)


def import_ref(src: str, data_dir: Path) -> dict:
    b = _read(Path(src))
    if not b or not all(k in b for k in ("track", "car", "lap_time", "length", "data")):
        raise ValueError("El archivo no es una vuelta de Kerbo Race Coach.")
    d = Path(data_dir) / "amigos"
    d.mkdir(parents=True, exist_ok=True)
    name = f"{slug(b['track'])}__{slug(b['car'])}__{slug(b.get('driver', 'amigo'))}.json.gz"
    shutil.copy2(src, d / name)
    return {"path": str(d / name), "track": b["track"], "car": b["car"], "lap_time": b["lap_time"],
            "driver": b.get("driver", "amigo")}


def progress(data_dir: Path) -> dict:
    """{(pista, auto): [{'date','best','sd','laps','session'}]} ordenado por fecha."""
    import statistics as st
    out: dict = {}
    for p in sorted(Path(data_dir).glob("sessions/*/session.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        valid = [l["time"] for l in d.get("laps", []) if l.get("valid") and l.get("time", 0) > 10]
        if not valid:
            continue
        best = min(valid)
        clean = [t for t in valid if t < best * 1.04]       # sin vueltas de tráfico/incidente
        out.setdefault((d["track"], d["car"]), []).append({
            "date": d.get("started", "")[:16], "best": best, "laps": len(valid), "session": d.get("session"),
            "sd": st.pstdev(clean) if len(clean) > 1 else 0.0})
    return out


def progress_svg(rows: list[dict], width: int = 900) -> str:
    """Mejor vuelta por sesión (línea) y consistencia (barras)."""
    W, H, pl, pr, pt, pb = width, 260, 64, 16, 24, 40
    n = len(rows)
    bests = [r["best"] for r in rows]
    lo, hi = min(bests), max(bests)
    if hi - lo < 0.5:
        hi, lo = hi + 0.25, lo - 0.25

    def X(i):
        return pl + (W - pl - pr) * (i / max(1, n - 1))

    def Y(t):
        return pt + (H - pt - pb) * (t - lo) / (hi - lo)   # más rápido = más arriba

    def fmt(t):
        m, s = divmod(t, 60)
        return f"{int(m)}:{s:06.3f}"
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="Segoe UI, Arial" font-size="11">',
         f'<rect width="{W}" height="{H}" rx="10" fill="#161a21"/>']
    for k in range(4):
        t = lo + (hi - lo) * k / 3
        y = Y(t)
        o.append(f'<line x1="{pl}" x2="{W - pr}" y1="{y:.1f}" y2="{y:.1f}" stroke="#262c37"/>')
        o.append(f'<text x="{pl - 6}" y="{y + 4:.1f}" fill="#8a93a3" text-anchor="end">{fmt(t)}</text>')
    pts = " ".join(f"{X(i):.1f},{Y(r['best']):.1f}" for i, r in enumerate(rows))
    o.append(f'<polyline points="{pts}" fill="none" stroke="#ff7a1a" stroke-width="2"/>')
    days = {r["date"][:10] for r in rows}
    for i, r in enumerate(rows):
        o.append(f'<circle cx="{X(i):.1f}" cy="{Y(r["best"]):.1f}" r="3.5" fill="#ff7a1a"/>')
        if n <= 12 or i % max(1, n // 10) == 0 or i == n - 1:
            lbl = r["date"][5:10] if len(days) == n else r["date"][8:16].replace(" ", "·")
            o.append(f'<text x="{X(i):.1f}" y="{H - 22}" fill="#8a93a3" text-anchor="middle">{lbl}</text>')
    best_i = min(range(n), key=lambda i: rows[i]["best"])
    o.append(f'<text x="{X(best_i):.1f}" y="{Y(rows[best_i]["best"]) - 8:.1f}" fill="#e8ebf0" text-anchor="middle" '
             f'font-weight="600">{fmt(rows[best_i]["best"])}</text>')
    o.append(f'<text x="{W / 2:.0f}" y="{H - 6}" fill="#8a93a3" text-anchor="middle">Mejor vuelta por sesión</text>')
    o.append("</svg>")
    return "\n".join(o)


def progress_markdown(data_dir: Path) -> str:
    prog = progress(data_dir)
    out_dir = Path(data_dir) / "progreso"
    out_dir.mkdir(parents=True, exist_ok=True)
    L = ["# Tu progreso", ""]
    if not prog:
        return "# Tu progreso\n\nTodavía no hay sesiones con vueltas válidas."
    for (track, car), rows in sorted(prog.items(), key=lambda kv: -len(kv[1])):
        rows.sort(key=lambda r: r["date"])
        name = f"{slug(track)}__{slug(car)}.svg"
        if len(rows) >= 2:
            (out_dir / name).write_text(progress_svg(rows), encoding="utf-8")
        first, last, best = rows[0]["best"], rows[-1]["best"], min(r["best"] for r in rows)
        L += [f"## {track} · {car}", "",
              f"- Sesiones: {len(rows)} · mejor vuelta: **{best // 60:.0f}:{best % 60:06.3f}** · "
              f"de la primera a la última: {last - first:+.3f} s", ""]
        if len(rows) >= 2:
            L += [f"![progreso]({name})", ""]
        L += ["| Fecha | Sesión | Mejor | Consistencia (σ) | Vueltas |", "|---|---|---|---|---|"]
        for r in rows[-15:]:
            L.append(f"| {r['date']} | {r['session']} | {r['best'] // 60:.0f}:{r['best'] % 60:06.3f} | "
                     f"{r['sd']:.2f} s | {r['laps']} |")
        L.append("")
    return "\n".join(L)
