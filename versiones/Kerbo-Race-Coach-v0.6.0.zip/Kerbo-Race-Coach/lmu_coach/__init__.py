"""Kerbo Race Coach (paquete interno: lmu_coach)."""
__version__ = "0.6.0"
