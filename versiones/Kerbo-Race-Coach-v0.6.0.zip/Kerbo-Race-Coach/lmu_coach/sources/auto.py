"""Detecta qué simulador está abierto (LMU o iRacing) y devuelve su fuente."""

from __future__ import annotations

SIMS = {"lmu": "Le Mans Ultimate", "iracing": "iRacing"}


def make(sim: str):
    if sim == "iracing":
        from .iracing import IRacingSource
        return IRacingSource()
    from .lmu import LMUSource
    return LMUSource()


class AutoDetect:
    """Prueba cada simulador permitido; `connect()` devuelve la fuente conectada o None."""

    def __init__(self, sims=("lmu", "iracing")):
        self.sources = []
        for s in sims:
            try:
                self.sources.append(make(s))
            except Exception:  # noqa: BLE001  (p. ej. falta pyirsdk)
                pass

    def connect(self):
        for src in self.sources:
            try:
                if src.connect():
                    return src
            except Exception:  # noqa: BLE001
                continue
        return None


def allowed(cfg: dict) -> tuple:
    sel = str(cfg.get("lectura", {}).get("simulador", "auto")).lower()
    return (sel,) if sel in SIMS else ("lmu", "iracing")
