"""Lector de telemetría en vivo de iRacing (memoria compartida oficial vía pyirsdk).

No requiere configurar nada en iRacing: la telemetría en vivo siempre está publicada
mientras estás en el auto.

Diferencias con LMU (iRacing no publica estos datos en vivo):
- No hay velocidad por rueda → no se mide el deslizamiento longitudinal (bloqueos/patinaje).
  Se estima el ángulo de deriva trasero con la cinemática del auto (velocidad lateral y
  tasa de giro) para detectar sobreviraje en salida; los bloqueos se ven solo vía ABS activo.
- No hay señal de "TC actuando" ni temperaturas de freno.
- Temperaturas, presiones y desgaste de llantas solo se actualizan al pasar por pits.
- Los niveles máximos de TC/ABS no se publican.
"""

from __future__ import annotations

import math
import re

from ..frame import Frame

FLAG_BLUE = 0x0020
FLAG_YELLOW = 0x0008 | 0x0100            # yellow | yellow_waving
FLAG_CAUTION = 0x4000 | 0x8000           # caution | caution_waving (pista completa)
UNLIMITED_TIME = 600000.0
REAR_AXLE_M = 1.4                         # distancia aproximada CG → eje trasero
DC_MAX_DEFAULT = 12                       # iRacing no publica el máximo de TC/ABS

_SESSION = {"practice": 1, "open qualify": 5, "lone qualify": 5, "qualify": 5, "warmup": 9,
            "race": 10, "heat race": 10, "offline testing": 0, "time trial": 5}


def _num(s, default: float = 0.0) -> float:
    m = re.search(r"-?\d+(?:\.\d+)?", str(s or ""))
    return float(m.group()) if m else default


def track_length_m(s) -> float:
    """'7.00 km' / '4.35 mi' → metros."""
    v = _num(s)
    return v * 1609.344 if "mi" in str(s) else v * 1000.0


class IRacingSource:
    """Fuente de telemetría en vivo desde iRacing.

    `ir` permite inyectar un objeto compatible con irsdk.IRSDK (para pruebas).
    """

    name = "iracing"

    def __init__(self, ir=None) -> None:
        self._ir = ir
        self._own = ir is None
        self._si_ver = -1
        self._info: dict = {}
        self._pit_prev = False
        self._pitstops = 0
        self._cars_prev: dict[int, tuple] = {}
        self._car_pits: dict[int, int] = {}
        self._car_pit_prev: dict[int, bool] = {}

    # ------------------------------------------------------------------ conexión
    def connect(self) -> bool:
        if self._ir is None:
            try:
                import irsdk
            except Exception:  # noqa: BLE001
                return False
            self._ir = irsdk.IRSDK()
        ir = self._ir
        if not getattr(ir, "is_initialized", True):
            try:
                if not ir.startup():
                    return False
            except Exception:  # noqa: BLE001
                return False
        return self.alive()

    def alive(self) -> bool:
        ir = self._ir
        if ir is None:
            return False
        try:
            ok = bool(getattr(ir, "is_initialized", True) and ir.is_connected)
        except Exception:  # noqa: BLE001
            ok = False
        if not ok and self._own and getattr(ir, "is_initialized", False):
            try:
                ir.shutdown()          # iRacing se cerró: reconectar desde cero la próxima vez
            except Exception:  # noqa: BLE001
                pass
            self._si_ver = -1
        return ok

    def user_data_path(self) -> str:
        return ""                      # los setups .sto de iRacing no se guardan (formato binario)

    # ------------------------------------------------------------------ info de sesión (YAML)
    def _session_info(self) -> dict:
        ir = self._ir
        ver = getattr(ir, "session_info_update", 0)
        if ver != self._si_ver or not self._info:
            self._si_ver = ver
            info = {}
            for key in ("WeekendInfo", "DriverInfo", "SessionInfo"):
                try:
                    info[key] = ir[key] or {}
                except Exception:  # noqa: BLE001
                    info[key] = {}
            self._info = self._parse_info(info)
        return self._info

    @staticmethod
    def _parse_info(info: dict) -> dict:
        wk, dr, se = info.get("WeekendInfo", {}), info.get("DriverInfo", {}), info.get("SessionInfo", {})
        me = dr.get("DriverCarIdx")
        me = int(me) if me is not None else -1
        drivers = {}
        for d in dr.get("Drivers", []) or []:
            idx = int(d.get("CarIdx", -1))
            if idx < 0:
                continue
            drivers[idx] = {
                "name": str(d.get("UserName", "")),
                "car": str(d.get("CarScreenName", "") or d.get("CarScreenNameShort", "")),
                "number": str(d.get("CarNumber", "")),
                "cls": str(d.get("CarClassShortName", "") or ""),
                "pace": bool(d.get("CarIsPaceCar", 0)),
                "spectator": bool(d.get("IsSpectator", 0)),
            }
        sessions = {int(s.get("SessionNum", i)): s for i, s in enumerate(se.get("Sessions", []) or [])}
        tyres = {int(t.get("TireIndex", i)): str(t.get("TireCompoundType", ""))
                 for i, t in enumerate(dr.get("DriverTires", []) or [])}
        track = str(wk.get("TrackDisplayName", "") or wk.get("TrackName", ""))
        cfg = str(wk.get("TrackConfigName", "") or "")
        if cfg and cfg.lower() not in track.lower():
            track = f"{track} {cfg}"
        fuel_cap = _num(dr.get("DriverCarFuelMaxLtr")) * (_num(dr.get("DriverCarMaxFuelPct"), 1.0) or 1.0)
        return {"me": me, "drivers": drivers, "sessions": sessions, "tyres": tyres, "track": track,
                "track_len": track_length_m(wk.get("TrackLength", "")),
                "redline": _num(dr.get("DriverCarRedLine")), "fuel_cap": fuel_cap}

    def _get(self, key, default=None):
        try:
            v = self._ir[key]
        except Exception:  # noqa: BLE001
            return default
        return default if v is None else v

    # ------------------------------------------------------------------ lectura
    def read(self) -> Frame | None:
        ir = self._ir
        if ir is None or not self.alive():
            return None
        frozen = hasattr(ir, "freeze_var_buffer_latest")
        if frozen:
            ir.freeze_var_buffer_latest()      # lectura consistente de todas las variables
        try:
            return self._read()
        finally:
            if frozen:
                ir.unfreeze_var_buffer_latest()

    def _read(self) -> Frame | None:
        g = self._get
        info = self._session_info()
        if not g("IsOnTrack", False) or g("IsReplayPlaying", False):
            return None
        me = info["me"]
        drv = info["drivers"].get(me, {})

        f = Frame()
        f.sim = "iracing"
        f.t = float(g("SessionTime", 0.0))
        f.lap = int(g("Lap", 0))
        lap_cur = float(g("LapCurrentLapTime", 0.0))
        f.lap_start_t = f.t - lap_cur if lap_cur > 0 else f.t
        pct = float(g("LapDistPct", 0.0))
        dist = float(g("LapDist", 0.0))
        f.track_len = info["track_len"] or (dist / pct if pct > 0.05 else 0.0)
        f.dist = min(max(dist, 0.0), f.track_len) if f.track_len else max(dist, 0.0)

        f.speed = float(g("Speed", 0.0))
        f.throttle = float(g("Throttle", 0.0))
        f.brake = float(g("Brake", 0.0))
        smax = float(g("SteeringWheelAngleMax", 0.0)) or 4.0
        f.steer = max(-1.0, min(1.0, -float(g("SteeringWheelAngle", 0.0)) / smax))  # + = derecha (como LMU)
        f.gear = int(g("Gear", 0))
        f.rpm = float(g("RPM", 0.0))
        f.max_rpm = info["redline"]
        f.yaw_rate = float(g("YawRate", 0.0))
        f.lat_g = float(g("LatAccel", 0.0)) / 9.81
        f.lon_g = float(g("LongAccel", 0.0)) / 9.81
        f.abs_active = bool(g("BrakeABSactive", False))
        f.tc_active = False

        # Deriva trasera estimada (cinemática): sirve para ver sobreviraje en salida.
        vx, vy = float(g("VelocityX", 0.0)), float(g("VelocityY", 0.0))
        if vx > 5.0:
            ar = math.degrees(math.atan2(vy - f.yaw_rate * REAR_AXLE_M, vx))
            f.slip_angle = [0.0, 0.0, ar, ar]
        f.slip_est = True

        f.fuel = float(g("FuelLevel", 0.0))
        f.fuel_cap = info["fuel_cap"]
        bat = g("EnergyERSBatteryPct", None)
        f.battery = float(bat) if bat is not None else -1.0

        for i, w in enumerate(("LF", "RF", "LR", "RR")):
            # iRacing: L/M/R = lado izquierdo/centro/derecho de la llanta; C* = carcasa (solo en pits)
            surf = [g(f"{w}temp{s}", 0.0) for s in ("L", "M", "R")]
            carc = [g(f"{w}tempC{s}", 0.0) for s in ("L", "M", "R")]
            f.tyre_temp[i] = [float(x) for x in (surf if any(surf) else carc)]
            f.tyre_carcass[i] = float(sum(carc) / 3) if any(carc) else 0.0
            f.tyre_press[i] = float(g(f"{w}press", 0.0) or g(f"{w}coldPressure", 0.0))
            wear = [g(f"{w}wear{s}", None) for s in ("L", "M", "R")]
            wear = [float(x) for x in wear if x is not None]
            f.tyre_wear[i] = sum(wear) / len(wear) if wear else 0.0
        comp = int(g("PlayerTireCompound", 0) or 0)
        f.compound = info["tyres"].get(comp, "")

        bias = g("dcBrakeBias", None)
        if bias is not None and bias > 0:
            front = bias / 100.0 if bias > 1.0 else bias
            f.brake_bias_rear = max(0.0, min(1.0, 1.0 - front))
        tc1, tc2, abs_ = g("dcTractionControl", None), g("dcTractionControl2", None), g("dcABS", None)
        if tc1 is not None:
            f.tc_level, f.tc_max = int(round(tc1)), DC_MAX_DEFAULT
        if tc2 is not None:
            f.tc_slip, f.tc_slip_max = int(round(tc2)), DC_MAX_DEFAULT
        if abs_ is not None:
            f.abs_level, f.abs_max = int(round(abs_)), DC_MAX_DEFAULT

        f.track = info["track"]
        f.car = drv.get("car", "")
        f.car_class = drv.get("cls", "")
        snum = int(g("SessionNum", 0))
        stype = str(info["sessions"].get(snum, {}).get("SessionType", "")).lower()
        f.session = _SESSION.get(stype, 10 if "race" in stype else 1)
        flags = int(g("SessionFlags", 0)) & 0xFFFFFFFF
        state = int(g("SessionState", 0))
        f.game_phase = 6 if flags & FLAG_CAUTION else (5 if state == 4 else (8 if state >= 5 else 0))
        f.in_realtime = True
        f.in_pits = bool(g("OnPitRoad", False))
        in_stall = bool(g("PlayerCarInPitStall", False))
        if in_stall and not self._pit_prev:
            self._pitstops += 1
        self._pit_prev = in_stall
        f.num_pitstops = self._pitstops
        f.place = int(g("PlayerCarPosition", 0))
        f.flag = 6 if flags & FLAG_BLUE else 0
        # sector (convención LMU: 1 = S1, 2 = S2, 0 = S3) por tercios de vuelta
        third = min(2, max(0, int(pct * 3)))
        f.sector = (1, 2, 0)[third]
        yellow = 1 if (flags & FLAG_YELLOW) and not (flags & FLAG_CAUTION) else 0
        sf = [0, 0, 0]
        sf[f.sector] = yellow
        f.sector_flags = tuple(sf)
        f.yellow_state = 1 if flags & FLAG_CAUTION else 0
        f.track_limits_steps = int(g("PlayerCarMyIncidentCount", 0))
        best = float(g("LapBestLapTime", 0.0))
        last = float(g("LapLastLapTime", 0.0))
        f.best_lap = best if best > 0 else -1.0
        f.last_lap = last if last > 0 else -1.0
        f.delta_best = float(g("LapDeltaToBestLap", 0.0)) if g("LapDeltaToBestLap_OK", False) else 0.0
        rem = float(g("SessionTimeRemain", -1.0))
        f.time_remaining = rem if 0 <= rem < UNLIMITED_TIME else -1.0
        laps_total = int(g("SessionLapsTotal", 0) or 0)
        f.max_laps = laps_total if 0 < laps_total < 10000 else 0
        f.air_temp = float(g("AirTemp", 0.0))
        f.track_temp = float(g("TrackTempCrew", 0.0) or g("TrackTemp", 0.0))
        wet = int(g("TrackWetness", 0) or 0)       # 0 desconocido, 1 seco … 7 extremadamente mojado
        f.wetness = max(0.0, (wet - 1) / 6.0) if wet > 0 else 0.0
        f.raining = float(g("Precipitation", 0.0) or 0.0)
        return f

    def read_cars(self):
        """Todos los autos de la sesión."""
        from ..coach.rivals import Car
        g = self._get
        info = self._session_info()
        t = float(g("SessionTime", 0.0))
        laps = g("CarIdxLapCompleted", []) or []
        pcts = g("CarIdxLapDistPct", []) or []
        pos = g("CarIdxPosition", []) or []
        pit = g("CarIdxOnPitRoad", []) or []
        last = g("CarIdxLastLapTime", []) or []
        best = g("CarIdxBestLapTime", []) or []
        tlen = info["track_len"]
        out = []
        for idx, d in info["drivers"].items():
            if d["pace"] or d["spectator"] or idx >= len(pcts) or pcts[idx] < 0:
                continue
            lapdist = max(0.0, pcts[idx]) * tlen
            lap_c = int(laps[idx]) if idx < len(laps) else 0
            on_pit = bool(pit[idx]) if idx < len(pit) else False
            if on_pit and not self._car_pit_prev.get(idx, False):
                self._car_pits[idx] = self._car_pits.get(idx, 0) + 1
            self._car_pit_prev[idx] = on_pit
            speed = 0.0
            prev = self._cars_prev.get(idx)
            total = lap_c * tlen + lapdist
            if prev and t > prev[0]:
                speed = max(0.0, (total - prev[1]) / (t - prev[0]))
                if speed > 120:            # salto de vuelta / reconexión
                    speed = 0.0
            self._cars_prev[idx] = (t, total)
            vehicle = d["car"] + (f" #{d['number']}" if d["number"] else "")
            out.append(Car(id=idx, driver=d["name"], vehicle=vehicle, cls=d["cls"],
                           place=int(pos[idx]) if idx < len(pos) else 0, laps=lap_c, lapdist=lapdist,
                           in_pits=on_pit, pitstops=self._car_pits.get(idx, 0),
                           last=float(last[idx]) if idx < len(last) else -1.0,
                           best=float(best[idx]) if idx < len(best) else -1.0,
                           is_player=idx == info["me"], speed=speed))
        return out

    def close(self) -> None:
        if self._ir is not None and self._own:
            try:
                self._ir.shutdown()
            except Exception:  # noqa: BLE001
                pass
        self._ir = None
