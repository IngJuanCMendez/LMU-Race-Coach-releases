"""Lector de la memoria compartida nativa de Le Mans Ultimate (`LMU_Data`).

LMU publica esta memoria por sí mismo (no requiere el plugin rF2SharedMemoryMap).
Requisito en el juego: Settings → Gameplay → "Enable Plugins" = ON.

Estructuras: pyLMUSharedMemory (MIT, TinyPedal), derivadas del
SharedMemoryInterface.hpp oficial de Studio 397. Tamaños verificados:
ScoringInfo 548, VehicleScoring 584, VehicleTelemetry 1888, Wheel 260,
ObjectOut 324 820 bytes.
"""

from __future__ import annotations

import ctypes
import math
import time

from ..frame import Frame
from ..vendor.pyLMUSharedMemory import lmu_data as D
from ..vendor.pyLMUSharedMemory._common import platform_mmap

_SZ_TEL = ctypes.sizeof(D.LMUVehicleTelemetry)
_SZ_VSC = ctypes.sizeof(D.LMUVehicleScoring)
_OFF_TELEM = D.LMUObjectOut.telemetry.offset + D.LMUTelemetryData.telemInfo.offset
_OFF_SINFO = D.LMUObjectOut.scoring.offset + D.LMUScoringData.scoringInfo.offset
_OFF_VSC = D.LMUObjectOut.scoring.offset + D.LMUScoringData.vehScoringInfo.offset
_MAXV = D.LMUConstants.MAX_MAPPED_VEHICLES


def _s(b: bytes) -> str:
    return b.split(b"\0", 1)[0].decode("utf-8", "ignore").strip()


def _c(k: float) -> float:
    """Kelvin → °C (LMU entrega temperaturas de llanta y freno en Kelvin)."""
    return k - 273.15 if k > 150 else k


class LMUSource:
    """Fuente de telemetría en vivo desde LMU."""

    name = "lmu"

    def __init__(self) -> None:
        self._mm = None
        self._obj = None
        self._anchor_et = -1.0
        self._anchor_dist = 0.0
        self._anchor_t = 0.0
        self._last_t = None
        self._dist = 0.0
        self._lap = -1

    # ------------------------------------------------------------------ conexión
    def connect(self) -> bool:
        if self._mm is None:
            try:
                self._mm = platform_mmap(D.LMUConstants.LMU_SHARED_MEMORY_FILE,
                                         ctypes.sizeof(D.LMUObjectOut))
                self._obj = D.LMUObjectOut.from_buffer(self._mm)
            except Exception:  # noqa: BLE001
                self._mm = None
                return False
        return self.alive()

    def alive(self) -> bool:
        if self._obj is None:
            return False
        return self._obj.generic.gameVersion != 0 or self._obj.scoring.scoringInfo.mNumVehicles > 0

    def game_version(self) -> int:
        return int(self._obj.generic.gameVersion) if self._obj else 0

    def user_data_path(self) -> str:
        return _s(bytes(self._obj.paths.userData)) if self._obj else ""

    # ------------------------------------------------------------------ lectura
    def _player_scoring(self, n: int):
        vs = self._obj.scoring.vehScoringInfo
        for i in range(min(max(n, 0), _MAXV)):
            if vs[i].mIsPlayer:
                return D.LMUVehicleScoring.from_buffer_copy(self._mm, _OFF_VSC + i * _SZ_VSC)
        return None

    def read(self) -> Frame | None:
        """Devuelve el Frame actual del jugador o None si no está en pista."""
        o = self._obj
        if o is None:
            return None
        tdat = o.telemetry
        if not tdat.playerHasVehicle:
            return None
        idx = int(tdat.playerVehicleIdx)
        if idx >= _MAXV:
            return None

        # Copia consistente: re-lee si el juego escribió durante la copia.
        tel = None
        for _ in range(3):
            before = tdat.telemInfo[idx].mElapsedTime
            tel = D.LMUVehicleTelemetry.from_buffer_copy(self._mm, _OFF_TELEM + idx * _SZ_TEL)
            if tdat.telemInfo[idx].mElapsedTime == before:
                break
        si = D.LMUScoringInfo.from_buffer_copy(self._mm, _OFF_SINFO)
        vs = self._player_scoring(si.mNumVehicles)

        f = Frame()
        f.t = tel.mElapsedTime
        f.lap = tel.mLapNumber
        f.lap_start_t = tel.mLapStartET
        f.track_len = si.mLapDist
        f.x, f.z = tel.mPos.x, tel.mPos.z
        v = tel.mLocalVel
        f.speed = math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
        f.throttle = tel.mUnfilteredThrottle
        f.brake = tel.mUnfilteredBrake
        f.steer = tel.mUnfilteredSteering
        f.gear = tel.mGear
        f.rpm = tel.mEngineRPM
        f.max_rpm = tel.mEngineMaxRPM
        f.yaw_rate = tel.mLocalRot.y
        f.lat_g = tel.mLocalAccel.x / 9.81
        f.lon_g = -tel.mLocalAccel.z / 9.81
        f.abs_active = bool(tel.mABSActive)
        f.tc_active = bool(tel.mTCActive)
        f.fuel = tel.mFuel
        f.fuel_cap = tel.mFuelCapacity
        f.virtual_energy = tel.mVirtualEnergy if tel.mVirtualEnergy > 0 else -1.0
        f.battery = tel.mBatteryChargeFraction
        f.ride_h_front = tel.mFrontRideHeight
        f.ride_h_rear = tel.mRearRideHeight
        f.compound = _s(tel.mFrontTireCompoundName)
        f.brake_bias_rear = tel.mRearBrakeBias
        f.tc_level = tel.mTC
        f.tc_max = tel.mTCMax
        f.tc_slip, f.tc_slip_max = tel.mTCSlip, tel.mTCSlipMax
        f.tc_cut, f.tc_cut_max = tel.mTCCut, tel.mTCCutMax
        f.abs_level = tel.mABS
        f.abs_max = tel.mABSMax
        f.motor_map = tel.mMotorMap
        f.lap_invalid = bool(tel.mLapInvalidated)
        f.track_limits_steps = tel.mTrackLimitsSteps
        f.delta_best = tel.mDeltaBest
        f.gap_ahead = tel.mTimeGapCarAhead
        f.gap_behind = tel.mTimeGapCarBehind
        f.track = _s(tel.mTrackName) or _s(si.mTrackName)
        f.car = _s(tel.mVehicleModel) or _s(tel.mVehicleName)

        for i in range(4):
            w = tel.mWheels[i]
            f.tyre_temp[i] = [_c(w.mTemperature[0]), _c(w.mTemperature[1]), _c(w.mTemperature[2])]
            f.tyre_carcass[i] = _c(w.mTireCarcassTemperature)
            f.tyre_opt[i] = _c(w.mOptimalTemp) if w.mOptimalTemp > 0 else 0.0
            f.tyre_press[i] = w.mPressure
            f.tyre_wear[i] = w.mWear
            f.brake_temp[i] = _c(w.mBrakeTemp)
            gv = w.mLongitudinalGroundVel
            if abs(gv) > 3.0:
                f.slip_angle[i] = math.degrees(math.atan2(w.mLateralGroundVel, abs(gv)))
                f.slip_ratio[i] = w.mLongitudinalPatchVel / abs(gv)

        f.session = si.mSession
        f.game_phase = si.mGamePhase
        f.in_realtime = bool(si.mInRealtime)
        f.yellow_state = int(si.mYellowFlagState[0]) if isinstance(si.mYellowFlagState, bytes) else int(si.mYellowFlagState)
        f.sector_flags = tuple(si.mSectorFlag)
        f.time_remaining = si.mSessionTimeRemaining
        f.max_laps = si.mMaxLaps
        f.air_temp = si.mAmbientTemp
        f.track_temp = si.mTrackTemp
        f.wetness = si.mAvgPathWetness
        f.raining = si.mRaining

        if vs is not None:
            f.car_class = _s(vs.mVehicleClass)
            f.in_pits = bool(vs.mInPits)
            f.pit_state = vs.mPitState
            f.place = vs.mPlace
            f.flag = vs.mFlag
            f.sector = vs.mSector
            f.best_lap = vs.mBestLapTime
            f.num_pitstops = vs.mNumPitstops
            f.last_lap = vs.mLastLapTime
            self._update_distance(f, si.mCurrentET, vs.mLapDist)
        else:
            f.dist = self._dist
        return f

    def read_cars(self):
        """Todos los autos de la sesión (scoring, 5 Hz)."""
        from ..coach.rivals import Car
        if self._obj is None:
            return []
        n = min(max(int(self._obj.scoring.scoringInfo.mNumVehicles), 0), _MAXV)
        out = []
        for i in range(n):
            v = D.LMUVehicleScoring.from_buffer_copy(self._mm, _OFF_VSC + i * _SZ_VSC)
            lv = v.mLocalVel
            out.append(Car(id=v.mID, driver=_s(v.mDriverName), vehicle=_s(v.mVehicleName), cls=_s(v.mVehicleClass),
                           place=v.mPlace, laps=v.mTotalLaps, lapdist=max(v.mLapDist, 0.0), in_pits=bool(v.mInPits),
                           pitstops=v.mNumPitstops, last=v.mLastLapTime, best=v.mBestLapTime,
                           is_player=bool(v.mIsPlayer),
                           speed=math.sqrt(lv.x * lv.x + lv.y * lv.y + lv.z * lv.z)))
        return out

    def _update_distance(self, f: Frame, scoring_et: float, lapdist: float) -> None:
        """La distancia de vuelta llega a 5 Hz; se interpola a la tasa de telemetría."""
        if self._lap == -1:          # primera lectura (p. ej. conectando a mitad de vuelta)
            self._lap = f.lap
            self._anchor_et = -1.0
        elif f.lap != self._lap:
            self._lap = f.lap
            self._anchor_et = scoring_et   # el scoring actual aún es de la vuelta anterior
            self._anchor_dist = 0.0
            self._anchor_t = f.lap_start_t if 0 < f.lap_start_t <= f.t else f.t
            self._fresh = True
        stale = getattr(self, "_fresh", False) and f.track_len > 0 and lapdist > f.track_len * 0.5
        if not stale:
            self._fresh = False
        if scoring_et != self._anchor_et and not stale:
            self._anchor_et = scoring_et
            self._anchor_dist = max(lapdist, 0.0)
            self._anchor_t = f.t
            self._dist = self._anchor_dist
        else:
            dt = max(0.0, f.t - self._anchor_t)
            self._dist = self._anchor_dist + f.speed * dt
        if f.track_len > 0:
            self._dist = min(self._dist, f.track_len)
        f.dist = self._dist

    def close(self) -> None:
        self._obj = None
        if self._mm is not None:
            try:
                self._mm.close()
            except BufferError:
                pass
            self._mm = None


def wait_for_game(src: LMUSource, poll: float = 1.0, log=print) -> None:
    shown = False
    while not src.connect():
        if not shown:
            log("Esperando a Le Mans Ultimate... (Settings → Gameplay → Enable Plugins = ON)")
            shown = True
        time.sleep(poll)
