"""Debrief con Claude (opcional). Requiere `pip install anthropic` y ANTHROPIC_API_KEY."""

from __future__ import annotations

import json
import os
from pathlib import Path

SYSTEM = """Eres un ingeniero de pista y coach de pilotaje de resistencia (WEC) experto en
Le Mans Ultimate (motor rFactor 2). Hablas español latino, directo y técnico pero claro.
Recibes un análisis numérico de una sesión (ya calculado: no inventes datos que no estén)
y, opcionalmente, el archivo de setup .svm. Entregas:

1. Resumen en 3 líneas (ritmo, consistencia, vuelta ideal vs mejor).
2. Las 3 prioridades de PILOTAJE ordenadas por tiempo recuperable, cada una con curva(s),
   qué hacer exactamente (referencias de frenada, vértice, acelerador) y cuánto se gana aprox.
3. Cambios de SETUP ordenados por impacto: máximo 4, UNO A LA VEZ, con el parámetro concreto
   del .svm si se proporcionó (nombre y dirección del cambio en pasos/clicks), el porqué
   según los datos y qué debería notar el piloto. Diferencia problemas de pilotaje de problemas de coche.
4. Ayudas: reparto de freno, ABS y TC con valores concretos (actual → sugerido) según
   bloqueos, inestabilidad trasera, patinaje y % de actuación de ABS/TC.
5. Referencias de frenada: para las 3 curvas con más pérdida, el punto de frenada (metros antes
   del vértice), presión pico, trail braking y marcha de la mejor ejecución, y cómo replicarla.
6. Plan para el siguiente stint (5 vueltas) en viñetas.

Convenciones de los datos: balance = ángulo de deriva delantero − trasero en grados
(+ subviraje, − sobreviraje). Temperaturas de llanta [izq, centro, der] en °C; para llantas
izquierdas el interior es 'der' y para las derechas el interior es 'izq'. Presiones en kPa.
Si un dato es insuficiente, dilo en una frase en lugar de suponer."""


def _svm_excerpt(path: str | None, limit: int = 220) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.exists():
        return ""
    lines = []
    for ln in p.read_text(encoding="utf-8", errors="ignore").splitlines():
        s = ln.strip()
        if s.startswith("[") or ("Setting=" in s and "//" in s and "Non-adjustable" not in s):
            lines.append(s)
    return "\n".join(lines[:limit])


def ai_debrief(cfg: dict, analysis: dict, local_advice: list[dict], setup_path: str | None = None) -> str | None:
    if not cfg["ia"].get("habilitada", True):
        return None
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("[IA] Sin ANTHROPIC_API_KEY: se omite el debrief con Claude (el análisis local sí se genera).")
        return None
    try:
        import anthropic
    except ImportError:
        print("[IA] Falta el paquete 'anthropic' (pip install anthropic).")
        return None
    svm = _svm_excerpt(setup_path)
    user = ("ANÁLISIS DE SESIÓN (JSON):\n" + json.dumps(analysis, ensure_ascii=False, indent=1) +
            "\n\nSUGERENCIAS DE LAS REGLAS LOCALES (valídalas o corrígelas):\n" +
            json.dumps(local_advice, ensure_ascii=False, indent=1))
    if svm:
        user += "\n\nSETUP .SVM (extracto de parámetros ajustables):\n" + svm
    client = anthropic.Anthropic()
    try:
        r = client.messages.create(model=cfg["ia"]["modelo"], max_tokens=int(cfg["ia"]["max_tokens"]),
                                   system=SYSTEM, messages=[{"role": "user", "content": user}])
    except Exception as e:  # noqa: BLE001
        print(f"[IA] Error llamando a Claude: {e}")
        return None
    return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")


# --------------------------------------------------------------------------- ingeniero de setup
SETUP_SYSTEM = """Eres un ingeniero de setup de Le Mans Ultimate (motor rFactor 2) que trabaja con el piloto.
Español latino, directo. Recibes: lo que el piloto SIENTE (síntomas marcados y notas), el análisis
numérico de su última sesión (balance por tipo de curva, temperaturas de llantas, ayudas, pérdidas por
curva) y, si hay, su archivo de setup .svm. Primero cruza lo que siente con los datos (di si coinciden
o no). Luego propone como máximo 4 cambios ordenados por impacto, UNO A LA VEZ, cada uno con: el
parámetro exacto del .svm (nombre y dirección en pasos/clicks), por qué, y qué debería notar en pista.
Distingue problemas de pilotaje de problemas de coche. Si falta información, pregunta una sola cosa al final."""

SYMPTOMS = [
    "Subviraje en la entrada", "Subviraje a mitad de curva", "Subviraje en la salida",
    "Sobreviraje en la entrada", "Sobreviraje a mitad de curva", "Sobreviraje en la salida",
    "Inestable al frenar", "Bloquea al frenar", "Le falta tracción al acelerar",
    "Rebota o se descoloca en pianos", "Toca el piso / bottoming", "Le falta velocidad punta",
    "Llantas frías", "Llantas se calientan demasiado", "Curvas rápidas inestables", "Curvas lentas no gira",
]


def _client():
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise RuntimeError("Falta la clave de Claude: guárdala en Ajustes.")
    import anthropic
    return anthropic.Anthropic()


def setup_engineer(cfg: dict, analysis: dict | None, svm_path: str | None, symptoms: list[str], notes: str) -> str:
    user = "SÍNTOMAS QUE SIENTE EL PILOTO:\n" + ("\n".join(f"- {s}" for s in symptoms) or "- (ninguno marcado)")
    if notes.strip():
        user += f"\n\nNOTAS DEL PILOTO:\n{notes.strip()}"
    if analysis:
        user += "\n\nANÁLISIS DE LA ÚLTIMA SESIÓN (JSON):\n" + json.dumps(analysis, ensure_ascii=False)[:12000]
    svm = _svm_excerpt(svm_path)
    if svm:
        user += "\n\nSETUP .SVM (parámetros ajustables):\n" + svm
    r = _client().messages.create(model=cfg["ia"]["modelo"], max_tokens=int(cfg["ia"]["max_tokens"]),
                                  system=SETUP_SYSTEM, messages=[{"role": "user", "content": user}])
    return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")


# --------------------------------------------------------------------------- preguntas por radio
RADIO_SYSTEM = """Eres el ingeniero de pista por radio de un piloto de Le Mans Ultimate, en plena sesión.
Responde en español latino, en MÁXIMO dos frases cortas que se puedan decir por radio en 6 segundos,
sin listas, sin markdown, sin símbolos. Usa solo los datos del estado que recibes; si no lo sabes, dilo
en pocas palabras. Números redondeados y fáciles de oír."""


def live_context(engine) -> dict:
    st = engine.state()
    f = st["frame"]
    if f is None:
        return {}
    corners = [{"curva": engine.cname(c["num"]), "perdida_media_s": round(c["avg"], 2), "patron": c["kind"]}
               for c in st["corners"] if c.get("avg")]
    corners.sort(key=lambda c: -c["perdida_media_s"])
    return {
        "pista": f.track, "auto": f.car, "sesion": f.session, "vuelta": f.lap,
        "ultima_vuelta_s": round(f.last_lap, 2), "mejor_s": round(st["best"] or 0, 2),
        "delta_en_vivo_s": round(st["delta"], 2) if st.get("delta") is not None else None,
        "posicion_clase": st["rivals"], "combustible_l": round(f.fuel, 1),
        "energia_virtual_pct": round(f.virtual_energy * 100) if f.virtual_energy > 0 else None,
        "vueltas_de_energia": round(st["fuel_laps"], 1) if st["fuel_laps"] else None,
        "llantas_carcasa_c": [round(x) for x in f.tyre_carcass], "presiones_kpa": [round(x) for x in f.tyre_press],
        "desgaste_restante": [round(x, 2) for x in f.tyre_wear],
        "ayudas": {k: v for k, v in st["car"].items() if k in ("bias_front", "abs_level", "tc_level", "tc_slip", "tc_cut",
                                                                 "lock_f", "abs", "spin", "tc")},
        "estrategia": engine.strategy.plan, "humedad_pista": round(f.wetness, 2),
        "curvas_con_mas_perdida": corners[:5],
    }


def ask_radio(cfg: dict, question: str, engine) -> str:
    ctx = live_context(engine)
    r = _client().messages.create(
        model=cfg["ia"].get("modelo_radio", "claude-haiku-5-5"), max_tokens=200, system=RADIO_SYSTEM,
        messages=[{"role": "user", "content": f"ESTADO:\n{json.dumps(ctx, ensure_ascii=False)}\n\nPREGUNTA DEL PILOTO: {question}"}])
    return "".join(b.text for b in r.content if getattr(b, "type", "") == "text").strip()
