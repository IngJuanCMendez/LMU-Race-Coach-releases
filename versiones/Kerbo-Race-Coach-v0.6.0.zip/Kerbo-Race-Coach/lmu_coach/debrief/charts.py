"""Gráfica SVG: mejor vuelta vs vuelta típica (velocidad + delta acumulado), sin dependencias."""

from __future__ import annotations

import bisect

BG, GRID, TEXT, MUTED = "#161a21", "#262c37", "#e8ebf0", "#8a93a3"
BEST, TYP, GAIN, LOSS = "#ff7a1a", "#3fa7ff", "#2ecc71", "#e74c3c"


def _interp(xs, ys, x):
    if not xs:
        return None
    if x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]
    i = bisect.bisect_left(xs, x)
    x0, x1 = xs[i - 1], xs[i]
    a = (x - x0) / (x1 - x0) if x1 != x0 else 0
    return ys[i - 1] + a * (ys[i] - ys[i - 1])


def comparison_svg(best: dict, typ: dict, corners: list[dict], names: dict, best_label: str, typ_label: str,
                   width: int = 1100) -> str:
    """best/typ: canales remuestreados {'d','t','speed'}; corners: [{'num','apex_d'}]."""
    L = min(best["d"][-1], typ["d"][-1])
    n = 500
    ds = [L * i / (n - 1) for i in range(n)]
    vb = [(_interp(best["d"], best["speed"], d) or 0) * 3.6 for d in ds]
    vt = [(_interp(typ["d"], typ["speed"], d) or 0) * 3.6 for d in ds]
    dt = [(_interp(typ["d"], typ["t"], d) or 0) - (_interp(best["d"], best["t"], d) or 0) for d in ds]

    pad_l, pad_r = 56, 16
    h1_top, h1_h = 34, 230
    h2_top, h2_h = h1_top + h1_h + 56, 120
    H = h2_top + h2_h + 34
    W = width
    pw = W - pad_l - pad_r
    vmax = max(max(vb), max(vt)) * 1.05
    vmin = max(0.0, min(min(vb), min(vt)) * 0.9)
    raw = max(0.2, max(abs(x) for x in dt) * 1.15)
    tick = next(t for t in (0.1, 0.2, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 1e9) if raw / 2 <= t)
    dmax = tick * 2

    def X(d):
        return pad_l + pw * d / L

    def Y1(v):
        return h1_top + h1_h * (1 - (v - vmin) / (vmax - vmin))

    def Y2(x):
        return h2_top + h2_h / 2 - (h2_h / 2) * (x / dmax)

    def path(xs, ys, fy):
        return "M" + " L".join(f"{X(x):.1f},{fy(y):.1f}" for x, y in zip(xs, ys))

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="Segoe UI, Arial, sans-serif" font-size="12">',
           f'<rect width="{W}" height="{H}" fill="{BG}" rx="10"/>',
           f'<text x="{pad_l}" y="22" fill="{TEXT}" font-size="14" font-weight="600">Velocidad (km/h)</text>',
           f'<text x="{W - pad_r}" y="22" fill="{BEST}" text-anchor="end">— {best_label}</text>',
           f'<text x="{W - pad_r - 230}" y="22" fill="{TYP}" text-anchor="end">— {typ_label}</text>']
    # rejilla velocidad
    step = 50 if vmax - vmin > 150 else 25
    v = (int(vmin // step) + 1) * step
    while v < vmax:
        y = Y1(v)
        out.append(f'<line x1="{pad_l}" x2="{W - pad_r}" y1="{y:.1f}" y2="{y:.1f}" stroke="{GRID}"/>')
        out.append(f'<text x="{pad_l - 6}" y="{y + 4:.1f}" fill="{MUTED}" text-anchor="end">{v}</text>')
        v += step
    # curvas (etiquetas en dos filas cuando están cerca)
    last_x = {0: -1e9, 1: -1e9}
    for c in sorted(corners, key=lambda c: c["apex_d"]):
        x = X(c["apex_d"])
        if x < pad_l or x > W - pad_r:
            continue
        label = names.get(c["num"]) or names.get(str(c["num"])) or str(c["num"])
        w = 6.2 * len(label)
        row = 0 if x - last_x[0] > w + 8 else 1
        last_x[row] = x
        out.append(f'<line x1="{x:.1f}" x2="{x:.1f}" y1="{h1_top}" y2="{h2_top + h2_h}" stroke="{GRID}" stroke-dasharray="3,4"/>')
        out.append(f'<text x="{x:.1f}" y="{h1_top + h1_h + 14 + 13 * row}" fill="{MUTED}" font-size="11" '
                   f'text-anchor="middle">{label}</text>')
    out.append(f'<path d="{path(ds, vt, Y1)}" fill="none" stroke="{TYP}" stroke-width="1.6"/>')
    out.append(f'<path d="{path(ds, vb, Y1)}" fill="none" stroke="{BEST}" stroke-width="1.8"/>')
    # delta
    out.append(f'<text x="{pad_l}" y="{h2_top - 10}" fill="{TEXT}" font-size="14" font-weight="600">'
               f'Tiempo perdido por la vuelta típica (s) · arriba = más lenta</text>')
    y0 = Y2(0)
    out.append(f'<line x1="{pad_l}" x2="{W - pad_r}" y1="{y0:.1f}" y2="{y0:.1f}" stroke="{MUTED}"/>')
    for val in (tick, -tick):
        y = Y2(val)
        out.append(f'<line x1="{pad_l}" x2="{W - pad_r}" y1="{y:.1f}" y2="{y:.1f}" stroke="{GRID}"/>')
        out.append(f'<text x="{pad_l - 6}" y="{y + 4:.1f}" fill="{MUTED}" text-anchor="end">{val:+.2f}</text>')
    area = path(ds, dt, Y2) + f" L{X(ds[-1]):.1f},{y0:.1f} L{X(ds[0]):.1f},{y0:.1f} Z"
    col = LOSS if dt[-1] >= 0 else GAIN
    out.append(f'<path d="{area}" fill="{col}" fill-opacity="0.18" stroke="none"/>')
    out.append(f'<path d="{path(ds, dt, Y2)}" fill="none" stroke="{col}" stroke-width="1.8"/>')
    out.append(f'<circle cx="{X(ds[-1]):.1f}" cy="{Y2(dt[-1]):.1f}" r="4" fill="{col}"/>')
    out.append(f'<text x="{X(ds[-1]) - 8:.1f}" y="{Y2(dt[-1]) - 8:.1f}" fill="{col}" text-anchor="end" font-weight="600">'
               f'{dt[-1]:+.2f} s</text>')
    out.append(f'<text x="{W / 2:.0f}" y="{H - 10}" fill="{MUTED}" text-anchor="middle">Distancia en la vuelta (m)</text>')
    out.append("</svg>")
    return "\n".join(out)
