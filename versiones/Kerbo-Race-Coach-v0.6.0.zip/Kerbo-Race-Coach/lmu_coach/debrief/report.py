"""Genera el debrief en Markdown (local + IA)."""

from __future__ import annotations

import json
import time
from pathlib import Path

from .. import config as C
from ..coach.messages import say_laptime, say_tenths
from .ai import ai_debrief
from .analysis import analyze
from .setup_advisor import advise


def _fmt(t: float) -> str:
    m, s = divmod(t, 60)
    return f"{int(m)}:{s:06.3f}" if m else f"{s:.3f}"


def find_session(cfg: dict, arg: str | None) -> Path:
    if arg:
        p = Path(arg)
        return p if p.suffix == ".json" else p / "session.json"
    root = C.data_dir(cfg)
    cands = sorted(root.rglob("sessions/*/session.json"), key=lambda p: p.stat().st_mtime)
    if not cands:
        raise SystemExit("No hay sesiones grabadas todavía. Corre primero: python -m lmu_coach run")
    return cands[-1]


def _cn(a: dict, num) -> str:
    name = (a.get("names") or {}).get(str(num)) or (a.get("names") or {}).get(num)
    return f"{num} · {name}" if name else str(num)


def make_chart(sess: dict, base: Path, a: dict) -> str | None:
    """Gráfica mejor vuelta vs vuelta típica → comparacion.svg. Devuelve el nombre del archivo."""
    import gzip
    from .charts import comparison_svg
    valid = [l for l in sess.get("laps", []) if l.get("valid") and l.get("trace_file") and (base / l["trace_file"]).exists()]
    if len(valid) < 2 or not sess.get("reference"):
        return None
    valid.sort(key=lambda l: l["time"])
    best, typ = valid[0], valid[len(valid) // 2]
    if typ is best:
        typ = valid[1]

    def load(l):
        with gzip.open(base / l["trace_file"], "rt", encoding="utf-8") as fh:
            return json.load(fh)
    svg = comparison_svg(load(best), load(typ), sess["reference"]["corners"], a.get("names") or {},
                         f"Mejor vuelta {_fmt(best['time'])} (V{best['lap']})",
                         f"Vuelta típica {_fmt(typ['time'])} (V{typ['lap']})")
    (base / "comparacion.svg").write_text(svg, encoding="utf-8")
    return "comparacion.svg"


def build_markdown(a: dict, advice: list[dict], ai_text: str | None, chart: str | None = None) -> str:
    L = [f"# Debrief — {a.get('track')} · {a.get('car')} ({a.get('session')})", ""]
    if "best" not in a:
        L.append(a.get("note", "Sin datos."))
        return "\n".join(L)
    L += [f"- **Mejor vuelta:** {_fmt(a['best'])}   ·   **Vuelta ideal (suma de mejores curvas):** {_fmt(a['ideal_lap'])}",
          f"- **Promedio:** {_fmt(a['avg'])}   ·   **Consistencia (σ):** {a['consistency_sd']:.3f} s   ·   "
          f"Vueltas válidas: {a['laps_valid']}/{a['laps_total']}",
          f"- Compuesto: {a.get('compound') or '—'}   ·   Aire {a['conditions']['air']:.0f} °C / pista {a['conditions']['track']:.0f} °C",
          ""]
    if a.get("fuel_per_lap"):
        ve = f" · Energía virtual {a['ve_per_lap_pct']} %/vuelta" if a.get("ve_per_lap_pct") else ""
        L += [f"- Consumo: {a['fuel_per_lap']} L/vuelta{ve}", ""]

    if chart:
        L += ["## Tu mejor vuelta contra una vuelta típica", "",
              "Dónde la vuelta típica pierde velocidad y cuánto tiempo acumula frente a la mejor.", "",
              f"![comparación]({chart})", ""]
    L += ["## Dónde se va el tiempo", "", "| Curva | Tipo | Pérdida media | Mejor vs ref | σ v.mín | Balance | Patrón |",
          "|---|---|---|---|---|---|---|"]
    for c in a["corners"][:10]:
        pat = ", ".join(f"{k} ×{v}" for k, v in c["issues"].items()) or "—"
        bal = f"{c['balance']:+.1f}° {'sub' if c['balance'] > 0.5 else ('sobre' if c['balance'] < -0.5 else 'neutro')}"
        L.append(f"| {_cn(a, c['corner'])} | {c['type']} ({c['ref_min_speed']:.0f} km/h) | {c['avg_loss']:+.3f} s | "
                 f"{c['best_time_gain']:+.3f} s | {c['vmin_sd']:.1f} | {bal} | {pat} |")
    if a.get("brake_refs"):
        L += ["", "## Referencias de frenada (tu mejor ejecución de cada curva)", "",
              "| Curva | Frena a … del vértice | Freno pico | Trail braking | Sin pedal | Vel. vértice | Marcha | Dispersión del punto | ABS en frenada | TC en salida |",
              "|---|---|---|---|---|---|---|---|---|---|"]
        for b in a["brake_refs"]:
            if not b.get("braking", True):
                L.append(f"| {_cn(a, b['corner'])} | sin freno (solo levantar) | — | — | — | {b['apex_kmh']} km/h | "
                         f"{str(b['apex_gear']) + 'ª' if b['apex_gear'] else '—'} | — | — | {b.get('tc_pct', 0)} % |")
                continue
            dist = b['brake_to_apex_m']
            dist_s = f"{dist} m" if dist is not None and dist > 0 else "toque corto"
            L.append(f"| {_cn(a, b['corner'])} | {dist_s} | "
                     f"{b['peak_brake_pct']} % | {b['trail_m']} m | {b['coast_m']} m | {b['apex_kmh']} km/h | "
                     f"{str(b['apex_gear']) + 'ª' if b['apex_gear'] else '—'} | ±{b['brake_sd_m']} m | "
                     f"{b.get('abs_pct', 0)} % | {b.get('tc_pct', 0)} % |")
        L += ["", "> Dispersión alta (> ±10 m) = punto de frenada inconsistente: elige una referencia visual fija "
              "(cartel de 100/50 m, marca en el piso) a esa distancia.", ""]
    if a.get("car_aids"):
        c = a["car_aids"]
        L += ["## Ayudas y reparto de freno", "",
              f"- Reparto: {c.get('bias_front') or '—'} % adelante · ABS {c.get('abs_level')}/{c.get('abs_max')} · "
              f"TC {c.get('tc_level')}/{c.get('tc_max')} · TC Slip {c.get('tc_slip')}/{c.get('tc_slip_max')} · "
              f"TC Cut {c.get('tc_cut')}/{c.get('tc_cut_max')}",
              f"- Bloqueo delantero en {c['lock_f']} % de la frenada · inestabilidad trasera {c['lock_r']} % · "
              f"ABS activo {c['abs']} %",
              f"- Patinaje en salida {c['spin']} % · TC activo {c['tc']} % de las salidas",
              f"- Balance al entrar frenando: {c.get('entry_bal') if c.get('entry_bal') is not None else '—'}° "
              f"(+ subviraje, − sobreviraje) · deslizamiento delante/detrás en frenada recta: "
              f"{c.get('brake_ratio') if c.get('brake_ratio') is not None else '—'}×", ""]
    if a.get("rivals_last"):
        r = a["rivals_last"]
        L += ["## Carrera", "", f"- Posición final en clase: P{r.get('class_pos')} de {r.get('n_class')}", ""]
    L += ["", "## Llantas", "", "| | Izq | Centro | Der | Carcasa | Óptima | Presión (kPa) | Desgaste final |", "|---|---|---|---|---|---|---|---|"]
    for w in ("FL", "FR", "RL", "RR"):
        t = a["tyre_temp"][w]
        L.append(f"| {w} | {t[0]:.0f} | {t[1]:.0f} | {t[2]:.0f} | {a.get('tyre_carcass', {}).get(w, 0) or '—'} | {a['tyre_opt'][w] or '—'} | "
                 f"{a['tyre_press'][w]:.0f} | {a['tyre_wear_end'][w]:.2f} |")
    L += ["", "Frenos máx: " + ", ".join(f"{k} {v} °C" for k, v in a["brake_max"].items()),
          (f"Altura mínima: delante {a['ride_min']['front_mm']} mm · detrás {a['ride_min']['rear_mm']} mm"
           if a['ride_min']['front_mm'] else "Altura mínima: LMU no publica este dato para este auto"), ""]

    L += ["## Sugerencias de setup (reglas locales)", ""]
    if advice:
        for s in advice:
            L.append(f"- **{s['area']}** ({s['confianza']}): {s['observacion']} → {s['sugerencia']}")
    else:
        L.append("- Sin señales claras: el coche parece equilibrado con estos datos.")
    L += ["", "> Haz un solo cambio por stint y compara la misma curva en el siguiente debrief.", ""]

    if ai_text:
        L += ["## Ingeniero IA (Claude)", "", ai_text.strip(), ""]
    L += ["## Vueltas", "", "| Vuelta | Tiempo | Válida |", "|---|---|---|"]
    for l in a["laps"]:
        L.append(f"| {l['lap']} | {_fmt(l['time'])} | {'✔' if l['valid'] else '✗'} |")
    return "\n".join(L)


def spoken_summary(a: dict) -> str:
    if "best" not in a:
        return "No hubo vueltas válidas para analizar."
    top = [c for c in a["corners"] if c["avg_loss"] > 0.05][:2]
    s = (f"Mejor vuelta {say_laptime(a['best'])}. La vuelta ideal está {say_tenths(a['best'] - a['ideal_lap'])} abajo. ")
    if top:
        s += "Para el próximo stint trabaja " + " y ".join(f"la curva {c['corner']}" for c in top) + "."
    return s


def run_debrief(cfg: dict, session_arg: str | None, use_ai=True, setup=None, speak=False) -> Path:
    path = find_session(cfg, session_arg)
    sess = json.loads(path.read_text(encoding="utf-8"))
    a = analyze(sess, path.parent)
    try:
        from ..coach.track import Corner
        from ..tracks import corner_names
        ref = sess.get("reference") or {}
        if ref.get("corners"):
            names = corner_names(path.parent.parent.parent, sess.get("track", ""),
                                 [Corner(**c) for c in ref["corners"]], ref.get("length", 0))
            a["names"] = {str(k): v for k, v in names.items()}
    except Exception:  # noqa: BLE001
        pass
    adv = advise(a)
    try:
        chart = make_chart(sess, path.parent, a)
    except Exception:  # noqa: BLE001
        chart = None
    if not setup and (path.parent / "setup.svm").exists():
        setup = str(path.parent / "setup.svm")
    ai_text = ai_debrief(cfg, a, adv, setup) if use_ai and "best" in a else None
    md = build_markdown(a, adv, ai_text, chart)
    try:
        from ..setups import setup_markdown
        extra = setup_markdown(path.parent)
        if extra:
            md = md.replace("## Sugerencias de setup", "\n".join(extra) + "\n## Sugerencias de setup", 1)
    except Exception:  # noqa: BLE001
        pass
    out = path.parent / "debrief.md"
    out.write_text(md, encoding="utf-8")
    (path.parent / "analysis.json").write_text(json.dumps({"analysis": a, "advice": adv}, ensure_ascii=False, indent=1),
                                               encoding="utf-8")
    print(md)
    print(f"\nGuardado: {out}")
    if speak:
        from ..voice import make_backend
        b = make_backend(cfg["voz"]["backend"], voice=cfg["voz"]["voz"], rate=cfg["voz"]["velocidad"],
                         volume=cfg["voz"]["volumen"])
        b.speak(spoken_summary(a))
        time.sleep(8)
    return out
