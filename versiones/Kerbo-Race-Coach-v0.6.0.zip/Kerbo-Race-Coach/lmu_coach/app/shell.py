"""Integración con Windows: icono propio en la barra de tareas y acceso directo del Escritorio."""

from __future__ import annotations

import os
import sys
from pathlib import Path

APP_ID = "Kerbo.RaceCoach"
APP_NAME = "Kerbo Race Coach"
OLD_NAMES = ("LMU Race Coach.lnk",)
ROOT = Path(__file__).resolve().parent.parent.parent


def set_app_id() -> None:
    """Sin esto Windows agrupa la ventana con pythonw.exe y muestra el icono de Python."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:  # noqa: BLE001
        pass


def _pythonw() -> str:
    exe = Path(sys.executable)
    if exe.name.lower() == "python.exe" and (exe.parent / "pythonw.exe").exists():
        exe = exe.parent / "pythonw.exe"
    return str(exe)


def ensure_shortcut(log=lambda m: None) -> None:
    """Crea/actualiza 'Kerbo Race Coach' en el Escritorio y quita el acceso viejo de esta misma instalación."""
    if sys.platform != "win32":
        return
    try:
        import win32com.client
        sh = win32com.client.Dispatch("WScript.Shell")
        desk = Path(sh.SpecialFolders("Desktop"))
        target, icon = _pythonw(), str(ROOT / "assets" / "icon.ico")
        new = desk / f"{APP_NAME}.lnk"
        lnk = sh.CreateShortcut(str(new))
        if not new.exists() or lnk.TargetPath.lower() != target.lower() or lnk.IconLocation.split(",")[0] != icon:
            lnk.TargetPath = target
            lnk.Arguments = "-m lmu_coach"
            lnk.WorkingDirectory = str(ROOT)
            lnk.IconLocation = icon
            lnk.Description = APP_NAME
            lnk.Save()
            log(f"acceso directo actualizado: {new}")
        for name in OLD_NAMES:
            old = desk / name
            if not old.exists():
                continue
            o = sh.CreateShortcut(str(old))
            # solo el acceso que apunta a ESTA instalación (no tocar otros)
            if Path(o.WorkingDirectory or ".").resolve() == ROOT.resolve() and "lmu_coach" in (o.Arguments or ""):
                os.remove(old)
                log(f"acceso directo viejo eliminado: {old}")
    except Exception as e:  # noqa: BLE001
        log(f"no se pudo actualizar el acceso directo: {e}")
