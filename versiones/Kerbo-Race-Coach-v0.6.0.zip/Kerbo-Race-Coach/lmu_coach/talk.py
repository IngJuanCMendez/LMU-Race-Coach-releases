"""Hablarle al coach (beta): push-to-talk + reconocimiento de comandos en español.

- Botón: tecla del teclado o botón del volante/joystick (API winmm de Windows, sin librerías extra).
- Reconocimiento: System.Speech de Windows con una gramática de comandos (rápido, offline).
  Requiere el reconocimiento de voz en español instalado en Windows
  (Configuración → Hora e idioma → Idioma → Español → Opciones → Reconocimiento de voz).
- Solo se aceptan frases dichas mientras el botón está presionado (o hasta `ventana_s` después).
"""

from __future__ import annotations

import ctypes
import subprocess
import sys
import threading
import time
import unicodedata

from .coach.messages import CUE, say_gap, say_laps, say_laptime, say_tenths

# ---------------------------------------------------------------- intenciones
INTENTS = {
    "fuel": ["combustible", "cuánto combustible", "cuanto combustible", "gasolina", "energía", "energia",
             "cuántas vueltas de combustible"],
    "tyres": ["llantas", "cómo van las llantas", "como van las llantas", "neumáticos", "gomas", "presiones"],
    "gaps": ["brechas", "cómo voy", "como voy", "posición", "posicion", "rivales", "quién viene", "quien viene"],
    "lap": ["tiempo", "última vuelta", "ultima vuelta", "mi tiempo", "tiempos"],
    "where": ["dónde pierdo", "donde pierdo", "dónde pierdo tiempo", "donde pierdo tiempo", "dónde mejoro",
              "donde mejoro", "qué mejoro", "que mejoro"],
    "aids": ["ayudas", "frenos", "control de tracción", "abs", "reparto de freno", "tc"],
    "remaining": ["cuánto falta", "cuanto falta", "cuántas vueltas faltan", "cuantas vueltas faltan", "vueltas restantes"],
    "less": ["habla menos", "menos charla", "cállate un poco"],
    "more": ["habla más", "habla mas", "más charla", "mas charla"],
    "silence": ["silencio", "cállate", "callate", "modo silencio"],
    "coach": ["modo coach", "ayúdame", "ayudame", "modo entrenador"],
    "strategy": ["estrategia", "cuándo paro", "cuando paro", "paradas", "plan de carrera", "cuándo entro", "cuando entro"],
    "consistency": ["modo consistencia", "entrenar consistencia", "consistencia"],
    "repeat": ["repite", "repítelo", "repitelo", "otra vez", "qué dijiste", "que dijiste"],
}


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn").strip(" ?¿!¡.,")


_LOOKUP = {_norm(p): k for k, ps in INTENTS.items() for p in ps}


def match_intent(text: str) -> str | None:
    t = _norm(text)
    if t in _LOOKUP:
        return _LOOKUP[t]
    for p, k in sorted(_LOOKUP.items(), key=lambda kv: -len(kv[0])):
        if p in t:
            return k
    return None


def answer(intent: str, engine) -> str:
    """Respuesta hablada a partir del estado actual del coach."""
    st = engine.state()
    f = st["frame"]
    if f is None:
        return "Todavía no tengo datos del auto."
    if intent == "fuel":
        parts = [f"Tienes {f.fuel:.1f} litros".replace(".", " punto ")]
        if st["fuel_laps"]:
            parts.append(f"para {say_laps(st['fuel_laps'])}")
        if f.virtual_energy > 0:
            parts.append(f"y {f.virtual_energy * 100:.0f} por ciento de energía virtual")
        return " ".join(parts) + "."
    if intent == "tyres":
        names = ["delantera izquierda", "delantera derecha", "trasera izquierda", "trasera derecha"]
        temps = [(f.tyre_carcass[i] if f.tyre_carcass[i] > 0 else sum(f.tyre_temp[i]) / 3) for i in range(4)]
        hot = max(range(4), key=lambda i: temps[i])
        cold = min(range(4), key=lambda i: temps[i])
        return (f"Delanteras {temps[0]:.0f} y {temps[1]:.0f} grados, traseras {temps[2]:.0f} y {temps[3]:.0f}. "
                f"La más caliente es la {names[hot]}, la más fría la {names[cold]}. "
                f"Presiones alrededor de {sum(f.tyre_press) / 4:.0f} kilopascales.")
    if intent == "gaps":
        r = st["rivals"]
        if not r.get("class_pos"):
            return "No tengo datos de rivales en esta sesión."
        s = f"P{r['class_pos']} de {r['n_class']} en tu clase."
        if r.get("ahead") and r.get("gap_ahead") is not None:
            s += f" Adelante {r['ahead']} a {say_gap(r['gap_ahead'])}."
        if r.get("behind") and r.get("gap_behind") is not None:
            s += f" Atrás {r['behind']} a {say_gap(r['gap_behind'])}."
        return s
    if intent == "lap":
        if f.last_lap > 0:
            s = f"Última vuelta {say_laptime(f.last_lap)}."
            if st["best"]:
                d = f.last_lap - st["best"]
                s += f" Tu mejor es {say_laptime(st['best'])}" + ("." if abs(d) < 0.05 else f", estás a {say_tenths(d)}.")
            return s
        return "Todavía no completas una vuelta."
    if intent == "where":
        cs = [c for c in st["corners"] if c["avg"] and c["avg"] > 0.05]
        cs.sort(key=lambda c: -c["avg"])
        if not cs:
            return "No veo pérdidas claras. Sigue así."
        from .coach.engine import SHORT_TIP
        top = cs[:3]
        return " ".join(f"{engine.cname(c['num'])}, {say_tenths(c['avg'])}: {SHORT_TIP.get(c['kind'], 'revisa la línea')}."
                        for c in top)
    if intent == "aids":
        c = st["car"]
        from .coach.car_advisor import CarAdvisor
        bias = f"Reparto {CarAdvisor._pct(c['bias_front'])} adelante. " if c.get("bias_front") else ""
        tc = f"TC {c['tc_level']}, slip {c['tc_slip']}, cut {c['tc_cut']}" if c.get("tc_max") else "sin TC"
        abs_ = f"ABS {c['abs_level']}" if c.get("abs_max") else "sin ABS"
        return f"{bias}{abs_}. {tc}."
    if intent == "strategy":
        return engine.strategy.summary_text()
    if intent == "consistency":
        return engine.start_consistency()
    if intent == "remaining":
        if 0 < f.max_laps < 10000:
            return f"Faltan {say_laps(max(0, f.max_laps - f.lap))}."
        if f.time_remaining > 0:
            m = int(f.time_remaining // 60)
            return f"Faltan {m} minutos." if m else f"Faltan {int(f.time_remaining)} segundos."
        return "No sé cuánto falta en esta sesión."
    key = "charla_carrera" if f.is_race else "charla"
    if intent in ("less", "more", "silence", "coach"):
        cur = int(engine.c.get(key, 3))
        new = {"less": max(0, cur - 1), "more": min(4, cur + 1), "silence": 0, "coach": 3}[intent]
        engine.c[key] = new
        from .coach.engine import CHAT_LEVELS
        return f"Entendido. Nivel {CHAT_LEVELS[new]}." if new else "Entendido, solo banderas y peligro."
    if intent == "repeat":
        hist = engine.q.history
        return hist[-1][1] if hist else "No he dicho nada todavía."
    return "No te entendí."


# ---------------------------------------------------------------- botones (Windows)
class _JOYINFOEX(ctypes.Structure):
    _fields_ = [("dwSize", ctypes.c_uint32), ("dwFlags", ctypes.c_uint32), ("dwXpos", ctypes.c_uint32),
                ("dwYpos", ctypes.c_uint32), ("dwZpos", ctypes.c_uint32), ("dwRpos", ctypes.c_uint32),
                ("dwUpos", ctypes.c_uint32), ("dwVpos", ctypes.c_uint32), ("dwButtons", ctypes.c_uint32),
                ("dwButtonNumber", ctypes.c_uint32), ("dwPOV", ctypes.c_uint32),
                ("dwReserved1", ctypes.c_uint32), ("dwReserved2", ctypes.c_uint32)]


def joy_buttons(joy_id: int) -> int | None:
    """Máscara de botones del joystick `joy_id` (0..15) o None si no existe."""
    if sys.platform != "win32":
        return None
    info = _JOYINFOEX()
    info.dwSize = ctypes.sizeof(_JOYINFOEX)
    info.dwFlags = 0x80  # JOY_RETURNBUTTONS
    if ctypes.windll.winmm.joyGetPosEx(joy_id, ctypes.byref(info)) != 0:
        return None
    return info.dwButtons


def key_down(vk: int) -> bool:
    if sys.platform != "win32":
        return False
    return bool(ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000)


def detect_button(timeout: float = 6.0):
    """Espera a que el usuario presione un botón del volante o una tecla. Devuelve ('joystick', id, boton) o ('teclado', vk)."""
    base = {j: joy_buttons(j) or 0 for j in range(16)}
    t0 = time.time()
    while time.time() - t0 < timeout:
        for j in range(16):
            b = joy_buttons(j)
            if b is None:
                continue
            new = b & ~base[j]
            if new:
                return ("joystick", j, (new & -new).bit_length() - 1)
        for vk in range(0x08, 0xFF):
            if vk in (0x01, 0x02, 0x04) or not key_down(vk):
                continue
            return ("teclado", vk)
        time.sleep(0.02)
    return None


# ---------------------------------------------------------------- reconocimiento
_PS_TEMPLATE = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$rec = $null
foreach ($c in @('es-MX','es-ES','es-US','es-CO')) {
  foreach ($r in [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()) {
    if ($r.Culture.Name -eq $c) { $rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine($r); break }
  }
  if ($rec) { break }
}
if (-not $rec) {
  foreach ($r in [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()) {
    if ($r.Culture.TwoLetterISOLanguageName -eq 'es') { $rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine($r); break }
  }
}
if (-not $rec) { [Console]::Out.WriteLine('ERROR|sin reconocedor en español'); exit 2 }
$choices = New-Object System.Speech.Recognition.Choices
@(__PHRASES__) | ForEach-Object { $choices.Add($_) }
$gb = New-Object System.Speech.Recognition.GrammarBuilder($choices)
$gb.Culture = $rec.RecognizerInfo.Culture
$cmd = New-Object System.Speech.Recognition.Grammar($gb)
$cmd.Name = 'cmd'
$cmd.Weight = 1.0
$rec.LoadGrammar($cmd)
if ($env:LMU_DICTADO -eq '1') {
  try { $dg = New-Object System.Speech.Recognition.DictationGrammar; $dg.Name = 'dict'; $dg.Weight = 0.4; $rec.LoadGrammar($dg) } catch {}
}
$rec.SetInputToDefaultAudioDevice()
[Console]::Out.WriteLine('READY|' + $rec.RecognizerInfo.Culture.Name)
while ($true) {
  $res = $rec.Recognize([TimeSpan]::FromSeconds(30))
  if ($res -ne $null) { [Console]::Out.WriteLine('RESULT|' + $res.Text + '|' + $res.Confidence + '|' + $res.Grammar.Name) }
}
"""


class TalkListener(threading.Thread):
    def __init__(self, cfg: dict, engine, log=print):
        super().__init__(daemon=True, name="talk")
        self.cfg = cfg["hablar"]
        self.cfg_all = cfg
        self.engine = engine
        self.log = log
        self._stop = threading.Event()
        self.proc = None
        self.status = "iniciando"
        self.last_heard = ""
        self._ptt_until = 0.0
        self._ptt_down = False

    def stop(self) -> None:
        self._stop.set()
        if self.proc:
            try:
                self.proc.kill()
            except Exception:  # noqa: BLE001
                pass

    def _ask(self, question: str) -> None:
        try:
            from .debrief.ai import ask_radio
            self.engine.say("Déjame ver.", CUE, "askwait", ttl=3)
            ans = ask_radio(self.cfg_all, question, self.engine)
            if ans:
                self.engine.say(ans, CUE, "ask", ttl=15)
        except Exception as e:  # noqa: BLE001
            self.log(f"hablar: error en pregunta libre: {e}")
            self.engine.say("No pude consultar eso ahora.", CUE, "ask", ttl=5)

    def ptt_pressed(self) -> bool:
        c = self.cfg
        if c.get("dispositivo") == "joystick":
            b = joy_buttons(int(c.get("joystick", 0)))
            return bool(b is not None and b & (1 << int(c.get("boton", 0))))
        return key_down(int(c.get("tecla", 0x14)))

    def _ptt_loop(self) -> None:
        import winsound
        while not self._stop.is_set():
            down = self.ptt_pressed()
            if down and not self._ptt_down:
                threading.Thread(target=winsound.Beep, args=(880, 70), daemon=True).start()
            if down:
                self._ptt_until = time.time() + float(self.cfg.get("ventana_s", 2.0))
            self._ptt_down = down
            time.sleep(0.03)

    def run(self) -> None:
        if sys.platform != "win32":
            self.status = "solo Windows"
            return
        phrases = ",".join("'" + p.replace("'", "''") + "'" for ps in INTENTS.values() for p in ps)
        script = _PS_TEMPLATE.replace("__PHRASES__", phrases)
        import os
        env = dict(os.environ)
        self.dictation = bool(os.environ.get("ANTHROPIC_API_KEY")) and self.cfg.get("preguntas_libres", True)
        env["LMU_DICTADO"] = "1" if self.dictation else "0"
        self.proc = subprocess.Popen(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="ignore",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        threading.Thread(target=self._ptt_loop, daemon=True).start()
        for line in self.proc.stdout:
            if self._stop.is_set():
                break
            line = line.strip()
            if line.startswith("READY|"):
                self.status = f"escuchando ({line.split('|')[1]})"
                self.log(f"hablar: {self.status}")
            elif line.startswith("ERROR|"):
                self.status = "falta reconocimiento de voz en español"
                self.log("hablar: " + line)
            elif line.startswith("RESULT|"):
                _, text, conf, gram = (line.split("|") + ["0", "cmd"])[:4]
                if time.time() > self._ptt_until:
                    continue  # se habló sin presionar el botón
                try:
                    c = float(conf.replace(",", "."))
                except ValueError:
                    c = 1.0
                intent = match_intent(text)
                if intent and c >= 0.5:
                    self.last_heard = text
                    self.log(f"hablar: oí '{text}' → {intent}")
                    self.engine.say(answer(intent, self.engine), CUE, "ask", ttl=8)
                elif self.dictation and len(text.split()) >= 2 and c >= 0.25:
                    self.last_heard = text
                    self.log(f"hablar: pregunta libre '{text}'")
                    threading.Thread(target=self._ask, args=(text,), daemon=True).start()
        if self.status.startswith("iniciando"):
            self.status = "no se pudo iniciar el reconocimiento"
