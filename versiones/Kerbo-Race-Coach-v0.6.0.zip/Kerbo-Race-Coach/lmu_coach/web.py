"""Panel para el celular: servidor web local con el estado en vivo.

Abre http://<IP-del-PC>:<puerto> desde el navegador del celular conectado a la misma red Wi-Fi.
Solo lectura; no expone archivos.
"""

from __future__ import annotations

import json
from pathlib import Path
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ICON = Path(__file__).resolve().parent.parent / "assets" / "icon.png"

PAGE = """<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Kerbo Race Coach</title><link rel="icon" href="/icon.png"><link rel="apple-touch-icon" href="/icon.png">
<style>
:root{--bg:#0e1014;--p:#161a21;--l:#262c37;--t:#e8ebf0;--m:#8a93a3;--a:#ff7a1a;--g:#2ecc71;--r:#e74c3c;--b:#3fa7ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--t);font-family:system-ui,Segoe UI,sans-serif;
padding:12px;padding-top:max(12px,env(safe-area-inset-top))}
.g{display:grid;grid-template-columns:1fr 1fr;gap:10px}.c{background:var(--p);border:1px solid var(--l);border-radius:12px;padding:12px}
.k{font-size:11px;color:var(--m);letter-spacing:1px;text-transform:uppercase}.v{font-size:30px;font-weight:700;font-variant-numeric:tabular-nums}
.s{font-size:14px;color:var(--m)}.w{grid-column:1/3}.big{font-size:56px;font-weight:800;font-variant-numeric:tabular-nums}
.ty{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px}.ty div{background:#1d222b;border-radius:8px;padding:6px;text-align:center;font-weight:700}
#radio div{padding:6px 0;border-bottom:1px solid var(--l);font-size:14px}h1{font-size:16px;margin:0 0 10px}h1 b{color:var(--a)}
</style></head><body><h1><b>Kerbo</b> Race Coach · <span id="st">…</span></h1>
<div class="g">
<div class="c w"><div class="k">Delta contra tu mejor</div><div class="big" id="delta">—</div><div class="s" id="lap">—</div></div>
<div class="c"><div class="k">Posición</div><div class="v" id="pos">—</div><div class="s" id="gaps">—</div></div>
<div class="c"><div class="k">Energía</div><div class="v" id="fuel">—</div><div class="s" id="fl">—</div></div>
<div class="c"><div class="k">Llantas °C</div><div class="ty" id="ty"></div></div>
<div class="c"><div class="k">Ayudas</div><div class="s" id="aids" style="font-size:16px;color:var(--t)">—</div></div>
<div class="c w"><div class="k">Próximo aviso</div><div class="v" style="font-size:20px" id="tip">—</div></div>
<div class="c w"><div class="k">Radio</div><div id="radio"></div></div>
</div>
<script>
function f(t){if(!t||t<=0)return"-:--.---";const m=Math.floor(t/60),s=(t-60*m).toFixed(3).padStart(6,"0");return m+":"+s}
async function tick(){try{const r=await fetch("state",{cache:"no-store"});const d=await r.json();
document.getElementById("st").textContent=d.status||"";
if(d.delta!=null){const e=document.getElementById("delta");e.textContent=(d.delta>0?"+":"")+d.delta.toFixed(2);
e.style.color=Math.abs(d.delta)<0.05?"var(--t)":(d.delta<0?"var(--g)":"var(--r)")}
document.getElementById("lap").textContent="Vuelta "+(d.lap||"—")+" · última "+f(d.last)+" · mejor "+f(d.best);
document.getElementById("pos").textContent=d.pos?("P"+d.pos+"/"+d.n):"—";
document.getElementById("gaps").textContent=(d.ahead?("▲ "+d.ahead+" +"+d.ga.toFixed(1)):"")+(d.behind?("  ▼ "+d.behind+" −"+d.gb.toFixed(1)):"");
document.getElementById("fuel").textContent=d.ve!=null?(d.ve+"%"):(d.fuel!=null?d.fuel.toFixed(1)+" L":"—");
document.getElementById("fl").textContent=d.fuel_laps?(d.fuel_laps.toFixed(1)+" vueltas"):"";
document.getElementById("ty").innerHTML=(d.tyres||[]).map(t=>"<div>"+Math.round(t)+"°</div>").join("");
document.getElementById("aids").textContent=d.aids||"—";document.getElementById("tip").textContent=d.tip||"—";
document.getElementById("radio").innerHTML=(d.radio||[]).map(x=>"<div>"+x+"</div>").join("");
}catch(e){document.getElementById("st").textContent="sin conexión"}}
setInterval(tick,500);tick();
</script></body></html>"""


def local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def snapshot(runner) -> dict:
    out = {"status": runner.status if runner else "detenido"}
    e = runner.engine if runner else None
    if not e:
        return out
    st = e.state()
    f = st["frame"]
    if f is None:
        return out
    rv = st["rivals"]
    aids = []
    if f.brake_bias_rear > 0:
        aids.append(f"Reparto {(1 - f.brake_bias_rear) * 100:.1f}%")
    for name, v, mx in (("ABS", f.abs_level, f.abs_max), ("TC", f.tc_level, f.tc_max),
                        ("Slip", f.tc_slip, f.tc_slip_max), ("Cut", f.tc_cut, f.tc_cut_max)):
        if mx:
            aids.append(f"{name} {v}")
    nxt = e.next_tip() if hasattr(e, "next_tip") else ""
    out.update({"delta": st.get("delta"), "lap": f.lap, "last": f.last_lap, "best": st["best"],
                "pos": rv.get("class_pos"), "n": rv.get("n_class"), "ahead": rv.get("ahead"), "ga": rv.get("gap_ahead") or 0,
                "behind": rv.get("behind"), "gb": rv.get("gap_behind") or 0, "fuel": f.fuel,
                "ve": round(f.virtual_energy * 100) if f.virtual_energy > 0 else None, "fuel_laps": st["fuel_laps"],
                "tyres": [f.tyre_carcass[i] if f.tyre_carcass[i] > 0 else sum(f.tyre_temp[i]) / 3 for i in range(4)],
                "aids": " · ".join(aids), "tip": nxt, "radio": [t for _, t, _ in list(runner.radio)[:6]]})
    return out


class PhoneServer:
    def __init__(self, get_runner, port: int = 8765):
        self.get_runner = get_runner
        self.port = port
        self.httpd = None

    def start(self) -> str:
        get_runner = self.get_runner

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                if self.path.startswith("/state"):
                    body = json.dumps(snapshot(get_runner()), ensure_ascii=False, default=float).encode("utf-8")
                    ctype = "application/json; charset=utf-8"
                elif self.path in ("/", "/index.html"):
                    body, ctype = PAGE.encode("utf-8"), "text/html; charset=utf-8"
                elif self.path == "/icon.png" and ICON.exists():
                    body, ctype = ICON.read_bytes(), "image/png"
                else:
                    self.send_response(404)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

        self.httpd = ThreadingHTTPServer(("0.0.0.0", self.port), H)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return f"http://{local_ip()}:{self.port}"

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
