"""Publica la versión actual en el repo público de versiones.

Uso:  python tools/publish_release.py RUTA_CLON_RELEASES "nota 1" "nota 2" ...

Copia dist/Kerbo-Race-Coach-vX.Y.Z.zip a versiones/, actualiza latest.json (lo que lee
el actualizador de la app) y el README con la lista de novedades. Después hay
que hacer commit y push en el clon del repo de versiones.
"""
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from lmu_coach import __version__  # noqa: E402

rel = Path(sys.argv[1])
notes = sys.argv[2:]
zip_name = f"Kerbo-Race-Coach-v{__version__}.zip"
src = ROOT / "dist" / zip_name
if not src.exists():
    sys.exit(f"Falta {src}: corre primero python tools/make_release.py")
(rel / "versiones").mkdir(exist_ok=True)
shutil.copy2(src, rel / "versiones" / zip_name)
bullets = "\n".join(f"- {n}" for n in notes)
(rel / "latest.json").write_text(json.dumps({"version": __version__, "file": f"versiones/{zip_name}", "notes": bullets},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
readme = f"""# Kerbo Race Coach

Ingeniero de pista por voz para **Le Mans Ultimate** e **iRacing**: te dice en qué curva pierdes tiempo y qué hacer distinto, ajusta contigo reparto de freno, ABS y TC, sigue a tus rivales y genera un debrief después de cada sesión.

## Descargar

**Última versión: [{zip_name}](versiones/{zip_name})** (botón *Download raw file* en la página del archivo).

1. Descomprime el zip en `Documentos`.
2. Ejecuta `instalar.bat` (instala Python si hace falta y crea el acceso directo **Kerbo Race Coach** en el Escritorio).
3. En LMU: *Settings → Gameplay → Enable Plugins = ON*. En iRacing no hay que configurar nada.
4. Voz en español: ejecuta `instalar_voz_espanol.bat`.

La app se actualiza sola desde aquí (*Ajustes → Buscar actualizaciones*), conservando tus sesiones y tu configuración.

## Novedades v{__version__}

{bullets}

---
Proyecto independiente, sin relación con Le Mans Ultimate, iRacing ni sus desarrolladores. Beta.
"""
(rel / "README.md").write_text(readme, encoding="utf-8")
print(f"Listo: v{__version__} en {rel}")
