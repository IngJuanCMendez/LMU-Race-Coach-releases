"""Genera el icono de Kerbo Race Coach (kerb rojo/blanco en curva + K naranja)."""
import math
import sys
from PIL import Image, ImageDraw, ImageFilter

S = 1024
BG = (22, 26, 33)
EDGE = (38, 44, 55)
ORANGE = (255, 122, 26)
RED = (226, 45, 38)
WHITE = (245, 246, 248)


def rounded_bg(img):
    d = ImageDraw.Draw(img)
    r = int(S * 0.22)
    d.rounded_rectangle([0, 0, S - 1, S - 1], r, fill=BG)
    d.rounded_rectangle([8, 8, S - 9, S - 9], r - 8, outline=EDGE, width=10)


def kerb(img):
    """Banda curva (vértice de curva) con franjas rojo/blanco alternadas."""
    d = ImageDraw.Draw(img)
    cx, cy = S * 0.98, S * 1.02        # centro de la curva, abajo a la derecha
    r_out, r_in = S * 0.80, S * 0.64
    a0, a1 = 180.0, 270.0
    n = 9
    step = (a1 - a0) / n
    for i in range(n):
        s0, s1 = math.radians(a0 + i * step), math.radians(a0 + (i + 1) * step)
        pts = []
        for k in range(13):
            a = s0 + (s1 - s0) * k / 12
            pts.append((cx + r_out * math.cos(a), cy + r_out * math.sin(a)))
        for k in range(13):
            a = s1 - (s1 - s0) * k / 12
            pts.append((cx + r_in * math.cos(a), cy + r_in * math.sin(a)))
        d.polygon(pts, fill=RED if i % 2 == 0 else WHITE)


def letter_k(img):
    """K geométrica en cursiva (sin fuente) para que se lea en 16 px."""
    d = ImageDraw.Draw(img)
    sl = 0.18                         # inclinación
    x0, top, bot = S * 0.20, S * 0.17, S * 0.66
    w = S * 0.115

    def sk(x, y):                      # aplica la inclinación respecto a la base
        return (x + (bot - y) * sl, y)

    stem = [sk(x0, top), sk(x0 + w, top), sk(x0 + w, bot), sk(x0, bot)]
    mid = top + (bot - top) * 0.56
    arm = [sk(x0 + w * 0.5, mid + S * 0.03), sk(x0 + w * 0.5, mid - S * 0.05), sk(x0 + w * 0.85 + S * 0.25, top), sk(x0 + w * 0.85 + S * 0.25 + w * 1.25, top),
           sk(x0 + w * 0.85 + w * 1.15, mid + S * 0.02)]
    leg = [sk(x0 + w * 1.55, mid - S * 0.07), sk(x0 + w * 0.85 + S * 0.27 + w * 1.25, bot),
           sk(x0 + w * 0.85 + S * 0.27, bot), sk(x0 + w * 0.5, mid + S * 0.08), sk(x0 + w * 0.5, mid - S * 0.02)]
    shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    for poly in (stem, arm, leg):
        sd.polygon([(x + 14, y + 18) for x, y in poly], fill=(0, 0, 0, 150))
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(14)))
    d = ImageDraw.Draw(img)
    for poly in (stem, arm, leg):
        d.polygon(poly, fill=ORANGE)


def make(out_dir="."):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rounded_bg(img)
    layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    kerb(layer)
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([14, 14, S - 15, S - 15], int(S * 0.21), fill=255)
    img.paste(layer, (0, 0), Image.composite(layer.split()[3], Image.new("L", (S, S), 0), mask))
    letter_k(img)
    img.save(f"{out_dir}/icon_1024.png")
    img.resize((256, 256), Image.LANCZOS).save(f"{out_dir}/icon.png")
    img.save(f"{out_dir}/icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    sheet = Image.new("RGBA", (16 + 32 + 48 + 256 + 60, 256), (240, 240, 240, 255))
    x = 0
    for s in (16, 32, 48, 256):
        sheet.paste(img.resize((s, s), Image.LANCZOS), (x, 256 - s))
        x += s + 20
    sheet.save(f"{out_dir}/preview.png")


if __name__ == "__main__":
    make(sys.argv[1] if len(sys.argv) > 1 else ".")
