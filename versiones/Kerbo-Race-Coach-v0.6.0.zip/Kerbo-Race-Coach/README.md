# Kerbo Race Coach 🏁🎙️

Ingeniero de pista por voz para **Le Mans Ultimate** e **iRacing**. Lee la telemetría del simulador en vivo,
aprende tu mejor vuelta y te dice **en qué curva pierdes tiempo, por qué, y qué hacer distinto**,
hablándote solo en las rectas. Después de la sesión genera un **debrief** con sugerencias de setup
(reglas locales + Claude opcional).

Funciona con todas las clases: no tiene nada cableado por coche, aprende de tus vueltas.

## Novedades v0.6

- **Nuevo nombre: Kerbo Race Coach**, con icono propio (ya no sale el de Python en la barra de tareas).
  Al abrir la app se crea el acceso directo *Kerbo Race Coach* en el Escritorio y se quita el viejo.
- **Compatibilidad con iRacing**: la app detecta sola si está abierto LMU o iRacing (o elige uno en
  *Ajustes → Simulador*). iRacing no necesita configurar nada.
  - Funciona igual: coaching por curva y avisos anticipados, delta, rivales y multiclase, combustible, estrategia,
    banderas, lluvia, consistencia, comparar con amigos, debrief e IA.
  - Limitaciones (datos que iRacing no publica en vivo): no hay deslizamiento por rueda, así que los bloqueos
    no se detectan directamente y el patinaje en salida se estima con la deriva trasera; no hay señal de "TC
    actuando" ni temperatura de frenos; llantas (temperatura, presión, desgaste) solo se actualizan en pits;
    TC 1 / TC 2 / ABS se leen pero iRacing no dice cuál es el máximo; los setups .sto no se guardan.

## Novedades v0.5

- **Estrategia de carrera**: ventana de pits, cuánta energía/combustible cargar, aviso de entrar, undercut/overcut cuando paran los rivales, desgaste de llantas y degradación de ritmo. Di «estrategia» por radio.
- **Clima**: aviso de lluvia y humedad, cuándo pasar a llantas de lluvia o volver a slicks; con pista mojada se suspende la comparación contra tu vuelta en seco.
- **Modo consistencia**: 5 vueltas seguidas lo más parejas posible y en qué curva varías más (botón *Consistencia* o «modo consistencia»).
- **Comparar contra un amigo**: *Sesiones → Exportar mi vuelta* / *Importar vuelta de un amigo* y en *Coach → Comparar contra*.
- **Mi progreso**: mejor vuelta y consistencia por pista y auto a lo largo de las sesiones.
- **Biblioteca de setups**: cada sesión guarda el .svm usado y el debrief muestra qué cambió respecto a la anterior.
- **Ingeniero de setup (IA)**: marcas lo que sientes en el auto y Claude lo cruza con tus datos y tu setup.
- **Preguntas libres por radio**: con el botón presionado pregunta lo que quieras («¿por qué pierdo en Bus Stop?»); Claude responde con tus datos.
- **Overlay** siempre encima del juego (simulador en ventana o sin bordes) y **panel en el celular** (*Ajustes → Panel en el celular*).

## La app (v0.3)

Abre **Kerbo Race Coach** desde el Escritorio (el instalador crea el acceso directo):

- **En vivo**: tiempo de vuelta y delta, posición en clase con brechas, energía y vueltas restantes,
  llantas, reparto/ABS/TC/TC Slip/TC Cut, pedales, tabla de curvas (pérdida, qué mejorar, ★ = aviso
  anticipado activo) y la *radio* con todo lo que dice el ingeniero.
- **Coach**: nivel de charla (0 Silencio · 1 Mínimo · 2 Ingeniero · 3 Coach · 4 Máximo) por separado para
  práctica y carrera, avisos antes de las curvas, voz, y **hablarle al coach** (beta).
- **Sesiones**: historial y debrief con un clic (con o sin IA, con tu setup .svm).
- **Ajustes**: clave de Claude, actualizaciones, diagnóstico.
- **Demo**: carrera simulada con rivales para ver y oír todo sin el juego.

### Hablarle al coach (beta)
Asigna un botón del volante (o una tecla) en *Coach → Asignar botón*, mantenlo presionado y di:
«combustible», «llantas», «cómo voy», «mi tiempo», «dónde pierdo tiempo», «ayudas», «cuánto falta»,
«habla menos», «habla más», «silencio», «modo coach», «repite». Usa el reconocimiento de voz en español
de Windows (sin internet).

### Actualizaciones
La app busca versiones nuevas en el repositorio de GitHub configurado en *Ajustes*. Para publicar una:
`python tools/make_release.py` → crea `dist/Kerbo-Race-Coach-vX.Y.Z.zip` → súbelo como release con el tag `vX.Y.Z`.
La actualización conserva `datos/` y tu `config.toml`.

## Qué hace en pista

| Momento | Ejemplo de lo que escuchas |
|---|---|
| Al salir de una curva donde perdiste | "Curva 4: frenaste 46 metros antes que tu referencia, 4 décimas. Puedes aguantar más la frenada." |
| Vuelta siguiente, 3 s antes de la frenada | "Curva 4, aguanta la frenada" |
| Cuando lo corriges | "Curva 4 corregida, bien." |
| Fin de vuelta | "1 19 punto 8, más 4 décimas. Lo que más cuesta: curva 4, 4 décimas." |
| Nueva mejor vuelta | "Nueva mejor vuelta, 1 19 punto 3, 1 punto 2 segundos más rápida." |
| Llantas | "Delanteras frías, 12 grados bajo la ventana." |
| Combustible / energía virtual | "Energía para 6 vueltas." · "Para llegar sin parar ahorra 0 punto 3 litros por vuelta." |
| Banderas (interrumpe) | "Bandera azul, deja pasar." · "Amarilla en este sector, cuidado." |
| Límites / vuelta inválida | "Cuidado con los límites de pista." · "Vuelta invalidada." |

Diagnósticos por curva: frenada tarde, frenada temprana, poca velocidad en el vértice,
aceleración tardía, bloqueo de delanteras y patinaje de traseras.

**Nunca habla frenando ni en curva** (salvo banderas): espera a que estés en recta con el acelerador abajo.
En carrera baja la verbosidad automáticamente (solo pérdidas grandes, sin felicitaciones).

## Instalación (Windows)

1. Instala **Python 3.11 o superior** desde python.org (marca *Add Python to PATH*).
2. Descomprime esta carpeta donde quieras y ejecuta **`instalar.bat`**.
3. Instala una voz en español: *Configuración → Hora e idioma → Voz → Agregar voces*
   (p. ej. *Microsoft Sabina – Español (México)*). Prueba con **`probar_voz.bat`**.
4. En LMU: **Settings → Gameplay → Enable Plugins = ON** (necesario para que el juego publique la telemetría;
   no hace falta instalar ningún plugin ni DLL). En iRacing no hay que configurar nada.

## Uso

- **`demo.bat`** – demo sin el juego: un piloto virtual comete errores a propósito y el coach los detecta.
- **`iniciar_coach.bat`** – ábrelo antes o después del simulador (LMU o iRacing); se conecta solo.
  La primera vuelta limpia queda como referencia y se guarda por pista+coche
  (la próxima vez arrancas comparándote contra tu mejor vuelta histórica).
- **`debrief.bat`** – analiza la última sesión y escribe `debrief.md` en su carpeta.
  Opciones: `debrief.bat --setup "ruta\a\tu_setup.svm"` (la IA propone clicks concretos del setup),
  `--sin-ia`, `--hablar` (te lee el resumen).

Los setups de LMU están en `Le Mans Ultimate\UserData\player\Settings\<pista>\*.svm`.

### Debrief con IA (opcional)

Crea una API key en console.anthropic.com y defínela una vez en Windows:

```
setx ANTHROPIC_API_KEY "tu-clave"
```

Sin key, el debrief local (tabla de pérdidas por curva, vuelta ideal, llantas, frenos, alturas y
reglas de setup) se genera igual.

## Configuración

Todo está en `config.toml`: voz, nivel de verbosidad (`auto | completo | carrera | minimo`),
segundos de anticipación de los avisos, umbrales de frenada/vértice/acelerador, ventana de
temperatura de llantas y modelo de IA.

## Cómo funciona (técnico)

- **Telemetría:** memoria compartida nativa `LMU_Data` de LMU (100 Hz telemetría / 5 Hz scoring),
  estructuras de [pyLMUSharedMemory](https://github.com/TinyPedal/pyLMUSharedMemory) (MIT, incluida en
  `lmu_coach/vendor`), derivadas del `SharedMemoryInterface.hpp` oficial de Studio 397. La distancia de
  vuelta (5 Hz) se interpola a la velocidad de telemetría.
- **Referencia:** tu mejor vuelta válida, remuestreada cada 2 m. Las curvas se detectan solas
  (zonas de frenada y zonas de levantar), con su punto de frenada, vértice y salida.
- **Medición por curva:** tiempo desde 60 m antes de la frenada hasta 250 m de recta después
  (así la mala salida cuenta como pérdida de esa curva), punto de frenada, velocidad mínima,
  punto de acelerador a fondo, slip ratio (bloqueos/patinaje) y balance
  (deriva delantera − trasera: + subviraje, − sobreviraje).
- **Datos:** `datos/sessions/<fecha_pista_coche>/` con `session.json`, cada vuelta remuestreada
  en `laps/` y el `debrief.md`; referencias en `datos/references/`.

## Pruebas

```
python tests/test_end_to_end.py
```

Incluye una prueba que escribe la estructura binaria `LMU_Data` completa (324 820 bytes) y la lee con
el lector real, verificando que el coach detecta los errores sembrados.

## Hoja de ruta

1. Validar umbrales con tus sesiones reales en LMU (por clase de coche).
2. Overlay en pantalla y dashboard en el celular (WebSocket).
3. Pulsador en el volante para preguntarle al ingeniero ("¿cómo van las llantas?", "¿cuántas vueltas de combustible?").
4. Estrategia de carrera en vivo con IA (ventanas de pit, undercut, doble stint de llantas).
5. Vueltas de referencia de pilotos rápidos y comparación tipo "fantasma".
6. Aplicar setups directamente vía la API local de LMU (puerto 6397).

---
Proyecto independiente, sin relación con Le Mans Ultimate, iRacing ni sus desarrolladores.
