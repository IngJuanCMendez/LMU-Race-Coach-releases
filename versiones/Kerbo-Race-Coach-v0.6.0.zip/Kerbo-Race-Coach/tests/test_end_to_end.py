"""Pruebas: lector binario LMU_Data, motor de coaching y debrief.

En Linux el lector usa /dev/shm/LMU_Data, así que podemos escribir la misma
estructura binaria que publica LMU y leerla con el código real.
"""
import ctypes
import os
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from lmu_coach import config as C
from lmu_coach.coach.engine import CoachEngine
from lmu_coach.coach.messages import MessageQueue, say_delta, say_laptime
from lmu_coach.sources.synthetic import SyntheticSource
from lmu_coach.vendor.pyLMUSharedMemory import lmu_data as D


def test_struct_sizes():
    assert ctypes.sizeof(D.LMUScoringInfo) == 548
    assert ctypes.sizeof(D.LMUVehicleScoring) == 584
    assert ctypes.sizeof(D.LMUVehicleTelemetry) == 1888
    assert ctypes.sizeof(D.LMUWheel) == 260
    assert ctypes.sizeof(D.LMUObjectOut) == 324_820


def test_voice_format():
    assert say_laptime(92.34) == "1 32 punto 3"
    assert say_laptime(59.96) == "1 00 punto 0"
    assert say_delta(0.3) == "más 3 décimas"
    assert say_delta(-0.1) == "menos una décima"


class ShmWriter:
    """Escribe Frames sintéticos en /dev/shm/LMU_Data con el layout binario de LMU."""

    def __init__(self):
        from lmu_coach.vendor.pyLMUSharedMemory._common import platform_mmap
        self.mm = platform_mmap("LMU_Data", ctypes.sizeof(D.LMUObjectOut))
        self.o = D.LMUObjectOut.from_buffer(self.mm)
        self.o.generic.gameVersion = 14000
        self.o.scoring.scoringInfo.mNumVehicles = 1
        self.o.telemetry.activeVehicles = 1
        self.o.telemetry.playerVehicleIdx = 0
        self.o.telemetry.playerHasVehicle = 1
        self.o.scoring.vehScoringInfo[0].mIsPlayer = 1
        self.last_scoring = -1.0

    def write(self, f):
        t = self.o.telemetry.telemInfo[0]
        t.mElapsedTime = f.t
        t.mLapNumber = f.lap
        t.mLapStartET = f.lap_start_t
        t.mTrackName = f.track.encode()
        t.mVehicleModel = f.car.encode()
        t.mLocalVel.z = -f.speed
        t.mUnfilteredThrottle = f.throttle
        t.mUnfilteredBrake = f.brake
        t.mUnfilteredSteering = f.steer
        t.mLocalAccel.x = f.lat_g * 9.81
        t.mGear = f.gear
        t.mFuel = f.fuel
        t.mFuelCapacity = f.fuel_cap
        t.mVirtualEnergy = f.virtual_energy
        t.mFrontRideHeight = f.ride_h_front
        t.mRearRideHeight = f.ride_h_rear
        for i in range(4):
            w = t.mWheels[i]
            for j in range(3):
                w.mTemperature[j] = f.tyre_temp[i][j] + 273.15
            w.mOptimalTemp = f.tyre_opt[i] + 273.15
            w.mPressure = f.tyre_press[i]
            w.mWear = f.tyre_wear[i]
            w.mBrakeTemp = f.brake_temp[i] + 273.15
            w.mLongitudinalGroundVel = -f.speed
            w.mLateralGroundVel = f.speed * __import__("math").tan(__import__("math").radians(f.slip_angle[i]))
        si = self.o.scoring.scoringInfo
        si.mInRealtime = 1
        si.mSession = f.session
        si.mGamePhase = f.game_phase
        si.mLapDist = f.track_len
        si.mTrackName = f.track.encode()
        si.mSessionTimeRemaining = f.time_remaining
        # scoring a 5 Hz, como el juego
        if f.t - self.last_scoring >= 0.2:  # sin forzar en cambio de vuelta: datos viejos como en el juego
            self._lap = f.lap
            self.last_scoring = f.t
            si.mCurrentET = f.t
            vs = self.o.scoring.vehScoringInfo[0]
            vs.mLapDist = f.dist
            vs.mVehicleClass = f.car_class.encode()
            vs.mPlace = f.place

    def close(self):
        self.o = None
        self.mm.close()
        Path("/dev/shm/LMU_Data").unlink(missing_ok=True)


def run_engine(frames_iter, tmp):
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tmp), log=said.append)
    for f in frames_iter:
        clk[0] = f.t
        eng.on_frame(f)
    path = eng.close()
    return said, path


def test_lmu_reader_end_to_end():
    if sys.platform == "win32":
        return  # en Windows /dev/shm no existe; se prueba con el juego real
    from lmu_coach.sources.lmu import LMUSource
    tmp = tempfile.mkdtemp()
    w = ShmWriter()
    src = LMUSource()
    assert src.connect() and src.game_version() == 14000
    synth = SyntheticSource(laps=5, realtime=False, hz=50)

    def frames():
        while (f := synth.read()) is not None:
            w.write(f)
            g = src.read()
            assert g is not None
            assert abs(g.speed - f.speed) < 1e-6
            assert abs(g.tyre_temp[0][2] - f.tyre_temp[0][2]) < 1e-6
            assert abs(g.dist - f.dist) < 25, (g.dist, f.dist)  # interpolación 5 Hz → 50 Hz
            yield g

    said, path = run_engine(frames(), tmp)
    src.close()
    w.close()
    txt = "\n".join(said)
    print(txt)
    assert "Vuelta de referencia" in txt
    assert "Curva 4: frenaste" in txt          # frenada temprana sembrada en vuelta 3
    assert "Curva 1: frenaste" in txt and "tarde" in txt  # frenada tardía vuelta 4
    assert "Curva 6" in txt                     # vértice lento vuelta 4
    assert "Curva 4, aguanta" in txt  # aviso anticipado
    shutil.rmtree(tmp)


def test_debrief_and_advice():
    from lmu_coach.debrief.analysis import analyze
    from lmu_coach.debrief.setup_advisor import advise
    tmp = tempfile.mkdtemp()
    synth = SyntheticSource(laps=6, realtime=False, hz=40)
    said, path = run_engine(iter(synth.read, None), tmp)
    sess = json.loads(path.read_text())
    a = analyze(sess, path.parent)
    assert a["laps_valid"] >= 5
    assert abs(a["ideal_lap"] - a["best"]) < 0.05   # la vuelta limpia es la mejor en todas las curvas
    assert a["corners"][0]["avg_loss"] > 0.05
    adv = advise(a)
    assert any("Balance" in x["area"] for x in adv)  # el simulador tiene subviraje
    shutil.rmtree(tmp)


def test_race_fuel_messages():
    tmp = tempfile.mkdtemp()
    synth = SyntheticSource(laps=6, realtime=False, hz=30, session=10,
                            error_plan={i: [] for i in range(1, 7)})
    said, _ = run_engine(iter(synth.read, None), tmp)
    txt = "\n".join(said)
    assert "Combustible" in txt or "Energía" in txt or "ahorra" in txt
    shutil.rmtree(tmp)


def test_race_rivals_aids_and_debrief():
    """Carrera con rivales, bloqueos y patinaje: info de rivales, asesor ABS/TC y debrief."""
    from lmu_coach.debrief.analysis import analyze
    from lmu_coach.debrief.report import build_markdown
    from lmu_coach.debrief.setup_advisor import advise
    from lmu_coach.sources.synthetic import CornerError as E
    tmp = tempfile.mkdtemp()
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tmp), log=said.append)
    plan = {1: [], 2: [], 3: [E("lock", 0)], 4: [E("lock", 0)], 5: [], 6: [], 7: [E("spin", 1)], 8: [E("spin", 1)],
            9: [E("spin", 1)], 10: [], 11: []}
    src = SyntheticSource(laps=11, realtime=False, hz=30, session=10, error_plan=plan)
    last = -9.0
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
        if f.t - last >= 0.5:
            last = f.t
            eng.on_cars(src.read_cars(), f)
    path = eng.close()
    txt = "\n".join(said)
    assert "P2 de 4" in txt and "Porsche" in txt and "se escapa" in txt
    assert "paró" in txt
    assert "Hypercar más rápido" in txt
    assert "Sube el ABS a 5" in txt
    assert "Sube TC Slip a 5" in txt
    a = analyze(json.loads(path.read_text()), path.parent)
    assert a["brake_refs"] and a["car_aids"]["lock_f"] > 0
    md = build_markdown(a, advise(a), None)
    assert "Referencias de frenada" in md and "Ayudas y reparto" in md
    shutil.rmtree(tmp)



def test_chat_levels_and_focus_cues():
    """Nivel 0 calla todo salvo peligro; nivel 3 avisa antes de curvas con potencial."""
    from lmu_coach.sources.synthetic import CornerError as E
    counts = {}
    for lvl in (0, 2, 3):
        cfg = C.load()
        cfg["coach"]["charla"] = lvl
        clk = [0.0]
        q = MessageQueue(clock=lambda: clk[0])
        said = []
        eng = CoachEngine(cfg, q, Path(tempfile.mkdtemp()), log=said.append, save=False)
        plan = {i: [E("slow_apex", 2)] for i in range(3, 8)}
        plan[1] = []
        plan[2] = []
        src = SyntheticSource(laps=7, realtime=False, hz=30, error_plan=plan)
        while (f := src.read()) is not None:
            clk[0] = f.t
            eng.on_frame(f)
        spoken = [x for x in said if not x.startswith("[silenciado")]
        counts[lvl] = (len(spoken), sum(1 for x in spoken if x.startswith("[AVISO]")))
    assert counts[0][0] == 0
    assert counts[2][1] == 0 and counts[2][0] > 0
    assert counts[3][1] >= 3



def test_aids_margin_and_experiment():
    """ABS actuando mucho sin bloqueos → sugiere bajarlo; al cambiarlo, compara y da veredicto."""
    from lmu_coach.sources.synthetic import CornerError as E
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tempfile.mkdtemp()), log=said.append, save=False)
    src = SyntheticSource(laps=15, realtime=False, hz=25, error_plan={i: [E("abs_heavy", 0)] for i in range(1, 16)})
    src.settings_by_lap = {i: {"abs_level": 3} for i in range(11, 16)}
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
    txt = "\n".join(said)
    assert "Prueba ABS 3" in txt
    assert "Anotado: ABS de 4 a 3" in txt
    assert "Con ABS 3" in txt


def test_incident_filtered_and_rival_names():
    from lmu_coach.coach.rivals import Car
    assert Car(0, "x", "Proton Competition #77:LM", "GT3", 1, 0, 0, False, 0, 0, 0, False).short == "Proton número 77"
    assert Car(0, "x", "Akkodis ASP Team #87:LM", "GT3", 1, 0, 0, False, 0, 0, 0, False).short == "Akkodis número 87"



def test_guided_tuning_covers_bias_tc_cut_slip():
    """Sin problemas visibles, en práctica recorre reparto, ABS, TC Cut y TC Slip."""
    from lmu_coach.sources.synthetic import CornerError as E
    cfg = C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tempfile.mkdtemp()), log=said.append, save=False)
    src = SyntheticSource(laps=22, realtime=False, hz=25,
                          error_plan={i: [E("abs_heavy", 0), E("tc_heavy", 0)] for i in range(1, 23)})
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
    txt = "\n".join(said)
    assert "reparto en 55 punto 5" in txt
    assert "Prueba ABS 3" in txt
    assert "TC Cut 2" in txt
    assert "TC Slip 3" in txt



def test_corner_names_and_live_delta():
    """Spa: nombres reales por plantilla y renombre del piloto; delta en vivo y aviso por sector."""
    from lmu_coach.coach.track import Corner
    from lmu_coach.tracks import corner_names, save_user_name
    tmp = Path(tempfile.mkdtemp())
    apex = [276, 1088, 2290, 2550, 2944, 3146, 3656, 3778, 4406, 4842, 6620]
    cs = [Corner(i + 1, a - 150, a - 100, a, a + 100, True) for i, a in enumerate(apex)]
    names = corner_names(tmp, "Circuit de Spa-Francorchamps", cs, 6982)
    assert names[1] == "La Source" and names[2] == "Eau Rouge" and names[11] == "Bus Stop"
    save_user_name(tmp, "Circuit de Spa-Francorchamps", 2944, "Rivage")
    assert corner_names(tmp, "Circuit de Spa-Francorchamps", cs, 6982)[5] == "Rivage"
    from lmu_coach.sources.synthetic import CornerError as E
    cfg = C.load()
    cfg["coach"]["charla"] = 4
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, tmp, log=said.append, save=False)
    src = SyntheticSource(laps=4, realtime=False, hz=25, error_plan={1: [], 2: [], 3: [E("slow_apex", 0)], 4: []})
    deltas = []
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
        if f.lap == 3 and eng.live_delta is not None:
            deltas.append(eng.live_delta)
    assert deltas and max(deltas) > 0.1
    assert any("Sector 1, más" in x for x in said)



def _engine(cfg=None, tmp=None, save=False):
    cfg = cfg or C.load()
    clk = [0.0]
    q = MessageQueue(clock=lambda: clk[0])
    said = []
    eng = CoachEngine(cfg, q, Path(tmp or tempfile.mkdtemp()), log=said.append, save=save)
    return eng, clk, said


def test_strategy_rain_and_consistency():
    eng, clk, said = _engine()
    src = SyntheticSource(laps=20, realtime=False, hz=20, session=10, error_plan={i: [] for i in range(1, 21)})
    src.session_len = 20 * 79.4
    src.rain_from_t = 1250
    started = False
    last = -9.0
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
        if f.t - last >= 0.5:
            last = f.t
            eng.on_cars(src.read_cars(), f)
        if f.lap == 2 and not started:
            started = True
            eng.start_consistency(4)
    txt = "\n".join(said)
    assert "Ventana de pits abierta" in txt and "por ciento de energía" in txt
    assert "Entra a pits esta vuelta" in txt
    assert "Empieza a llover" in txt and "llantas de lluvia" in txt and "suspendo la comparación" in txt
    assert "Fin del modo consistencia" in txt
    assert "parada" in eng.strategy.summary_text() or "alcanza" in eng.strategy.summary_text()


def test_share_and_compare_against_friend():
    from lmu_coach.sharing import export_ref, friend_refs, import_ref, own_refs
    a = Path(tempfile.mkdtemp())
    eng, clk, said = _engine(tmp=a, save=True)
    src = SyntheticSource(laps=3, realtime=False, hz=25, error_plan={1: [], 2: [], 3: []})
    while (f := src.read()) is not None:
        clk[0] = f.t
        eng.on_frame(f)
    eng.close()
    refs = own_refs(a)
    assert refs
    out = Path(tempfile.mkdtemp()) / "vuelta_pedro.json.gz"
    export_ref(refs[0]["path"], str(out), "Pedro")
    b = Path(tempfile.mkdtemp())
    r = import_ref(str(out), b)
    assert r["driver"] == "Pedro" and friend_refs(b, "Demo Ring")
    cfg = C.load()
    cfg["coach"]["comparar"] = r["path"]
    from lmu_coach.sources.synthetic import CornerError as E
    eng2, clk2, said2 = _engine(cfg=cfg, tmp=b)
    src = SyntheticSource(laps=4, realtime=False, hz=25, error_plan={1: [], 2: [], 3: [E("early_brake", 3)], 4: []})
    while (f := src.read()) is not None:
        clk2[0] = f.t
        eng2.on_frame(f)
    txt = "\n".join(said2)
    assert "Comparando contra Pedro" in txt
    assert "antes que Pedro" in txt
    assert "contra Pedro" in txt


def test_setups_diff_and_radio_and_phone():
    import sys as _s
    import types
    from lmu_coach.setups import diff_svm, setup_markdown
    a = "[REARWING]\nRearWingSetting=3//P4\n[GENERAL]\nFuelSetting=40//40L\n"
    assert diff_svm(a, a.replace("3//P4", "4//P5")) == [("REARWING", "RearWing", "P4", "P5")]
    root = Path(tempfile.mkdtemp()) / "sessions"
    for name, wing in (("20260101_000000_x", "3//P4"), ("20260102_000000_x", "4//P5")):
        d = root / name
        d.mkdir(parents=True)
        (d / "session.json").write_text(json.dumps({"track": "T", "car": "C", "laps": [{"valid": True, "time": 100.0}]}))
        (d / "setup.svm").write_text(a.replace("3//P4", wing))
    md = "\n".join(setup_markdown(root / "20260102_000000_x"))
    assert "RearWing | P4 | P5" in md
    # pregunta libre por radio (Claude simulado)
    calls = {}

    class Msgs:
        def create(self, **kw):
            calls.update(kw)
            return types.SimpleNamespace(content=[types.SimpleNamespace(type="text", text="Te quedan seis vueltas de energía.")])
    mod = types.ModuleType("anthropic")
    mod.Anthropic = lambda: types.SimpleNamespace(messages=Msgs())
    old = _s.modules.get("anthropic")
    _s.modules["anthropic"] = mod
    os.environ["ANTHROPIC_API_KEY"] = "x"
    try:
        eng, clk, said = _engine()
        src = SyntheticSource(laps=3, realtime=False, hz=20, session=10, error_plan={1: [], 2: [], 3: []})
        while (f := src.read()) is not None:
            clk[0] = f.t
            eng.on_frame(f)
        from lmu_coach.debrief.ai import ask_radio
        ans = ask_radio(C.load(), "cuánta energía me queda", eng)
        assert "energía" in ans and "PREGUNTA DEL PILOTO" in calls["messages"][0]["content"]
        # panel del celular
        from lmu_coach.web import snapshot

        class R:
            status = "conectado"
            engine = eng
            radio = [("t", "hola", 3)]
        snap = snapshot(R())
        assert snap["lap"] and "tyres" in snap and snap["radio"] == ["hola"]
    finally:
        del os.environ["ANTHROPIC_API_KEY"]
        if old is not None:
            _s.modules["anthropic"] = old
        else:
            _s.modules.pop("anthropic", None)


class _FakeIR:
    """Imita irsdk.IRSDK a partir del piloto sintético (variables y YAML de sesión de iRacing)."""

    def __init__(self, synth):
        import math
        self.s, self.math = synth, math
        self.is_initialized, self.is_connected = True, True
        self.session_info_update = 1
        self.vars = {}
        self.yaml = None

    def _build_yaml(self):
        synth = self.s
        L = synth.tr.length
        cars = synth.read_cars()
        self.yaml = {
            "WeekendInfo": {"TrackDisplayName": "Demo Ring", "TrackLength": f"{L / 1000:.3f} km"},
            "DriverInfo": {"DriverCarIdx": 0, "DriverCarRedLine": 8000, "DriverCarFuelMaxLtr": 100,
                           "DriverCarMaxFuelPct": 1.0, "DriverTires": [{"TireIndex": 0, "TireCompoundType": "Hard"}],
                           "Drivers": [{"CarIdx": 0, "UserName": "Juan", "CarScreenName": "Demo LMGT3",
                                        "CarNumber": "7", "CarClassShortName": "GT3"},
                                       {"CarIdx": 99, "UserName": "Pace", "CarScreenName": "Safety",
                                        "CarIsPaceCar": 1}]
                           + [{"CarIdx": i + 1, "UserName": c.driver, "CarScreenName": c.vehicle.split(" #")[0],
                               "CarNumber": c.vehicle.split("#")[-1] if "#" in c.vehicle else "",
                               "CarClassShortName": c.cls} for i, c in enumerate(x for x in cars if not x.is_player)]},
            "SessionInfo": {"Sessions": [{"SessionNum": 0, "SessionType": "Race"}]},
        }

    def __getitem__(self, k):
        return self.vars[k] if k in self.vars else (self.yaml or {}).get(k)

    def step(self):
        f = self.s.read()
        if f is None:
            return None
        if self.yaml is None:
            self._build_yaml()
        m, L = self.math, self.s.tr.length
        rear_sa = 10.0 if f.slip_ratio[2] > 0.25 else f.slip_angle[2]
        vx = f.speed
        v = {"SessionTime": f.t, "Lap": f.lap, "LapCurrentLapTime": f.t - f.lap_start_t, "LapDist": f.dist,
             "LapDistPct": f.dist / L, "Speed": f.speed, "Throttle": f.throttle, "Brake": f.brake,
             "SteeringWheelAngle": -f.steer * 4.0, "SteeringWheelAngleMax": 4.0, "Gear": f.gear, "RPM": f.rpm,
             "YawRate": f.yaw_rate, "LatAccel": f.lat_g * 9.81, "LongAccel": f.lon_g * 9.81,
             "BrakeABSactive": f.abs_active, "VelocityX": vx,
             "VelocityY": m.tan(m.radians(rear_sa)) * vx + f.yaw_rate * 1.4, "FuelLevel": f.fuel,
             "dcBrakeBias": (1 - f.brake_bias_rear) * 100, "dcTractionControl": f.tc_level,
             "dcTractionControl2": f.tc_slip, "dcABS": f.abs_level, "IsOnTrack": True, "SessionNum": 0,
             "SessionFlags": 0x20 if f.flag == 6 else 0x04, "SessionState": 4, "OnPitRoad": f.in_pits,
             "PlayerCarPosition": f.place, "LapBestLapTime": max(f.best_lap, 0), "LapLastLapTime": max(f.last_lap, 0),
             "SessionTimeRemain": f.time_remaining, "AirTemp": 22.0, "TrackTempCrew": 30.0, "TrackWetness": 1,
             "Precipitation": 0.0, "SessionLapsTotal": 32767}
        for i, w in enumerate(("LF", "RF", "LR", "RR")):
            for side in ("L", "M", "R"):
                v[f"{w}tempC{side}"] = f.tyre_carcass[i] or 80.0
                v[f"{w}wear{side}"] = f.tyre_wear[i] or 1.0
        cars = [c for c in self.s.read_cars() if not c.is_player]
        n = 100
        arr = lambda d: [d.get(i, -1) for i in range(n)]
        pct, lapc, pos, pit = {0: f.dist / L}, {0: f.lap - 1}, {0: f.place}, {0: f.in_pits}
        for i, c in enumerate(cars):
            pct[i + 1], lapc[i + 1], pos[i + 1], pit[i + 1] = c.lapdist / L, c.laps, c.place, c.in_pits
        v.update({"CarIdxLapDistPct": arr(pct), "CarIdxLapCompleted": arr(lapc), "CarIdxPosition": arr(pos),
                  "CarIdxOnPitRoad": arr(pit), "CarIdxLastLapTime": [-1] * n, "CarIdxBestLapTime": [-1] * n})
        self.vars = v
        return f


def test_iracing_source_end_to_end():
    """La fuente de iRacing alimenta el motor completo: vueltas, curvas, rivales, ABS y patinaje (estimado)."""
    from lmu_coach.sources.auto import allowed
    from lmu_coach.sources.iracing import IRacingSource, track_length_m
    from lmu_coach.sources.synthetic import CornerError as E
    assert abs(track_length_m("4.35 mi") - 7000.6) < 1 and track_length_m("7.00 km") == 7000.0
    assert allowed({"lectura": {"simulador": "iracing"}}) == ("iracing",)
    assert allowed({"lectura": {}}) == ("lmu", "iracing")
    plan = {1: [], 2: [], 3: [E("lock", 0)], 4: [E("lock", 0)], 5: [], 6: [], 7: [E("spin", 1)],
            8: [E("spin", 1)], 9: [E("spin", 1)], 10: [], 11: []}
    synth = SyntheticSource(laps=11, realtime=False, hz=30, session=10, error_plan=plan)
    ir = _FakeIR(synth)
    src = IRacingSource(ir)
    assert src.connect() and src.user_data_path() == ""
    eng, clk, said = _engine()
    last, n = -9.0, 0
    while ir.step() is not None:
        f = src.read()
        assert f is not None and f.sim == "iracing" and f.slip_est
        n += 1
        clk[0] = f.t
        eng.on_frame(f)
        if f.t - last >= 0.5:
            last = f.t
            cars = src.read_cars()
            assert all(c.driver != "Pace" for c in cars)
            eng.on_cars(cars, f)
    assert n > 1000
    assert abs(f.brake_bias_rear - 0.44) < 1e-6 and f.tc_level == 5 and f.abs_max == 12
    assert f.track == "Demo Ring" and f.car == "Demo LMGT3" and f.session == 10 and f.compound == "Hard"
    eng.close()
    txt = "\n".join(said)
    assert "Vuelta" in txt or "vuelta" in txt
    assert "P2 de 4" in txt and "Porsche" in txt
    assert "Patinas al acelerar en las salidas. Sube el TC a 6" in txt   # patinaje vía deriva trasera estimada
    assert "el TC casi no actúa" not in txt


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("OK", name)
