"""Asesor en vivo de reparto de freno, ABS y TC (TC, TC Slip, TC Cut).

Cada vuelta:
  1. Estadísticas globales (bloqueos, ABS activo, patinaje, TC activo) y por curva
     (ABS en la frenada, TC en la salida).
  2. Recomienda como máximo UN cambio, con valor actual → sugerido, tanto para
     problemas (bloqueos, patinaje) como para margen (ayuda que actúa de más sin
     problemas, que suele costar distancia de frenada o tracción).
  3. Si el piloto cambia un ajuste en el juego, lo detecta y compara las curvas
     afectadas antes/después (experimento) para decir si conviene mantenerlo.

Convención LMU por defecto: número más alto = más ayuda (configurable).
"""

from __future__ import annotations

from .messages import NORMAL, say_tenths

KEYS = {"abs_level": "ABS", "tc_level": "TC", "tc_slip": "TC Slip", "tc_cut": "TC Cut", "bias_front": "el reparto"}


class CarAdvisor:
    def __init__(self, engine, cfg: dict):
        self.e = engine
        self.cfg = cfg
        self.history: list[dict] = []        # estadísticas de vueltas válidas
        self.corner_laps: list[dict] = []    # {num: metrics} por vuelta válida
        self.settings_laps: list[dict] = []  # ajustes en cada vuelta válida
        self.last_advice_lap = -99
        self.suggested: dict[str, int] = {}  # clave de sugerencia -> veces
        self.experiment: dict | None = None
        self.tested: dict[tuple, str] = {}     # (clave, dirección) -> 'mantener' | 'volver' | 'igual'
        self.reset()

    # ------------------------------------------------------------ por frame
    def reset(self) -> None:
        self.n_brake = self.n_abs = self.n_lock_f = self.n_lock_r = 0
        self.n_exit = self.n_tc = self.n_spin = 0
        self.sb_n = 0
        self.sb_front = self.sb_rear = 0.0      # deslizamiento longitudinal en frenada recta
        self.en_n = 0
        self.en_bal = 0.0                       # deriva delantera − trasera entrando frenado
        self.last = None

    def on_frame(self, f) -> None:
        if f.in_pits or f.speed < 12:
            return
        self.last = f
        sr = f.slip_ratio
        if f.brake > 0.3:
            self.n_brake += 1
            self.n_abs += f.abs_active
            front = max(abs(sr[0]), abs(sr[1]))
            rear = max(abs(sr[2]), abs(sr[3]))
            # bloqueo real = un eje desliza claramente más que el otro (si deslizan los 4 es un trompo/salida)
            if front > self.cfg["umbral_bloqueo"] and front > rear * 1.5:
                self.n_lock_f += 1
            if rear > self.cfg["umbral_bloqueo"] * 0.75 and rear > front * 1.5:
                self.n_lock_r += 1
            if f.brake > 0.5 and abs(f.steer) < 0.05 and f.speed > 25 and front < 0.5 and rear < 0.5:
                self.sb_n += 1
                self.sb_front += (abs(sr[0]) + abs(sr[1])) / 2
                self.sb_rear += (abs(sr[2]) + abs(sr[3])) / 2
        if 0.1 < f.brake and abs(f.steer) > 0.12 and f.speed > 15:
            sa = f.slip_angle
            fa, ra = (abs(sa[0]) + abs(sa[1])) / 2, (abs(sa[2]) + abs(sa[3])) / 2
            if fa < 15 and ra < 15:
                self.en_n += 1
                self.en_bal += fa - ra
        elif f.throttle > 0.6 and abs(f.lat_g) > 0.3:
            self.n_exit += 1
            self.n_tc += f.tc_active
            if max(abs(sr[2]), abs(sr[3])) > self.cfg["umbral_patinaje"]:
                self.n_spin += 1

    def settings(self) -> dict:
        f = self.last
        if f is None:
            return {}
        return {"abs_level": f.abs_level, "abs_max": f.abs_max, "tc_level": f.tc_level, "tc_max": f.tc_max,
                "tc_slip": f.tc_slip, "tc_slip_max": f.tc_slip_max, "tc_cut": f.tc_cut, "tc_cut_max": f.tc_cut_max,
                "bias_front": round((1 - f.brake_bias_rear) * 100, 1) if f.brake_bias_rear > 0 else None}

    def lap_stats(self) -> dict:
        b = max(self.n_brake, 1)
        x = max(self.n_exit, 1)
        ratio = (self.sb_front / self.sb_rear) if self.sb_n > 20 and self.sb_rear > 1e-4 else None
        return {"lock_f": self.n_lock_f / b, "lock_r": self.n_lock_r / b, "abs": self.n_abs / b,
                "spin": self.n_spin / x, "tc": self.n_tc / x,
                "brake_ratio": round(ratio, 2) if ratio else None,
                "entry_bal": round(self.en_bal / self.en_n, 2) if self.en_n > 20 else None,
                "samples_brake": self.n_brake, "samples_exit": self.n_exit, **self.settings()}

    # ------------------------------------------------------------ por vuelta
    def end_lap(self, lap: int, valid_for_stats: bool, corners: dict | None = None, braking: set | None = None) -> dict:
        s = self.lap_stats()
        self.reset()
        if not (valid_for_stats and s["samples_brake"] > 30):
            return s
        self.history.append(s)
        self.corner_laps.append(corners or {})
        self.settings_laps.append({k: s.get(k) for k in KEYS})
        self.braking = braking or set()
        if self._check_experiment(lap):
            return s
        self._advise(lap)
        return s

    # ------------------------------------------------------------ experimentos
    def _changed(self) -> list[tuple[str, object, object]]:
        if len(self.settings_laps) < 2:
            return []
        a, b = self.settings_laps[-2], self.settings_laps[-1]
        return [(k, a[k], b[k]) for k in KEYS if a.get(k) is not None and b.get(k) is not None and a[k] != b[k]]

    def _corner_time(self, laps: list[dict], nums: set) -> dict:
        """Promedio de las 2 mejores ejecuciones de cada curva (reduce el ruido sin favorecer a ningún lado)."""
        out = {}
        for n in nums:
            xs = sorted(cl[n]["time"] for cl in laps if n in cl)[:2]
            if xs:
                out[n] = sum(xs) / len(xs)
        return out

    def _check_experiment(self, lap: int) -> bool:
        ch = self._changed()
        if ch:
            k, old, new = ch[0]
            base = self.corner_laps[-4:-1]
            # curvas afectadas: frenadas para ABS/reparto, todas para TC
            nums = set(self.braking) if k in ("abs_level", "bias_front") else set().union(*[set(c) for c in base]) if base else set()
            self.experiment = {"key": k, "old": old, "new": new, "start": len(self.corner_laps) - 1,
                               "base_laps": base, "nums": nums, "base_hist": self.history[-4:-1]}
            name = KEYS[k]
            self.e.say(f"Anotado: {name} de {self._fmt(k, old)} a {self._fmt(k, new)}. "
                       f"En dos vueltas te digo si funciona.", NORMAL, "car", 5)
            return True
        ex = self.experiment
        if not ex:
            return False
        if self.settings_laps[-1].get(ex["key"]) != ex["new"]:
            self.experiment = None
            return False
        after = self.corner_laps[ex["start"]:]
        if len(after) < 2:
            return True
        before_t = self._corner_time(ex["base_laps"], ex["nums"])
        after_t = self._corner_time(after, ex["nums"])
        common = set(before_t) & set(after_t)
        self.experiment = None
        if not common or not ex["base_laps"]:
            return True
        delta = sum(after_t[n] - before_t[n] for n in common)
        hist_after = self.history[-len(after):]
        lk_b = sum(h["lock_f"] for h in ex["base_hist"]) / max(len(ex["base_hist"]), 1)
        lk_a = sum(h["lock_f"] for h in hist_after) / len(hist_after)
        sp_b = sum(h["spin"] for h in ex["base_hist"]) / max(len(ex["base_hist"]), 1)
        sp_a = sum(h["spin"] for h in hist_after) / len(hist_after)
        name, new, old = KEYS[ex["key"]], self._fmt(ex["key"], ex["new"]), self._fmt(ex["key"], ex["old"])
        worse_grip = (lk_a > lk_b + 0.02) or (sp_a > sp_b + 0.02)
        try:
            direction = 1 if float(ex["new"]) > float(ex["old"]) else -1
        except (TypeError, ValueError):
            direction = 0
        res = "mantener" if (delta < -0.1 and not worse_grip) else ("volver" if (delta > 0.1 or worse_grip) else "igual")
        self.tested[(ex["key"], direction)] = res
        zone = "en las frenadas" if ex["key"] in ("abs_level", "bias_front") else "en las curvas"
        if delta < -0.1 and not worse_grip:
            msg = f"Con {name} {new} vas {say_tenths(delta)} más rápido {zone}. Mantenlo."
        elif delta > 0.1 or worse_grip:
            why = " y bloqueas más" if lk_a > lk_b + 0.02 else (" y patinas más" if sp_a > sp_b + 0.02 else "")
            msg = f"Con {name} {new} vas {say_tenths(delta)} más lento {zone}{why}. Vuelve a {old}."
        else:
            msg = f"Con {name} {new} no hay diferencia clara {zone}. Quédate con el que te dé más confianza."
        self.last_advice_lap = lap
        self.e.say(msg, NORMAL, "car", 5)
        return True

    # ------------------------------------------------------------ recomendaciones
    def _advise(self, lap: int) -> None:
        if self.experiment or lap - self.last_advice_lap < 3 or len(self.history) < 2:
            return
        h = self.history[-3:]
        avg = {k: sum(x[k] for x in h) / len(h) for k in ("lock_f", "lock_r", "abs", "spin", "tc")}
        s = self.history[-1]
        msg, key = self._problem_advice(avg, s)
        if not msg or key in self._skip():
            msg, key = self._bias_advice(h, s)
        if not msg or key in self._skip():
            msg, key = self._margin_advice(avg, s)
        if (not msg or key in self._skip()) and self._practice():
            msg, key = self._tuning_advice(avg, s)
        if msg and self.suggested.get(key, 0) < 2:
            self.suggested[key] = self.suggested.get(key, 0) + 1
            self.last_advice_lap = lap
            self.e.say(msg, NORMAL, "car", 60)

    def _step(self, s, key, maxkey, d):
        up = 1 if self.cfg.get("tc_mas_alto_mas_ayuda", True) else -1
        cur, mx = s.get(key) or 0, s.get(maxkey) or 0
        new = cur + d * up
        if new < 0 or (mx and new > mx) or (key != "tc_cut" and key != "tc_slip" and new < 1):
            return None
        return new

    def _corner_avg(self, field: str) -> dict:
        laps = self.corner_laps[-3:]
        nums = set().union(*[set(c) for c in laps]) if laps else set()
        out = {}
        for n in nums:
            xs = [cl[n].get(field, 0.0) for cl in laps if n in cl]
            if xs:
                out[n] = sum(xs) / len(xs)
        return out

    def _list(self, nums) -> str:
        nums = sorted(nums)[:3]
        names = [self.e.cname(n) if hasattr(self.e, "cname") else f"curva {n}" for n in nums]
        names = [x if not x.startswith("Curva ") else x.lower() for x in names]
        return " y ".join(", ".join(names).rsplit(", ", 1))

    def _problem_advice(self, avg, s):
        bias = s.get("bias_front")
        if avg["lock_f"] > 0.04:
            n = self._step(s, "abs_level", "abs_max", +1) if s.get("abs_max") else None
            if n is not None:
                return f"Bloqueas delanteras en las frenadas. Sube el ABS a {n}.", "abs+"
            if bias:
                return (f"Bloqueas delanteras. Mueve el reparto medio punto atrás: de {self._pct(bias)} a "
                        f"{self._pct(bias - 0.5)} adelante.", "bias-")
            return "Bloqueas delanteras. Frena menos fuerte al final de la frenada.", "lockf"
        if avg["lock_r"] > 0.03 and bias:
            return (f"El auto se mueve atrás al frenar. Reparto medio punto adelante: de {self._pct(bias)} a "
                    f"{self._pct(bias + 0.5)}.", "bias+")
        if avg["spin"] > 0.03:
            if avg["tc"] < 0.15 and s.get("tc_slip_max"):
                n = self._step(s, "tc_slip", "tc_slip_max", +1)
                if n is not None:
                    return f"Patinas en la salida y el TC casi no actúa. Sube TC Slip a {n} para que entre antes.", "slip+"
            if s.get("tc_cut_max"):
                n = self._step(s, "tc_cut", "tc_cut_max", +1)
                if n is not None:
                    return f"Patinas en la salida aunque el TC actúa. Sube TC Cut a {n} para que corte más.", "cut+"
            if s.get("tc_max"):
                n = self._step(s, "tc_level", "tc_max", +1)
                if n is not None:
                    return f"Patinas al acelerar en las salidas. Sube el TC a {n}.", "tc+"
        return None, None

    def _margin_advice(self, avg, s):
        """Ayuda que actúa de más sin problemas: cuesta frenada o tracción."""
        if avg["lock_f"] < 0.01 and avg["lock_r"] < 0.01 and s.get("abs_max"):
            abs_c = self._corner_avg("abs_pct")
            heavy = [n for n, v in abs_c.items() if v > 0.5]
            if avg["abs"] > 0.30 and (heavy or avg["abs"] > 0.40) and "abs-" not in self._skip() \
                    and self._allowed("abs_level", -1):
                n = self._step(s, "abs_level", "abs_max", -1)
                if n is not None:
                    where = f", sobre todo en {self._list(heavy)}" if heavy else ""
                    return (f"El ABS actúa en el {avg['abs'] * 100:.0f} por ciento de tus frenadas{where}, sin bloqueos. "
                            f"Prueba ABS {n}: con menos intervención frenas más corto. Te digo si funciona.", "abs-")
        if avg["spin"] < 0.01 and (s.get("tc_max") or s.get("tc_cut_max")):
            tc_c = self._corner_avg("tc_pct")
            busy = [n for n, v in tc_c.items() if v > 0.25]
            if busy or avg["tc"] > 0.25:
                where = f"en la salida de {self._list(busy)}" if busy else "en las salidas"
                skip = self._skip()
                if s.get("tc_cut_max") and (s.get("tc_cut") or 0) > 0 and "cut-" not in skip and self._allowed("tc_cut", -1):
                    n = self._step(s, "tc_cut", "tc_cut_max", -1)
                    if n is not None:
                        return (f"El TC corta potencia {where} y no patinas. Prueba TC Cut {n} para salir con más empuje.",
                                "cut-")
                if s.get("tc_slip_max") and "slip-" not in skip and self._allowed("tc_slip", -1):
                    n = self._step(s, "tc_slip", "tc_slip_max", -1)
                    if n is not None:
                        return (f"El TC actúa {where} sin que patines. Prueba TC Slip {n} para permitir algo más de deslizamiento.",
                                "slip-")
                if s.get("tc_max") and "tc-" not in skip and self._allowed("tc_level", -1):
                    n = self._step(s, "tc_level", "tc_max", -1)
                    if n is not None:
                        return f"El TC actúa {where} sin que patines. Prueba TC {n}.", "tc-"
        return None, None

    def _skip(self) -> set:
        return {k for k, v in self.suggested.items() if v >= 2}

    def _allowed(self, key: str, direction: int) -> bool:
        """Se puede proponer si nunca se probó en esa dirección o si la última prueba funcionó."""
        return self.tested.get((key, direction)) in (None, "mantener")

    def _practice(self) -> bool:
        f = self.last_frame_session()
        return self.cfg.get("ajuste_guiado", True) and f is not None and (f <= 4 or f == 9)

    def last_frame_session(self):
        lf = getattr(self.e, "last_frame", None)
        return lf.session if lf is not None else None

    def _bias_advice(self, h, s):
        """Reparto por balance de entrada y por cómo trabajan los ejes en frenada recta."""
        bias = s.get("bias_front")
        if not bias:
            return None, None
        bals = [x["entry_bal"] for x in h if x.get("entry_bal") is not None]
        ratios = [x["brake_ratio"] for x in h if x.get("brake_ratio") is not None]
        bal = sum(bals) / len(bals) if len(bals) >= 2 else None
        ratio = sum(ratios) / len(ratios) if len(ratios) >= 2 else None
        back, fwd = self._pct(bias - 0.5), self._pct(bias + 0.5)
        skip = self._skip()
        if "bias-" in skip:
            bal = bal if (bal is None or bal <= 1.5) else None
            ratio = ratio if (ratio is None or ratio <= 2.5) else None
        if "bias+" in skip:
            bal = bal if (bal is None or bal >= -0.8) else None
            ratio = ratio if (ratio is None or ratio >= 1.15) else None
        if bal is not None and bal > 1.5 and ("bias_front", -1) not in self.tested:
            return (f"Al entrar frenando el auto subvira: las delanteras derivan {bal:.1f} grados más. ".replace(".", " punto ", 1)
                    + f"Mueve el reparto medio punto atrás, de {self._pct(bias)} a {back}, para que rote mejor.", "bias-")
        if bal is not None and bal < -0.8 and ("bias_front", 1) not in self.tested:
            return (f"Al entrar frenando la cola se suelta. Mueve el reparto medio punto adelante, "
                    f"de {self._pct(bias)} a {fwd}, para más estabilidad.", "bias+")
        if ratio is not None and ratio > 2.5 and ("bias_front", -1) not in self.tested:
            return (f"En las frenadas las delanteras deslizan {ratio:.1f} veces más que las traseras. ".replace(".", " punto ", 1)
                    + f"Hay margen atrás: prueba el reparto en {back}.", "bias-")
        if ratio is not None and ratio < 1.15 and ("bias_front", 1) not in self.tested:
            return (f"En las frenadas las traseras trabajan casi igual que las delanteras. "
                    f"Para más estabilidad prueba el reparto en {fwd}.", "bias+")
        return None, None

    def _tuning_advice(self, avg, s):
        """Ajuste guiado en práctica: propone una prueba medible con cada ayuda, una a la vez."""
        tc, spin = avg["tc"], avg["spin"]
        bias = s.get("bias_front")
        # 1) TC Cut: solo importa si el TC actúa
        skip = self._skip()
        if s.get("tc_cut_max") and tc >= 0.03 and spin < 0.01 and self._allowed("tc_cut", -1) and "t-cut-" not in skip:
            n = self._step(s, "tc_cut", "tc_cut_max", -1)
            if n is not None:
                return (f"Prueba de ajuste: el TC actúa en el {tc * 100:.0f} por ciento de las salidas y no patinas. "
                        f"Baja TC Cut a {n}: cuando actúe cortará menos potencia. En dos vueltas te digo si sirvió.", "t-cut-")
        # 2) TC Slip: permite más deslizamiento antes de actuar
        if s.get("tc_slip_max") and tc >= 0.02 and spin < 0.01 and self._allowed("tc_slip", -1) and "t-slip-" not in skip:
            n = self._step(s, "tc_slip", "tc_slip_max", -1)
            if n is not None:
                return (f"Prueba de ajuste: baja TC Slip a {n} para que el TC deje deslizar un poco más antes de entrar. "
                        f"Ayuda a rotar el auto en la salida. En dos vueltas te digo si sirvió.", "t-slip-")
        # 3) Reparto: si atrás empeoró, probar adelante; si no se probó nada, probar atrás
        if bias:
            if ("bias_front", -1) not in self.tested and "t-bias-" not in skip:
                return (f"Prueba de ajuste: mueve el reparto medio punto atrás, de {self._pct(bias)} a "
                        f"{self._pct(bias - 0.5)}. Suele ayudar a girar en la entrada. Te digo si sirvió.", "t-bias-")
            if self.tested.get(("bias_front", -1)) == "volver" and ("bias_front", 1) not in self.tested \
                    and "t-bias+" not in skip:
                return (f"Prueba de ajuste: ahora mueve el reparto medio punto adelante, a {self._pct(bias + 0.5)}, "
                        f"para frenar más estable. Te digo si sirvió.", "t-bias+")
        # 4) TC con muy poca intervención: subir Slip no aporta; informar una vez
        if s.get("tc_max") and tc < 0.02 and spin < 0.005 and ("tc_info", 0) not in self.tested:
            self.tested[("tc_info", 0)] = "igual"
            return ("Tu TC casi no actúa y no patinas: el TC Cut y el TC Slip no te están costando tiempo. "
                    "Puedes dejarlos así o bajarlos un punto si quieres más rotación en la salida.", "tc-info")
        return None, None

    # ------------------------------------------------------------ formato
    @staticmethod
    def _pct(x: float) -> str:
        return f"{x:.1f}".replace(".0", "").replace(".", " punto ")

    def _fmt(self, k, v):
        return self._pct(v) if k == "bias_front" and isinstance(v, float) else str(v)
