"""Motor del coach en vivo.

Por cada Frame:
  1. Construye la traza de la vuelta actual.
  2. Al salir de cada curva la compara con la vuelta de referencia (tu mejor
     vuelta válida) y diagnostica la causa principal de la pérdida.
  3. En la vuelta siguiente, antes de esa curva, da un aviso corto anticipado.
  4. Al cerrar la vuelta: tiempo, delta, mayor pérdida, llantas y combustible.
  5. Banderas, límites de pista y vuelta invalidada en tiempo real.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from pathlib import Path

from ..frame import WHEEL_ES, WHEELS, Frame
from .messages import CRITICAL, CUE, HIGH, LOW, NORMAL, MessageQueue, say_delta, say_int, say_laps, say_laptime, say_tenths
from .session_log import SessionLog
from .car_advisor import CarAdvisor
from .rivals import RivalTracker
from .track import LapTrace, Reference, trace_metrics


CHAT_LEVELS = {0: "Silencio", 1: "Mínimo", 2: "Ingeniero", 3: "Coach", 4: "Máximo"}
CHAT_DESC = {
    0: "Solo banderas y peligro.",
    1: "+ tiempos de vuelta, posición, defensa/ataque y combustible crítico.",
    2: "+ errores grandes por curva, rivales al cerrar vuelta, combustible, llantas y ayudas.",
    3: "+ avisos ANTES de las curvas donde puedes mejorar y errores medianos.",
    4: "Todo: cada curva, felicitaciones y avisos en todas las curvas con potencial.",
}
# nivel mínimo de charla para cada clave de mensaje
_KEY_LEVEL = [("blue", 0), ("fcy", 0), ("green", 0), ("yellow", 0), ("tr", 0), ("fuelcrit", 1), ("lap", 1),
              ("ref", 1), ("pos", 1), ("behind", 1), ("ahead", 1), ("rivals", 2), ("pit", 2), ("fuel", 2),
              ("car", 2), ("tyres", 2), ("invalid", 2), ("limits", 2), ("cue", 3), ("cgen", 3), ("ok", 4), ("sector", 3),
              ("c", 2), ("ask", 0)]
LOSS_BY_LEVEL = {2: 0.15, 3: 0.08, 4: 0.05}
FOCUS_BY_LEVEL = {3: 3, 4: 6}
SHORT_TIP = {"late_brake": "frena en tu punto", "early_brake": "aguanta la frenada", "slow_apex": "más velocidad al vértice",
             "late_throttle": "acelera antes", "weak_brake": "freno fuerte", "coast": "sin pausa al acelerador",
             "lock": "cuidado el bloqueo", "spin": "salida suave", "brake_in_lift": "solo levanta"}


def key_level(key: str) -> int:
    for k, lv in _KEY_LEVEL:
        if key.startswith(k):
            return lv
    return 2


@dataclass
class Issue:
    kind: str
    corner: int
    cue: str
    count: int = 1


class CoachEngine:
    def __init__(self, cfg: dict, queue: MessageQueue, data_dir: Path, log=print, save=True):
        self.cfg = cfg
        self.c = cfg["coach"]
        self.q = queue
        self.data_dir = Path(data_dir)
        self.log = log
        self.save = save
        self.ref: Reference | None = None
        self.session_key = None
        self.session: SessionLog | None = None
        self._reset_lap(None)
        self.issues: dict[int, Issue] = {}
        self.best_corner: dict = {}
        self.corner_hist: dict[int, list] = {}
        self.focus: dict[int, str] = {}
        self.chat = 3
        self.listeners = []          # callbacks (texto, prioridad) para la interfaz
        self.names: dict[int, str] = {}
        self.live_delta = None       # delta en vivo contra la vuelta de referencia (s)
        self._sector_start_delta = 0.0
        self.last_frame = None
        self.rivals = RivalTracker(self, cfg.get("rivales", {}))
        self.car = CarAdvisor(self, self.c)
        self.fuel_hist: list[tuple[float, float, float]] = []  # (fuel, ve, lap_time)
        self.prev: Frame | None = None
        self.safe = True
        self.best = 0.0
        self.completed_laps = 0

    # ------------------------------------------------------------------ util
    def say(self, text, prio=NORMAL, key="", cooldown=0.0, ttl=0.0):
        if key_level(key or "x") > self.chat:
            self.log(f"[silenciado nivel {self.chat}] {text}")
            return
        if self.q.push(text, prio, key, cooldown, ttl):
            self.log(f"[{['CRIT', 'AVISO', 'ALTA', 'NORM', 'BAJA'][prio]}] {text}")
            for cb in self.listeners:
                cb(text, prio)

    def level(self, f: Frame) -> int:
        """Nivel de charla actual (0..4); en carrera usa su propio nivel."""
        legacy = {"minimo": 1, "carrera": 2, "completo": 4}
        lv = self.c.get("charla_carrera" if f.is_race else "charla", 3)
        if isinstance(lv, str):
            lv = legacy.get(lv, 3)
        return max(0, min(4, int(lv)))

    def cname(self, n: int, low: bool = False) -> str:
        """Nombre real de la curva (La Source, Bus Stop…) o 'Curva N'."""
        name = self.names.get(n)
        if name:
            return name
        return f"{'curva' if low else 'Curva'} {n}"

    def reload_names(self) -> None:
        if self.ref:
            from ..tracks import corner_names
            self.names = corner_names(self.data_dir, self.ref.track, self.ref.corners, self.ref.length)
        else:
            self.names = {}

    def can_speak(self) -> bool:
        return self.safe

    def _reset_lap(self, f: Frame | None):
        self.trace = LapTrace()
        self.lap = f.lap if f else None
        self.lap_start = f.lap_start_t if f else 0.0
        self.lap_invalid = False
        self.lap_pits = False
        self.evaluated: set[int] = set()
        self.cued: set[int] = set()
        self.corner_res: dict[int, dict] = {}
        self.start_fuel = f.fuel if f else 0.0
        self.start_ve = f.virtual_energy if f else -1.0
        self.tyre_acc = [[0.0, 0.0, 0.0] for _ in range(4)]
        self.carcass_acc = [0.0] * 4
        self.press_acc = [0.0] * 4
        self.brake_max = [0.0] * 4
        self.tyre_n = 0
        self.rh_min = [9.0, 9.0]
        self._sector_start_delta = 0.0
        self.live_delta = None

    # ------------------------------------------------------------------ sesión
    def _check_session(self, f: Frame) -> None:
        key = (f.track, f.car, f.session)
        if key == self.session_key:
            return
        same_combo = self.session_key and self.session_key[:2] == key[:2]
        self.session_key = key
        if self.session:
            self.session.close()
        self.session = SessionLog(self.data_dir, f) if self.save else None
        self.fuel_hist.clear()
        self.issues.clear()
        self.best_corner.clear()
        self.corner_hist.clear()
        self.focus.clear()
        self.rivals = RivalTracker(self, self.cfg.get("rivales", {}))
        self.car = CarAdvisor(self, self.c)
        if not same_combo:
            self.ref = Reference.load(self.data_dir, f.track, f.car)
            self.reload_names()
            if self.ref:
                self.best = self.ref.lap_time
                self.say(f"Referencia cargada para {f.track}. Mejor vuelta {say_laptime(self.ref.lap_time)}. "
                         f"{len(self.ref.corners)} curvas.", NORMAL, "ref")
            else:
                self.best = 0.0
                self.say("Sin referencia para esta combinación. Dame una vuelta limpia y la uso de base.",
                         NORMAL, "ref")
        if self.session and self.ref:
            self.session.set_reference(self.ref)

    # ------------------------------------------------------------------ bucle
    def on_frame(self, f: Frame) -> None:
        self.last_frame = f
        self.chat = self.level(f)
        if not f.in_realtime or not f.track:
            self.safe = True
            return
        self._check_session(f)

        if self.lap is None:
            self._reset_lap(f)
        elif f.lap != self.lap:
            self._finish_lap(f)
            self._reset_lap(f)

        if f.in_pits:
            self.lap_pits = True
        else:
            self.trace.add(f)
        if f.lap_invalid and not self.lap_invalid:
            self.lap_invalid = True
            self.say("Vuelta invalidada.", NORMAL, "invalid", 10)

        if f.speed > 20:
            for i in range(4):
                for j in range(3):
                    self.tyre_acc[i][j] += f.tyre_temp[i][j]
                self.press_acc[i] += f.tyre_press[i]
                self.carcass_acc[i] += f.tyre_carcass[i]
                self.brake_max[i] = max(self.brake_max[i], f.brake_temp[i])
            self.tyre_n += 1
            if f.ride_h_front > 0:
                self.rh_min[0] = min(self.rh_min[0], f.ride_h_front)
            if f.ride_h_rear > 0:
                self.rh_min[1] = min(self.rh_min[1], f.ride_h_rear)

        self.car.on_frame(f)
        if self.ref and not f.in_pits:
            self._delta(f)
            self._corners(f)
        self._flags(f)
        self._update_safe(f)
        self.prev = f

    def _delta(self, f: Frame) -> None:
        """Vuelta fantasma: tiempo actual contra el de la referencia en el mismo punto de la pista."""
        if f.dist < 30 or not self.trace.d or self.trace.d[0] > 60:
            self.live_delta = None
            return
        t_ref = self.ref.time_at(min(f.dist, self.ref.data["d"][-1]))
        if t_ref is None:
            return
        self.live_delta = f.lap_time - t_ref
        p = self.prev
        if p is not None and p.sector != f.sector and p.lap == f.lap and p.sector in (1, 2):
            sec_delta = self.live_delta - self._sector_start_delta
            self._sector_start_delta = self.live_delta
            if abs(sec_delta) >= 0.1:
                sign = "menos" if sec_delta < 0 else "más"
                self.say(f"Sector {p.sector}, {sign} {say_tenths(sec_delta)}.", LOW, "sector", 5)

    def _update_safe(self, f: Frame) -> None:
        calm = f.brake < 0.05 and abs(f.steer) < 0.2 and abs(f.lat_g) < 0.9 and f.throttle > 0.7
        if calm and self.ref:
            nxt = self._next_corner(f.dist)
            if nxt and 0 <= nxt.brake_d - f.dist < max(f.speed * 1.2, 40):
                calm = False
        self.safe = calm or f.speed < 5 or f.in_pits

    def _next_corner(self, d: float):
        for c in self.ref.corners:
            if c.brake_d >= d:
                return c
        return None

    # ------------------------------------------------------------------ curvas
    def _corners(self, f: Frame) -> None:
        lead = float(self.c.get("anticipacion_s", 3.0))
        lv = self.level(f)
        for c in self.ref.corners:
            # aviso anticipado
            if (self.c.get("avisos_anticipados", True) and (c.num in self.issues or c.num in self.focus)
                    and c.num not in self.cued):
                trig = c.brake_d - f.speed * lead
                if trig <= f.dist < c.brake_d - 25:
                    self.cued.add(c.num)
                    text = self.issues[c.num].cue if c.num in self.issues else self.focus[c.num]
                    self.say(text, CUE, f"cue{c.num}", ttl=lead * 0.8)
            # evaluación al salir
            if c.num not in self.evaluated and f.dist > max(c.exit_d, c.seg_end_d) + 5:
                self.evaluated.add(c.num)
                if self.trace.d and self.trace.d[0] <= c.entry_d:
                    self._evaluate(c, f, lv)

    def _target(self, num: int):
        """Objetivo de la curva: la mejor ejecución de la sesión o la de la vuelta de referencia."""
        r = self.ref.metrics.get(num)
        b = self.best_corner.get(num)
        if b and r and b.time < r.time:
            return b
        return r

    def _evaluate(self, c, f: Frame, lv: str) -> None:
        m = trace_metrics(c, self.trace)
        r = self._target(c.num)
        if not m or not r:
            return
        loss = m.time - r.time
        if loss > max(2.0, 0.4 * r.time):
            # trompo, salida de pista o tráfico: no es un error de técnica, no se coachea
            self.corner_res[c.num] = {**asdict(m), "loss": loss, "incident": True}
            self.log(f"(incidente en curva {c.num}: +{loss:.1f} s, ignorado)")
            return
        self.corner_res[c.num] = {**asdict(m), "loss": loss}
        best = self.best_corner.get(c.num)
        if not f.lap_invalid and (best is None or m.time < best.time):
            self.best_corner[c.num] = m
        kind, post, cue = self._diagnose(c.num, m, r, loss, c.braking)
        self.corner_hist.setdefault(c.num, []).append((loss, kind))
        self.corner_hist[c.num] = self.corner_hist[c.num][-3:]
        if lv < 2:
            return
        th = LOSS_BY_LEVEL.get(lv, 0.15)
        prev = self.issues.get(c.num)

        if kind and loss >= th:
            if prev and prev.kind == kind:
                prev.count += 1
                if prev.count in (2, 4) or prev.count % 4 == 0:
                    self.say(f"{self.cname(c.num)}, otra vez: {post.split(': ', 1)[-1]}", NORMAL, f"c{c.num}", 20)
            else:
                self.issues[c.num] = Issue(kind, c.num, cue)
                self.say(post, NORMAL, f"c{c.num}", 20)
        elif loss >= 2 * th:
            self.say(f"{self.cname(c.num)}: perdiste {say_tenths(loss)} contra tu mejor.", LOW, f"cgen{c.num}", 30)
        else:
            if prev and loss < th:
                del self.issues[c.num]
                if self.c.get("felicitar", True):
                    self.say(f"{self.cname(c.num)} corregida, bien.", LOW, f"ok{c.num}", 30)
            elif loss <= -0.1 and self.c.get("felicitar", True):
                self.say(f"{self.cname(c.num)}, nueva mejor, {say_tenths(loss)} más rápido.", LOW, f"ok{c.num}", 60)

    def _diagnose(self, n: int, m, r, loss: float, braking: bool = True):
        c = self.c
        N = self.cname(n)
        db = (m.brake_d - r.brake_d) if (m.brake_d is not None and r.brake_d is not None) else None
        if not braking:
            # curva de solo levantar: no hay punto de frenada que comparar
            if m.peak_brake > 0.25 and r.peak_brake < 0.15:
                return ("brake_in_lift", f"{N}: frenaste donde en tu mejor solo levantaste el acelerador, "
                        f"{say_tenths(loss)}. Confía en el agarre: solo levanta.", f"{N}, solo levanta")
            db = None
        dv = m.min_speed - r.min_speed
        dt = (m.full_throttle_d - r.full_throttle_d) if (m.full_throttle_d and r.full_throttle_d) else None
        t = say_tenths(loss)
        gear = (f" Tu mejor usó {r.apex_gear}ª, tú {m.apex_gear}ª."
                if r.apex_gear and m.apex_gear and r.apex_gear != m.apex_gear else "")
        if m.lock > c["umbral_bloqueo"]:
            return ("lock", f"{N}: bloqueaste delanteras, {t}. Pisa fuerte al inicio y suelta presión a medida que giras.",
                    f"{N}, cuidado el bloqueo")
        if m.spin > c["umbral_patinaje"]:
            return ("spin", f"{N}: patinan las traseras en la salida, {t}. Endereza el volante antes de pisar a fondo.{gear}",
                    f"{N}, salida suave")
        if db is not None and db > c["umbral_frenada_m"] and dv < -c["umbral_vel_min_kmh"] / 2:
            return ("late_brake", f"{N}: frenaste {say_int(db)} metros más tarde que tu mejor y te pasaste, {t}. "
                    f"Frena en tu punto y prioriza la salida.", f"{N}, frena en tu punto")
        if db is not None and db < -c["umbral_frenada_m"]:
            return ("early_brake", f"{N}: frenaste {say_int(-db)} metros antes que tu mejor, {t}. "
                    f"Aguanta la frenada hasta tu punto.", f"{N}, aguanta {say_int(-db)} metros")
        if r.peak_brake > 0.6 and m.peak_brake < r.peak_brake - 0.12:
            return ("weak_brake", f"{N}: llegaste solo al {m.peak_brake * 100:.0f} por ciento de freno, tu mejor al "
                    f"{r.peak_brake * 100:.0f}, {t}. Golpe de freno más fuerte al inicio.", f"{N}, freno fuerte")
        if dv < -c["umbral_vel_min_kmh"]:
            if r.trail_m - m.trail_m > 15:
                tip = "Sueltas el freno de golpe: llévalo suave hasta el vértice para rotar el auto."
            elif m.coast_m - r.coast_m > 12:
                tip = f"Vas {say_int(m.coast_m)} metros sin pedal. Pasa del freno al acelerador sin pausa."
            elif db is not None and db > 3:
                tip = "Entras pasado: frena un poco antes para llevar más velocidad al vértice."
            else:
                tip = "Suelta el freno antes y deja rodar el auto."
            return ("slow_apex", f"{N}: {say_int(-dv)} kilómetros por hora menos en el vértice, {t}. {tip}{gear}",
                    f"{N}, más velocidad al vértice")
        if m.coast_m - r.coast_m > 15:
            return ("coast", f"{N}: {say_int(m.coast_m)} metros sin pedal entre freno y acelerador, {t}. "
                    f"Empieza a acelerar suave apenas sueltas el freno.", f"{N}, sin pausa")
        if dt is not None and dt > c["umbral_acelerador_m"]:
            return ("late_throttle", f"{N}: aceleraste a fondo {say_int(dt)} metros tarde, {t}.{gear}",
                    f"{N}, acelera antes")
        return (None, "", "")

    # ------------------------------------------------------------------ vuelta
    def _finish_lap(self, f: Frame) -> None:
        lap_time = f.lap_start_t - self.lap_start if f.lap_start_t > self.lap_start else 0.0
        tl = f.track_len or (self.ref.length if self.ref else 0)
        complete = (len(self.trace) > 50 and tl > 0 and self.trace.d[0] < 60
                    and self.trace.max_d > tl * 0.95)
        valid = complete and not self.lap_invalid and not self.lap_pits and lap_time > 10
        lv = self.level(f)
        prev_best = self.best
        if complete:
            self.completed_laps += 1

        # resumen por vuelta para el debrief
        n = max(self.tyre_n, 1)
        summary = {
            "lap": self.lap, "time": lap_time, "valid": valid, "complete": complete,
            "pits": self.lap_pits, "corners": self.corner_res,
            "tyre_temp": [[round(x / n, 1) for x in w] for w in self.tyre_acc],
            "tyre_press": [round(x / n, 1) for x in self.press_acc],
            "tyre_carcass": [round(x / n, 1) for x in self.carcass_acc],
            "tyre_opt": f.tyre_opt, "tyre_wear": f.tyre_wear, "brake_max": self.brake_max,
            "ride_min": [x if x < 9.0 else None for x in self.rh_min], "fuel_used": self.start_fuel - f.fuel,
            "ve_used": (self.start_ve - f.virtual_energy) if self.start_ve > 0 and f.virtual_energy > 0 else None,
            "compound": f.compound, "air": f.air_temp, "track_temp": f.track_temp,
        }

        if valid:
            if self.ref is None or lap_time < self.ref.lap_time:
                first = self.ref is None
                self.ref = Reference.from_trace(self.trace, f.track, f.car, lap_time, tl)
                self.reload_names()
                self.best = lap_time
                self.issues.clear()
                self.best_corner.clear()
                if self.save:
                    self.ref.save(self.data_dir)
                if self.session:
                    self.session.set_reference(self.ref)
                if first:
                    self.say(f"Vuelta de referencia: {say_laptime(lap_time)}. Detecté {len(self.ref.corners)} curvas. "
                             f"Desde ahora te comparo contra ella.", NORMAL, "lap")
                else:
                    gain = prev_best - lap_time
                    self.say(f"Nueva mejor vuelta, {say_laptime(lap_time)}, {say_tenths(gain)} más rápida.",
                             NORMAL, "lap")
            else:
                d = lap_time - self.best
                worst = max(((n, r) for n, r in self.corner_res.items() if not r.get("incident")),
                            key=lambda kv: kv[1]["loss"], default=None)
                tail = ""
                if worst and worst[1]["loss"] > 0.1 and lv >= 2:
                    tail = f" Lo que más cuesta: {self.cname(worst[0], low=True)}, {say_tenths(worst[1]['loss'])}."
                self.say(f"{say_laptime(lap_time)}, {say_delta(d)}.{tail}", NORMAL, "lap")
        clean = {n: r for n, r in self.corner_res.items() if not r.get("incident")} if valid else {}
        braking = {c.num for c in self.ref.corners if c.braking} if self.ref else set()
        summary["car"] = self.car.end_lap(self.lap, complete and not self.lap_pits and not self.lap_invalid,
                                          clean, braking)
        self._update_focus(lv)
        if f.is_race:
            rep = self.rivals.lap_report(self.lap)
            summary["rivals"] = self.rivals.snapshot()
            if rep:
                self.say(rep, NORMAL, "rivals", 20)
        if complete and not self.lap_pits:
            self._fuel(f, lap_time, summary)
            if self.completed_laps >= 2:
                self._tyres(f, summary)
        if self.session:
            self.session.add_lap(summary, self.trace, tl)

    def _update_focus(self, lv: int) -> None:
        """Curvas con más potencial (pérdida media de las últimas vueltas) → avisos anticipados."""
        n = FOCUS_BY_LEVEL.get(lv, 0)
        cands = []
        for num, h in self.corner_hist.items():
            if len(h) < 2:
                continue
            avg = sum(x[0] for x in h) / len(h)
            if avg >= 0.08:
                kinds = [k for _, k in h if k]
                kind = max(set(kinds), key=kinds.count) if kinds else None
                cands.append((avg, num, kind))
        cands.sort(reverse=True)
        self.focus = {}
        for avg, num, kind in cands[:n]:
            tip = SHORT_TIP.get(kind, "concéntrate aquí")
            self.focus[num] = f"{self.cname(num)}, {say_tenths(avg)}: {tip}"

    def state(self) -> dict:
        """Resumen para la interfaz gráfica."""
        f = self.last_frame
        corners = []
        if self.ref:
            for c in self.ref.corners:
                h = self.corner_hist.get(c.num, [])
                kinds = [k for _, k in h if k]
                corners.append({"num": c.num, "name": self.names.get(c.num, ""), "apex_d": c.apex_d, "last": h[-1][0] if h else None,
                                "avg": sum(x[0] for x in h) / len(h) if h else None,
                                "kind": max(set(kinds), key=kinds.count) if kinds else None,
                                "focus": c.num in self.focus or c.num in self.issues})
        fuel_laps = None
        if self.fuel_hist and f:
            h = self.fuel_hist[-3:]
            avg_f = sum(x[0] for x in h) / len(h)
            fuel_laps = f.fuel / avg_f if avg_f > 0 else None
            avg_ve = sum(x[1] for x in h) / len(h)
            if f.virtual_energy > 0 and avg_ve > 0:
                ve_laps = f.virtual_energy / avg_ve
                fuel_laps = min(fuel_laps, ve_laps) if fuel_laps else ve_laps
        return {"frame": f, "best": self.best, "delta": self.live_delta, "names": self.names, "ref_time": self.ref.lap_time if self.ref else None,
                "corners": corners, "chat": self.chat, "rivals": self.rivals.snapshot(),
                "car": self.car.lap_stats(), "fuel_laps": fuel_laps, "lap": self.lap}

    def _tyres(self, f: Frame, s: dict) -> None:
        win = float(self.cfg["llantas"]["ventana_c"])
        dflt = float(self.cfg["llantas"]["optima_por_defecto_c"])
        devs = []
        carc = s.get("tyre_carcass") or [0.0] * 4
        for i in range(4):
            # LMU reporta la óptima para la carcasa; si no hay carcasa, usa la superficie
            if carc[i] <= 0 and f.tyre_opt[i]:
                return  # la óptima del juego es de carcasa; sin dato de carcasa no se puede comparar
            avg = carc[i] if carc[i] > 0 else sum(s["tyre_temp"][i]) / 3
            opt = f.tyre_opt[i] or dflt
            devs.append(avg - opt)
        msgs = []
        for pair, name in (((0, 1), "Delanteras"), ((2, 3), "Traseras")):
            a, b = devs[pair[0]], devs[pair[1]]
            if a < -win and b < -win:
                msgs.append(f"{name} frías, {say_int(-(a + b) / 2)} grados bajo la ventana")
            elif a > win and b > win:
                msgs.append(f"{name} calientes, {say_int((a + b) / 2)} grados por encima")
            else:
                for i in pair:
                    if abs(devs[i]) > win * 1.5:
                        st = "fría" if devs[i] < 0 else "caliente"
                        msgs.append(f"{WHEEL_ES[WHEELS[i]].capitalize()} {st}")
        state = tuple(sorted(m.split(",")[0] for m in msgs))
        last_state, last_lap = getattr(self, "_tyre_state", ((), -99))
        if msgs and (state != last_state or self.completed_laps - last_lap >= 6):
            self._tyre_state = (state, self.completed_laps)
            self.say(". ".join(msgs) + ".", HIGH if any("calientes" in m for m in msgs) else NORMAL, "tyres", 60)
        elif not msgs and last_state:
            self._tyre_state = ((), self.completed_laps)
            self.say("Llantas en temperatura.", NORMAL, "tyres", 60)

    def _fuel(self, f: Frame, lap_time: float, s: dict) -> None:
        used = s["fuel_used"]
        ve = s["ve_used"]
        if used <= 0.05 or lap_time <= 0:
            return
        self.fuel_hist.append((used, ve or 0.0, lap_time))
        h = self.fuel_hist[-3:]
        avg_f = sum(x[0] for x in h) / len(h)
        avg_t = sum(x[2] for x in h) / len(h)
        laps_f = f.fuel / avg_f if avg_f > 0 else 99
        what, laps_left = "Combustible", laps_f
        if f.virtual_energy > 0 and all(x[1] > 0 for x in h):
            avg_ve = sum(x[1] for x in h) / len(h)
            laps_ve = f.virtual_energy / avg_ve
            if laps_ve < laps_f:
                what, laps_left = "Energía", laps_ve
        warn = float(self.cfg["combustible"]["avisar_vueltas"])
        to_go = None
        if f.is_race:
            if 0 < f.max_laps < 10000:
                to_go = max(0, f.max_laps - f.lap)
            elif f.time_remaining > 0 and avg_t > 0:
                to_go = math.ceil(f.time_remaining / avg_t)
            elif f.time_remaining <= 0 and f.max_laps >= 10000:
                to_go = 1   # carrera por tiempo con el reloj en cero: última vuelta
        if laps_left < 1.3 and not (to_go is not None and laps_left >= to_go - 0.05):
            self.say(f"{'Energía crítica' if what == 'Energía' else 'Combustible crítico'}. Entra a pits.", HIGH, "fuelcrit", 30)
            return
        if f.is_race and to_go is not None and laps_left < to_go:
            deficit = to_go - laps_left
            if deficit < 1.0 and to_go > 0:
                if what == "Combustible":
                    save = avg_f - f.fuel / to_go
                    self.say(f"Para llegar sin parar ahorra {save:.1f} litros por vuelta.".replace(".", " punto ", 1),
                             NORMAL, "fuel", 60)
                else:
                    self.say(f"Para llegar sin parar ahorra un {deficit / to_go * 100:.0f} por ciento de energía.",
                             NORMAL, "fuel", 60)
                return
        if laps_left <= warn or self.completed_laps % 5 == 0:
            tail = " Alcanza para terminar." if (f.is_race and to_go is not None and laps_left >= to_go + 0.3) else ""
            self.say(f"{what} para {say_laps(math.floor(laps_left))}.{tail}", NORMAL, "fuel", 45)

    # ------------------------------------------------------------------ banderas
    def _flags(self, f: Frame) -> None:
        p = self.prev
        if p is None:
            return
        if f.flag == 6 and p.flag != 6:
            self.say("Bandera azul, deja pasar.", CRITICAL, "blue", 20)
        if f.game_phase == 6 and p.game_phase != 6:
            self.say("Bandera amarilla de pista completa. Baja el ritmo.", CRITICAL, "fcy", 10)
        if f.game_phase == 5 and p.game_phase == 6:
            self.say("Verde, verde, verde.", CRITICAL, "green", 10)
        if f.sector_flags != p.sector_flags:
            self.log(f"(debug) banderas de sector {tuple(f.sector_flags)} sector={f.sector} fcy={f.yellow_state}")
        sec = f.sector if 0 <= f.sector < 3 else 0
        now_y = bool(f.sector_flags) and f.sector_flags[sec] == 1
        prev_y = p.sector == f.sector and bool(p.sector_flags) and p.sector_flags[sec] == 1
        if now_y and not prev_y:
            self.say("Amarilla en este sector, cuidado.", CRITICAL, "yellow", 20)
        if f.track_limits_steps > p.track_limits_steps:
            self.say("Cuidado con los límites de pista.", HIGH, "limits", 15)

    def on_cars(self, cars, f: Frame) -> None:
        if f.in_realtime and f.track:
            self.rivals.update(cars, f)

    def close(self) -> Path | None:
        if self.session:
            return self.session.close()
        return None
