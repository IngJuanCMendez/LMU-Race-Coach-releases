"""LMU Race Coach — aplicación de escritorio."""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
                               QInputDialog,
                               QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMainWindow, QMessageBox, QProgressBar, QPushButton, QScrollArea,
                               QSlider, QStackedWidget, QTableWidget, QTableWidgetItem, QTextBrowser, QVBoxLayout,
                               QWidget)

from .. import __version__
from .. import config as C
from ..coach.engine import CHAT_DESC, CHAT_LEVELS, SHORT_TIP
from ..frame import WHEELS
from ..runner import CoachRunner
from . import theme as T

ROOT = Path(__file__).resolve().parent.parent.parent
KIND_ES = {**SHORT_TIP, None: "—"}


def fmt_time(t: float | None) -> str:
    if not t or t <= 0:
        return "-:--.---"
    m, s = divmod(t, 60)
    return f"{int(m)}:{s:06.3f}"


class Bridge(QObject):
    """Señales para pasar resultados de hilos de fondo a la interfaz."""
    text = Signal(str, str)        # destino, texto
    done = Signal(str, object)     # tarea, resultado


def card(title: str) -> tuple[QFrame, QVBoxLayout]:
    f = QFrame()
    f.setObjectName("card")
    lay = QVBoxLayout(f)
    lay.setContentsMargins(14, 10, 14, 12)
    lay.setSpacing(4)
    t = QLabel(title.upper())
    t.setObjectName("cardTitle")
    lay.addWidget(t)
    return f, lay


def lab(text="", obj=None, align=None) -> QLabel:
    lb = QLabel(text)
    if obj:
        lb.setObjectName(obj)
    if align:
        lb.setAlignment(align)
    return lb


# ====================================================================== EN VIVO
class LivePage(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.win = win
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)

        # cabecera
        head = QHBoxLayout()
        self.status = lab("● Detenido", "h2")
        self.session = lab("", "muted")
        head.addWidget(self.status)
        head.addSpacing(14)
        head.addWidget(self.session, 1)
        head.addWidget(lab("Charla:", "muted"))
        self.chat = QComboBox()
        for k, v in CHAT_LEVELS.items():
            self.chat.addItem(f"{k} · {v}", k)
        self.chat.setCurrentIndex(int(win.cfg["coach"]["charla"]))
        self.chat.setToolTip("Nivel de charla actual (práctica o carrera según la sesión)")
        self.chat.currentIndexChanged.connect(self._chat_changed)
        head.addWidget(self.chat)
        self.btn_start = QPushButton("▶  Iniciar coach")
        self.btn_start.setObjectName("primary")
        self.btn_start.clicked.connect(win.toggle_coach)
        self.btn_demo = QPushButton("Demo")
        self.btn_demo.setToolTip("Carrera simulada sin el juego, para ver y oír la app")
        self.btn_demo.clicked.connect(win.toggle_demo)
        head.addWidget(self.btn_demo)
        head.addWidget(self.btn_start)
        root.addLayout(head)

        grid = QGridLayout()
        grid.setSpacing(12)

        c, l = card("Vuelta")
        self.cur = lab("-:--.---", "big")
        self.delta = lab("", "mid")
        row = QHBoxLayout()
        row.addWidget(self.cur)
        row.addStretch()
        row.addWidget(self.delta)
        l.addLayout(row)
        self.lapinfo = lab("Última -:--.---   ·   Mejor -:--.---", "muted")
        l.addWidget(self.lapinfo)
        grid.addWidget(c, 0, 0, 1, 2)

        c, l = card("Posición en clase")
        self.pos = lab("P–", "big")
        self.ahead = lab("Adelante —", "muted")
        self.behind = lab("Atrás —", "muted")
        l.addWidget(self.pos)
        l.addWidget(self.ahead)
        l.addWidget(self.behind)
        grid.addWidget(c, 0, 2)

        c, l = card("Energía")
        self.fuel = lab("— L", "mid")
        self.fuel_laps = lab("— vueltas", "muted")
        self.ve = lab("", "muted")
        l.addWidget(self.fuel)
        l.addWidget(self.fuel_laps)
        l.addWidget(self.ve)
        grid.addWidget(c, 0, 3)

        c, l = card("Llantas (°C / kPa)")
        tg = QGridLayout()
        self.tyres = []
        for i, w in enumerate(WHEELS):
            b = lab(w, "mid", Qt.AlignCenter)
            b.setMinimumHeight(56)
            b.setStyleSheet(f"background:{T.PANEL2}; border-radius:8px;")
            tg.addWidget(b, i // 2, i % 2)
            self.tyres.append(b)
        l.addLayout(tg)
        grid.addWidget(c, 1, 0)

        c, l = card("Ayudas")
        self.aids = lab("—", "h2")
        self.aids.setWordWrap(True)
        self.aids_stats = lab("", "muted")
        self.aids_stats.setWordWrap(True)
        l.addWidget(self.aids)
        l.addWidget(self.aids_stats)
        grid.addWidget(c, 1, 1)

        c, l = card("Pedales")
        ph = QHBoxLayout()
        self.thr = QProgressBar()
        self.thr.setObjectName("thr")
        self.brk = QProgressBar()
        self.brk.setObjectName("brk")
        for b in (self.thr, self.brk):
            b.setOrientation(Qt.Vertical)
            b.setRange(0, 100)
            b.setFixedWidth(22)
            b.setMinimumHeight(90)
            ph.addWidget(b)
        sp = QVBoxLayout()
        self.speed = lab("0", "big")
        self.gear = lab("km/h · N", "muted")
        sp.addWidget(self.speed)
        sp.addWidget(self.gear)
        ph.addSpacing(10)
        ph.addLayout(sp, 1)
        l.addLayout(ph)
        grid.addWidget(c, 1, 2)

        c, l = card("Vuelta de referencia")
        self.ref = lab("—", "mid")
        self.ref_info = lab("Da una vuelta limpia para crearla", "muted")
        self.ref_info.setWordWrap(True)
        l.addWidget(self.ref)
        l.addWidget(self.ref_info)
        grid.addWidget(c, 1, 3)
        for col in range(4):
            grid.setColumnStretch(col, 1)
        root.addLayout(grid)

        low = QHBoxLayout()
        low.setSpacing(12)
        c, l = card("Curvas — pérdida contra tu mejor ejecución")
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Curva", "Última", "Media", "Qué mejorar", "Aviso"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.setToolTip("Doble clic en una curva para ponerle su nombre (se guarda para este circuito)")
        self.table.cellDoubleClicked.connect(self._rename)
        self._rows = []
        l.addWidget(self.table)
        low.addWidget(c, 3)
        c, l = card("Radio del ingeniero")
        self.radio = QListWidget()
        self.radio.setObjectName("radio")
        self.radio.setWordWrap(True)
        self.radio.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        l.addWidget(self.radio)
        low.addWidget(c, 2)
        root.addLayout(low, 1)
        self._seen = None

    def _rename(self, row, _col):
        r = self.win.runner
        if not (r and r.engine and r.engine.ref) or row >= len(self._rows):
            return
        c = self._rows[row]
        name, ok = QInputDialog.getText(self, "Nombre de la curva",
                                        f"Curva {c['num']} (vértice a {c['apex_d']:.0f} m). Nombre:",
                                        text=c.get("name", ""))
        if ok:
            from ..tracks import save_user_name
            save_user_name(r.engine.data_dir, r.engine.ref.track, c["apex_d"], name)
            r.engine.reload_names()

    def _chat_changed(self, _):
        st = self.win.runner.engine.last_frame if (self.win.runner and self.win.runner.engine) else None
        key = "charla_carrera" if (st and st.is_race) else "charla"
        self.win.cfg["coach"][key] = self.chat.currentData()
        self.win.save_cfg()

    def refresh(self):
        r = self.win.runner
        status = r.status if r else "detenido"
        colors = {"conectado": T.GOOD, "demo": T.ACCENT, "esperando": T.WARN}
        col = colors.get(status, T.BAD if status.startswith("error") else T.MUTED)
        text = {"conectado": "Conectado a LMU", "esperando": "Esperando a Le Mans Ultimate…",
                "demo": "Demo", "detenido": "Detenido", "iniciando": "Iniciando…"}.get(status, status)
        self.status.setText(f"<span style='color:{col}'>●</span> {text}")
        running = bool(r and r.running)
        self.btn_start.setText("■  Detener" if running and r.mode == "lmu" else "▶  Iniciar coach")
        self.btn_start.setObjectName("danger" if running and r.mode == "lmu" else "primary")
        self.btn_start.style().polish(self.btn_start)
        self.btn_demo.setText("■ Detener demo" if running and r.mode == "demo" else "Demo")
        if not (r and r.engine):
            return
        e = r.engine
        st = e.state()
        f = st["frame"]
        # radio
        items = list(r.radio)
        if items and items[0] is not self._seen:
            new = []
            for it in items:
                if it is self._seen:
                    break
                new.append(it)
            for hora, texto, prio in reversed(new):
                li = QListWidgetItem(f"{hora}   {texto}")
                if prio == 0:
                    li.setForeground(QColor(T.BAD))
                elif prio == 1:
                    li.setForeground(QColor(T.ACCENT))
                self.radio.insertItem(0, li)
            self._seen = items[0]
            while self.radio.count() > 150:
                self.radio.takeItem(self.radio.count() - 1)
        if f is None:
            return
        idx = self.chat.findData(st["chat"])
        if idx >= 0 and idx != self.chat.currentIndex():
            self.chat.blockSignals(True)
            self.chat.setCurrentIndex(idx)
            self.chat.blockSignals(False)
        from ..coach.session_log import session_name
        self.session.setText(f"{f.track}  ·  {f.car}  ·  {session_name(f.session)}")
        self.cur.setText(fmt_time(f.lap_time if f.lap_time > 0 else 0))
        dl = st.get("delta") if st.get("delta") is not None else (f.delta_best or None)
        if dl is not None and st["best"]:
            c = T.MUTED if abs(dl) < 0.05 else (T.GOOD if dl < 0 else T.BAD)
            self.delta.setText(f"<span style='color:{c}'>{dl:+.2f}</span>")
        else:
            self.delta.setText("")
        self.lapinfo.setText(f"Última {fmt_time(f.last_lap)}   ·   Mejor {fmt_time(st['best'])}   ·   Vuelta {f.lap}")
        rv = st["rivals"]
        if rv.get("class_pos"):
            self.pos.setText(f"P{rv['class_pos']} <span style='font-size:16px;color:{T.MUTED}'>/ {rv['n_class']}</span>")
            self.ahead.setText(f"Adelante  {rv['ahead']}  +{rv['gap_ahead']:.1f}s" if rv.get("ahead") and rv.get("gap_ahead") is not None else "Adelante —")
            self.behind.setText(f"Atrás  {rv['behind']}  −{rv['gap_behind']:.1f}s" if rv.get("behind") and rv.get("gap_behind") is not None else "Atrás —")
        self.fuel.setText(f"{f.fuel:.1f} L")
        self.fuel_laps.setText(f"{st['fuel_laps']:.1f} vueltas" if st["fuel_laps"] else "calculando…")
        self.ve.setText(f"Energía virtual {f.virtual_energy * 100:.0f} %" if f.virtual_energy > 0 else "")
        win = float(self.win.cfg["llantas"]["ventana_c"])
        for i, b in enumerate(self.tyres):
            surf = sum(f.tyre_temp[i]) / 3
            carc = f.tyre_carcass[i]
            t = carc if carc > 0 else surf
            opt = f.tyre_opt[i] or float(self.win.cfg["llantas"]["optima_por_defecto_c"])
            col = T.temp_color(t, opt, win) if carc > 0 else T.TEXT
            b.setText(f"<span style='color:{col}'>{t:.0f}°</span><br><span style='font-size:11px;color:{T.MUTED}'>"
                      f"{f.tyre_press[i]:.0f} kPa</span>")
        car = st["car"]
        parts = []
        if f.brake_bias_rear > 0:
            parts.append(f"Reparto {(1 - f.brake_bias_rear) * 100:.1f}%")
        if f.abs_max:
            parts.append(f"ABS {f.abs_level}")
        if f.tc_max:
            parts.append(f"TC {f.tc_level}")
        if f.tc_slip_max:
            parts.append(f"Slip {f.tc_slip}")
        if f.tc_cut_max:
            parts.append(f"Cut {f.tc_cut}")
        self.aids.setText("  ·  ".join(parts) or "—")
        ex = e.car.experiment
        exp = (f"\nProbando {ex['key'].replace('_level', '').replace('_', ' ').upper()} {ex['old']} → {ex['new']}"
               if ex else "")
        self.aids_stats.setText(f"Esta vuelta: bloqueo {car['lock_f'] * 100:.0f}% · ABS {car['abs'] * 100:.0f}% · "
                                f"patinaje {car['spin'] * 100:.0f}% · TC {car['tc'] * 100:.0f}%{exp}")
        self.thr.setValue(int(f.throttle * 100))
        self.brk.setValue(int(f.brake * 100))
        self.speed.setText(f"{f.kmh:.0f}")
        self.gear.setText(f"km/h  ·  marcha {'R' if f.gear < 0 else ('N' if f.gear == 0 else f.gear)}")
        if st["ref_time"]:
            self.ref.setText(fmt_time(st["ref_time"]))
            self.ref_info.setText(f"{len(st['corners'])} curvas detectadas")
        rows = st["corners"]
        self._rows = rows
        self.table.setRowCount(len(rows))
        for i, c in enumerate(rows):
            vals = [f"{c['num']} · {c['name']}" if c.get("name") else str(c["num"]),
                    f"{c['last']:+.2f}" if c["last"] is not None else "",
                    f"{c['avg']:+.2f}" if c["avg"] is not None else "",
                    KIND_ES.get(c["kind"], c["kind"] or "—") if (c["avg"] or 0) > 0.03 else "—",
                    "★" if c["focus"] else ""]
            for j, v in enumerate(vals):
                it = self.table.item(i, j)
                if it is None:
                    it = QTableWidgetItem()
                    it.setTextAlignment(Qt.AlignCenter if j != 3 else Qt.AlignLeft | Qt.AlignVCenter)
                    self.table.setItem(i, j, it)
                it.setText(v)
                if j in (1, 2) and v:
                    x = float(v)
                    it.setForeground(QColor(T.BAD if x > 0.08 else (T.GOOD if x < -0.02 else T.TEXT)))
                if j == 4:
                    it.setForeground(QColor(T.ACCENT))


# ====================================================================== COACH
class CoachPage(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.win = win
        cfg = win.cfg
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)
        root = QVBoxLayout(body)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(14)
        root.addWidget(lab("Coach", "h1"))

        c, l = card("¿Qué tanto habla el coach?")
        self.sl_prac, self.lb_prac = self._chat_slider(l, "Práctica y clasificación", cfg["coach"]["charla"], "charla")
        self.sl_race, self.lb_race = self._chat_slider(l, "Carrera", cfg["coach"]["charla_carrera"], "charla_carrera")
        root.addWidget(c)

        c, l = card("Avisos y diagnóstico")
        self.cb_cue = QCheckBox("Avisarme ANTES de las curvas donde puedo mejorar (nivel Coach o Máximo)")
        self.cb_cue.setChecked(cfg["coach"]["avisos_anticipados"])
        self.cb_cue.toggled.connect(lambda v: self._set("coach", "avisos_anticipados", v))
        l.addWidget(self.cb_cue)
        row = QHBoxLayout()
        row.addWidget(lab("Anticipación del aviso (segundos antes de la frenada):"))
        sp = QDoubleSpinBox()
        sp.setRange(1.5, 6.0)
        sp.setSingleStep(0.5)
        sp.setValue(cfg["coach"]["anticipacion_s"])
        sp.valueChanged.connect(lambda v: self._set("coach", "anticipacion_s", v))
        row.addWidget(sp)
        row.addStretch()
        l.addLayout(row)
        cb = QCheckBox("Felicitarme cuando mejoro una curva")
        cb.setChecked(cfg["coach"]["felicitar"])
        cb.toggled.connect(lambda v: self._set("coach", "felicitar", v))
        l.addWidget(cb)
        cb = QCheckBox("Ajuste guiado en práctica: el coach propone cambios de reparto, ABS, TC Cut y TC Slip y mide si te hacen más rápido")
        cb.setChecked(cfg["coach"].get("ajuste_guiado", True))
        cb.toggled.connect(lambda v: self._set("coach", "ajuste_guiado", v))
        l.addWidget(cb)
        cb = QCheckBox("En TC / TC Slip / TC Cut un número más alto significa más ayuda")
        cb.setChecked(cfg["coach"].get("tc_mas_alto_mas_ayuda", True))
        cb.toggled.connect(lambda v: self._set("coach", "tc_mas_alto_mas_ayuda", v))
        l.addWidget(cb)
        row = QHBoxLayout()
        row.addWidget(lab("Avisar pelea con rivales a menos de (s):"))
        sp = QDoubleSpinBox()
        sp.setRange(0.3, 3.0)
        sp.setSingleStep(0.1)
        sp.setValue(cfg["rivales"]["brecha_pelea_s"])
        sp.valueChanged.connect(lambda v: self._set("rivales", "brecha_pelea_s", v))
        row.addWidget(sp)
        row.addStretch()
        l.addLayout(row)
        root.addWidget(c)

        c, l = card("Voz del ingeniero")
        row = QHBoxLayout()
        row.addWidget(lab("Voz:"))
        self.voices = QComboBox()
        self.voices.setMinimumWidth(320)
        self._load_voices()
        self.voices.currentTextChanged.connect(self._voice_changed)
        row.addWidget(self.voices)
        b = QPushButton("Probar voz")
        b.clicked.connect(self._test_voice)
        row.addWidget(b)
        row.addStretch()
        l.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(lab("Velocidad:"))
        s = QSlider(Qt.Horizontal)
        s.setRange(-5, 6)
        s.setValue(int(cfg["voz"]["velocidad"]))
        s.valueChanged.connect(lambda v: self._set("voz", "velocidad", v))
        row.addWidget(s, 1)
        row.addSpacing(20)
        row.addWidget(lab("Volumen:"))
        s = QSlider(Qt.Horizontal)
        s.setRange(10, 100)
        s.setValue(int(cfg["voz"]["volumen"]))
        s.valueChanged.connect(lambda v: self._set("voz", "volumen", v))
        row.addWidget(s, 1)
        l.addLayout(row)
        l.addWidget(lab("Los cambios de voz se aplican al reiniciar el coach.", "muted"))
        root.addWidget(c)

        c, l = card("Hablarle al coach (beta)")
        hc = cfg["hablar"]
        self.cb_talk = QCheckBox("Activar: mantén presionado tu botón y habla")
        self.cb_talk.setChecked(hc["habilitado"])
        self.cb_talk.toggled.connect(lambda v: self._set("hablar", "habilitado", v))
        l.addWidget(self.cb_talk)
        row = QHBoxLayout()
        self.lb_btn = lab(self._btn_text())
        row.addWidget(self.lb_btn)
        b = QPushButton("Asignar botón…")
        b.clicked.connect(self._assign)
        row.addWidget(b)
        row.addStretch()
        l.addLayout(row)
        self.lb_talk = lab("", "muted")
        l.addWidget(self.lb_talk)
        ex = ("Puedes decir: «combustible», «llantas», «cómo voy», «mi tiempo», «dónde pierdo tiempo», "
              "«ayudas», «cuánto falta», «habla menos», «habla más», «silencio», «modo coach», «repite».")
        e = lab(ex, "muted")
        e.setWordWrap(True)
        l.addWidget(e)
        l.addWidget(lab("Requiere el reconocimiento de voz en español de Windows. Se aplica al reiniciar el coach.", "muted"))
        root.addWidget(c)
        root.addStretch()

    def _chat_slider(self, l, title, value, key):
        l.addWidget(lab(title, "h2"))
        row = QHBoxLayout()
        s = QSlider(Qt.Horizontal)
        s.setRange(0, 4)
        s.setValue(int(value))
        s.setTickPosition(QSlider.TicksBelow)
        name = lab("", "mid")
        name.setMinimumWidth(130)
        row.addWidget(s, 1)
        row.addWidget(name)
        l.addLayout(row)
        desc = lab("", "muted")
        desc.setWordWrap(True)
        l.addWidget(desc)

        def upd(v):
            name.setText(CHAT_LEVELS[v])
            desc.setText(CHAT_DESC[v])
            self._set("coach", key, v)
        s.valueChanged.connect(upd)
        upd(int(value))
        return s, name

    def _set(self, sec, key, val):
        self.win.cfg[sec][key] = val
        self.win.save_cfg()

    def _load_voices(self):
        names = []
        try:
            import win32com.client
            v = win32com.client.Dispatch("SAPI.SpVoice")
            names = [v.GetVoices().Item(i).GetDescription() for i in range(v.GetVoices().Count)]
        except Exception:  # noqa: BLE001
            pass
        self.voices.addItem("(automática: primera en español)")
        for n in names:
            self.voices.addItem(n)
        cur = self.win.cfg["voz"]["voz"]
        if cur:
            i = self.voices.findText(cur, Qt.MatchContains)
            if i >= 0:
                self.voices.setCurrentIndex(i)

    def _voice_changed(self, text):
        self._set("voz", "voz", "" if text.startswith("(") else text)

    def _test_voice(self):
        vc = dict(self.win.cfg["voz"])

        def go():
            from ..voice import make_backend
            b = make_backend(vc["backend"], voice=vc["voz"], rate=vc["velocidad"], volume=vc["volumen"])
            b.speak("Radio check. Curva uno, aguanta la frenada.")
            time.sleep(4)
        threading.Thread(target=go, daemon=True).start()

    def _btn_text(self):
        h = self.win.cfg["hablar"]
        if h["dispositivo"] == "joystick":
            return f"Botón: volante/joystick {h['joystick']}, botón {h['boton'] + 1}"
        return f"Botón: tecla {h['tecla']:#04x}" + (" (Bloq Mayús)" if h["tecla"] == 0x14 else "")

    def _assign(self):
        self.lb_btn.setText("Presiona el botón del volante o una tecla…")

        def go():
            from ..talk import detect_button
            r = detect_button(8.0)
            self.win.bridge.done.emit("assign", r)
        threading.Thread(target=go, daemon=True).start()

    def assigned(self, r):
        if r:
            h = self.win.cfg["hablar"]
            if r[0] == "joystick":
                h.update(dispositivo="joystick", joystick=r[1], boton=r[2])
            else:
                h.update(dispositivo="teclado", tecla=r[1])
            self.win.save_cfg()
        self.lb_btn.setText(self._btn_text() if r else "No detecté ningún botón. " + self._btn_text())

    def refresh(self):
        for s, key in ((self.sl_prac, "charla"), (self.sl_race, "charla_carrera")):
            v = int(self.win.cfg["coach"][key])
            if s.value() != v:
                s.blockSignals(True)
                s.setValue(v)
                s.blockSignals(False)
        r = self.win.runner
        t = r.talk if r else None
        self.lb_talk.setText(f"Estado: {t.status}" + (f" · última frase: «{t.last_heard}»" if t and t.last_heard else "")
                             if t else "Estado: inactivo (inicia el coach con la opción activada)")


# ====================================================================== SESIONES
class SessionsPage(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.win = win
        root = QHBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)
        left = QVBoxLayout()
        left.addWidget(lab("Sesiones", "h1"))
        self.list = QListWidget()
        self.list.setWordWrap(True)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list.currentItemChanged.connect(self._show)
        left.addWidget(self.list, 1)
        b = QPushButton("Actualizar lista")
        b.clicked.connect(self.reload)
        left.addWidget(b)
        lw = QWidget()
        lw.setLayout(left)
        lw.setMaximumWidth(380)
        root.addWidget(lw)
        right = QVBoxLayout()
        bar = QHBoxLayout()
        self.btn_deb = QPushButton("Generar debrief")
        self.btn_deb.setObjectName("primary")
        self.btn_deb.clicked.connect(self._debrief)
        self.cb_ai = QCheckBox("Con ingeniero IA (Claude)")
        self.cb_ai.setChecked(bool(os.environ.get("ANTHROPIC_API_KEY")))
        self.btn_svm = QPushButton("Setup .svm…")
        self.btn_svm.clicked.connect(self._pick_svm)
        self.svm = None
        b2 = QPushButton("Abrir carpeta")
        b2.clicked.connect(self._open)
        for w in (self.btn_deb, self.cb_ai, self.btn_svm, b2):
            bar.addWidget(w)
        bar.addStretch()
        right.addLayout(bar)
        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(True)
        right.addWidget(self.view, 1)
        root.addLayout(right, 1)
        self.reload()

    def reload(self):
        self.list.clear()
        root = C.data_dir(self.win.cfg)
        files = sorted(root.rglob("sessions/*/session.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        for p in files[:200]:
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                continue
            valid = [l for l in d.get("laps", []) if l.get("valid")]
            best = min((l["time"] for l in valid), default=0)
            demo = " (demo)" if "demo" in p.parts else ""
            it = QListWidgetItem(f"{d.get('started', '')[:16]}  ·  {d.get('session')}{demo}\n"
                                 f"{d.get('track')}\n{d.get('car')}  ·  {len(valid)} vueltas  ·  mejor {fmt_time(best)}")
            it.setData(Qt.UserRole, str(p))
            self.list.addItem(it)

    def _current(self) -> Path | None:
        it = self.list.currentItem()
        return Path(it.data(Qt.UserRole)) if it else None

    def _show(self, *_):
        p = self._current()
        if not p:
            return
        md = p.parent / "debrief.md"
        self.view.setSearchPaths([str(p.parent)])
        if md.exists():
            self.view.setMarkdown(md.read_text(encoding="utf-8"))
        else:
            self.view.setMarkdown("### Sin debrief todavía\n\nPulsa **Generar debrief** para analizar esta sesión.")

    def _pick_svm(self):
        start = str(Path.home() / "Documents")
        f, _ = QFileDialog.getOpenFileName(self, "Setup de LMU (.svm)", start, "Setups (*.svm)")
        if f:
            self.svm = f
            self.btn_svm.setText(Path(f).name)

    def _open(self):
        p = self._current()
        if p:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(p.parent)))

    def _debrief(self):
        p = self._current()
        if not p:
            return
        self.btn_deb.setEnabled(False)
        self.btn_deb.setText("Analizando…")
        cfg, ai, svm = self.win.cfg, self.cb_ai.isChecked(), self.svm

        def go():
            try:
                import contextlib
                import io
                from ..debrief.report import run_debrief
                with contextlib.redirect_stdout(io.StringIO()):
                    out = run_debrief(cfg, str(p.parent), use_ai=ai, setup=svm)
                self.win.bridge.done.emit("debrief", out)
            except Exception as e:  # noqa: BLE001
                self.win.bridge.done.emit("debrief", e)
        threading.Thread(target=go, daemon=True).start()

    def debrief_done(self, res):
        self.btn_deb.setEnabled(True)
        self.btn_deb.setText("Generar debrief")
        if isinstance(res, Exception):
            QMessageBox.warning(self, "Debrief", f"No se pudo generar: {res}")
        self._show()


# ====================================================================== AJUSTES
class SettingsPage(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.win = win
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(14)
        root.addWidget(lab("Ajustes", "h1"))

        c, l = card("Ingeniero IA (Claude) para el debrief")
        row = QHBoxLayout()
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.Password)
        self.key.setPlaceholderText("sk-ant-… (console.anthropic.com)")
        if os.environ.get("ANTHROPIC_API_KEY"):
            self.key.setPlaceholderText("Clave configurada ✓  (escribe otra para reemplazarla)")
        row.addWidget(self.key, 1)
        b = QPushButton("Guardar clave")
        b.clicked.connect(self._save_key)
        row.addWidget(b)
        l.addLayout(row)
        l.addWidget(lab("Se guarda solo en tu PC (carpeta datos). Modelo: " + win.cfg["ia"]["modelo"], "muted"))
        root.addWidget(c)

        c, l = card("Actualizaciones")
        l.addWidget(lab(f"Versión instalada: {__version__}", "h2"))
        row = QHBoxLayout()
        row.addWidget(lab("Repositorio (GitHub):"))
        self.repo = QLineEdit(win.cfg["actualizaciones"]["repo"])
        self.repo.setPlaceholderText("usuario/LMU-Coach")
        self.repo.editingFinished.connect(self._save_repo)
        row.addWidget(self.repo, 1)
        self.btn_upd = QPushButton("Buscar actualizaciones")
        self.btn_upd.clicked.connect(lambda: win.check_updates(manual=True))
        row.addWidget(self.btn_upd)
        l.addLayout(row)
        cb = QCheckBox("Buscar actualizaciones al abrir la app")
        cb.setChecked(win.cfg["actualizaciones"]["auto"])
        cb.toggled.connect(lambda v: (win.cfg["actualizaciones"].__setitem__("auto", v), win.save_cfg()))
        l.addWidget(cb)
        self.upd_status = lab("", "muted")
        l.addWidget(self.upd_status)
        root.addWidget(c)

        c, l = card("Herramientas")
        row = QHBoxLayout()
        b = QPushButton("Abrir carpeta de datos")
        b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(C.data_dir(win.cfg)))))
        row.addWidget(b)
        b = QPushButton("Diagnóstico (voz + conexión LMU)")
        b.clicked.connect(self._diag)
        row.addWidget(b)
        row.addStretch()
        l.addLayout(row)
        self.diag = QTextBrowser()
        self.diag.setMinimumHeight(220)
        self.diag.setFont(QFont("Consolas", 10))
        l.addWidget(self.diag)
        l.addWidget(lab("En LMU activa: Settings → Gameplay → Enable Plugins = ON.", "muted"))
        root.addWidget(c)
        root.addStretch()

    def _save_key(self):
        k = self.key.text().strip()
        if not k:
            return
        p = C.secret_path(self.win.cfg)
        p.write_text(k, encoding="utf-8")
        os.environ["ANTHROPIC_API_KEY"] = k
        self.key.clear()
        self.key.setPlaceholderText("Clave configurada ✓  (escribe otra para reemplazarla)")
        self.win.pages["Sesiones"].cb_ai.setChecked(True)

    def _save_repo(self):
        self.win.cfg["actualizaciones"]["repo"] = self.repo.text().strip()
        self.win.save_cfg()

    def _diag(self):
        self.diag.setPlainText("Ejecutando diagnóstico (20 s)… sal a pista en LMU para ver la telemetría.")
        cfg = self.win.cfg

        def go():
            import contextlib
            import io
            from ..diag import run
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    run(cfg, C.data_dir(cfg), 20)
            except Exception as e:  # noqa: BLE001
                buf.write(f"\nERROR: {e}")
            self.win.bridge.text.emit("diag", buf.getvalue())
        threading.Thread(target=go, daemon=True).start()


# ====================================================================== VENTANA
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = C.load()
        C.load_secret(self.cfg)
        self.runner: CoachRunner | None = None
        self.bridge = Bridge()
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(lambda: C.save(self.cfg))
        self.setWindowTitle(f"LMU Race Coach {__version__}")
        icon = ROOT / "assets" / "icon.ico"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        self.resize(1360, 860)
        central = QWidget()
        central.setObjectName("root")
        self.setCentralWidget(central)
        lay = QHBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        side = QVBoxLayout()
        side.setContentsMargins(0, 0, 0, 0)
        brand = lab(f"<span style='color:{T.ACCENT};font-size:18px;font-weight:800'>LMU</span>"
                    f"<span style='font-size:18px;font-weight:800'> Coach</span>")
        brand.setContentsMargins(20, 18, 0, 6)
        sidew = QWidget()
        sidew.setFixedWidth(190)
        sidew.setStyleSheet(f"background:{T.PANEL};")
        sidew.setLayout(side)
        side.addWidget(brand)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        side.addWidget(self.nav, 1)
        ver = lab(f"v{__version__}", "muted")
        ver.setContentsMargins(20, 0, 0, 14)
        side.addWidget(ver)
        lay.addWidget(sidew)
        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)
        self.pages = {}
        for name, cls in (("En vivo", LivePage), ("Coach", CoachPage), ("Sesiones", SessionsPage), ("Ajustes", SettingsPage)):
            page = cls(self)
            self.pages[name] = page
            self.stack.addWidget(page)
            self.nav.addItem(QListWidgetItem(name))
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)
        self.bridge.done.connect(self._done)
        self.bridge.text.connect(self._text)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(100)
        if self.cfg["actualizaciones"]["auto"] and self.cfg["actualizaciones"]["repo"]:
            QTimer.singleShot(2500, lambda: self.check_updates(manual=False))

    # -------------------------------------------------------------- acciones
    def save_cfg(self):
        self._save_timer.start(400)

    def _start(self, mode):
        if self.runner and self.runner.running:
            self.runner.stop()
            self.runner.join(3)
        self.runner = CoachRunner(self.cfg, mode=mode)
        self.runner.start()

    def toggle_coach(self):
        if self.runner and self.runner.running and self.runner.mode == "lmu":
            self.runner.stop()
            QTimer.singleShot(1500, self.pages["Sesiones"].reload)
        else:
            self._start("lmu")

    def toggle_demo(self):
        if self.runner and self.runner.running and self.runner.mode == "demo":
            self.runner.stop()
        else:
            self._start("demo")

    def check_updates(self, manual=False):
        repo = self.cfg["actualizaciones"]["repo"]
        st = self.pages["Ajustes"].upd_status
        if not repo:
            if manual:
                st.setText("Configura primero el repositorio de GitHub.")
            return
        st.setText("Buscando…")

        def go():
            try:
                from ..updater import check
                self.bridge.done.emit("upd_check", (check(repo), manual))
            except Exception as e:  # noqa: BLE001
                self.bridge.done.emit("upd_check", (e, manual))
        threading.Thread(target=go, daemon=True).start()

    def _done(self, task, res):
        if task == "debrief":
            self.pages["Sesiones"].debrief_done(res)
        elif task == "assign":
            self.pages["Coach"].assigned(res)
        elif task == "upd_check":
            info, manual = res
            st = self.pages["Ajustes"].upd_status
            if isinstance(info, Exception):
                st.setText(f"No se pudo consultar: {info}")
            elif not info:
                st.setText(f"Estás al día ({__version__}).")
            else:
                st.setText(f"Nueva versión disponible: {info['version']}")
                r = QMessageBox.question(self, "Actualización disponible",
                                         f"Hay una nueva versión {info['version']}.\n\n{info['notes'][:800]}\n\n¿Instalar ahora?")
                if r == QMessageBox.Yes:
                    self._apply_update(info["url"])
        elif task == "upd_apply":
            st = self.pages["Ajustes"].upd_status
            if isinstance(res, Exception):
                st.setText(f"Error al actualizar: {res}")
            else:
                st.setText(f"Actualizado a {res}. Cierra y vuelve a abrir la app.")
                QMessageBox.information(self, "Actualizado", f"Se instaló la versión {res}.\nCierra y vuelve a abrir la app.")

    def _apply_update(self, url):
        st = self.pages["Ajustes"].upd_status

        def go():
            try:
                from ..updater import apply
                ver = apply(url, progress=lambda s: self.bridge.text.emit("upd", s))
                self.bridge.done.emit("upd_apply", ver)
            except Exception as e:  # noqa: BLE001
                self.bridge.done.emit("upd_apply", e)
        st.setText("Descargando…")
        threading.Thread(target=go, daemon=True).start()

    def _text(self, dest, text):
        if dest == "diag":
            self.pages["Ajustes"].diag.setPlainText(text)
        elif dest == "upd":
            self.pages["Ajustes"].upd_status.setText(text)

    def _tick(self):
        page = self.stack.currentWidget()
        if hasattr(page, "refresh"):
            page.refresh()

    def closeEvent(self, ev):
        C.save(self.cfg)
        if self.runner and self.runner.running:
            self.runner.stop()
            self.runner.join(3)
        ev.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("LMU Race Coach")
    app.setStyleSheet(T.QSS)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
